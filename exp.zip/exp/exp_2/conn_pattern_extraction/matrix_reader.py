import json
import os
from typing import List, Tuple, Any

class MatrixReader:
    def __init__(self, json_path: str):
        """初始化时直接从 JSON 文件读取矩阵数据"""
        if not os.path.exists(json_path):
            raise FileNotFoundError(f"Matrix file not found: {json_path}")
            
        with open(json_path, 'r', encoding='utf-8') as f:
            self.matrix = json.load(f)
            
    def get_connections(self, node: str, direction: str = "outbound") -> List[Tuple[str, float]]:
        """
        读取并查询矩阵中的连接信息
        :param node: 目标算子名称
        :param direction: "inbound" (谁指向我) 或 "outbound" (我指向谁)
        """
        results = []
        
        if direction == "outbound":
            # 读取 node 的出度：直接从 matrix[node] 获取
            outbound_data = self.matrix.get(node, {})
            for target, val in outbound_data.items():
                if val > 0:
                    results.append((target, val))
                    
        elif direction == "inbound":
            # 读取 node 的入度：需要遍历整个矩阵
            for src, targets in self.matrix.items():
                val = targets.get(node, 0)
                if val > 0:
                    results.append((src, val))
        else:
            raise ValueError("direction must be 'inbound' or 'outbound'")

        # 按数值降序排序
        return sorted(results, key=lambda x: x[1], reverse=True)

# # ================= 使用示例 =================
# if __name__ == "__main__":
#     # 假设这是您之前生成的后验矩阵
#     reader = MatrixReader("./transition_frequencies.json")
    
#     # 查询 FilterDict 的入度 (谁连接到它)
#     in_connections = reader.get_connections("FilterDict", direction="inbound")
#     print(f"FilterDict Inbound: {in_connections}")
    
#     # 查询 FilterDict 的出度 (它连接到谁)
#     out_connections = reader.get_connections("FilterDict", direction="outbound")
#     print(f"FilterDict Outbound: {out_connections}")
