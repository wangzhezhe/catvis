import json
import yaml
import os
import glob
from collections import defaultdict
from typing import Dict, List, Tuple

# =====================================================================
# 1. 配置与规则设定
# =====================================================================

# 类别之间的初始转移概率倾向 (Prior Beliefs)
CATEGORY_TRANSITION_PRIOR = {
    "loader": {"feature_extract": 1, "reducedim": 0, "vis": 0, "writer": 0.0},
    "feature_extract": {"feature_extract": 0.35, "reducedim": 0.1, "vis": 0.45, "writer": 0.1},
    "vis": {"feature_extract": 0.0, "reducedim": 0.05, "vis": 0.3, "writer": 0.65},
    "reducedim": {"feature_extract": 0.05, "vis": 0.85, "writer": 0.1}, 
    "writer": {"loader": 0.0, "feature_extract": 0.0, "vis": 0.0, "reducedim": 0.0, "writer": 0.0}
}

# 强制终端节点（绝对不会有输出流向其他算子的节点）
TERMINAL_NODES = {"RenderServer", "oneVTKDataWriter", "multiVTPDataWriter", "vtkMultiblocksDataWriter", "MemoryWriter"}

# 强制拓扑规则 (Hard Topology Rules)
# 含义: 如果前一个节点是 Key 中的任何一个，它的下一个节点必须有 100% 的概率是 Value。
MUST_FOLLOW_RULES = {
    "vtkDataLoader": "Preprocess",
    "vtkDataLoaderByList": "Preprocess",
    "vtkmDataLoader": "Preprocess"
}

# =====================================================================
# 2. 核心类：拓扑概率矩阵管理器
# =====================================================================
class TopologyMatrixManager:
    def __init__(self, filter_desc_path: str):
        self.tasks_info = self._load_json(filter_desc_path)
        self.task_names = [t["task_id"] for t in self.tasks_info]
        self.category_map = {t["task_id"]: t["category"] for t in self.tasks_info}
        
        # 初始化概率矩阵 Matrix[A][B]
        self.prior_matrix = defaultdict(lambda: defaultdict(float))
        self.count_matrix = defaultdict(lambda: defaultdict(int))
        self.posterior_matrix = defaultdict(lambda: defaultdict(float))
        
        self._build_prior_matrix()

    def _load_json(self, path: str) -> List[Dict]:
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)

    def _build_prior_matrix(self):
        """步骤1：基于分类生成初始先验概率，并应用强制规则"""
        for src in self.task_names:
            if src in TERMINAL_NODES:
                continue # 终端节点没有出度
                
            # --- 应用强制规则 (Hard Rules) ---
            if src in MUST_FOLLOW_RULES:
                target_node = MUST_FOLLOW_RULES[src]
                if target_node in self.task_names:
                    # 100% 转移概率
                    for dst in self.task_names:
                        self.prior_matrix[src][dst] = 1.0 if dst == target_node else 0.0
                    continue # 跳过后续的类别计算
            
            # --- 应用类别先验 (Category Prior) ---
            src_cat = self.category_map.get(src, "unknown")
            if src_cat not in CATEGORY_TRANSITION_PRIOR:
                continue
                
            cat_dist = CATEGORY_TRANSITION_PRIOR[src_cat]
            
            for dst in self.task_names:
                dst_cat = self.category_map.get(dst, "unknown")
                base_prob = cat_dist.get(dst_cat, 0.0)
                
                # 均分概率给目标类别下的所有具体算子
                num_dst_cat_tasks = sum(1 for t in self.task_names if self.category_map.get(t) == dst_cat)
                if num_dst_cat_tasks > 0:
                    self.prior_matrix[src][dst] = base_prob / num_dst_cat_tasks

        # 归一化先验概率
        self._normalize_matrix(self.prior_matrix)

    def _safe_get_types(self, task_cls, method_name: str):
        """
        安全地获取算子支持的类型。
        兼容带有 @classmethod 的情况，以及开发者忘记加装饰器导致变成实例方法的情况。
        """
        try:
            func = getattr(task_cls, method_name)
            try:
                # 尝试作为类方法直接调用
                return set(func())
            except TypeError:
                # 如果报 TypeError (missing 'self')，说明是实例方法
                # 我们创建一个极其简单的 dummy 实例来调用它
                dummy_instance = task_cls(name="dummy_for_type_check")
                func_instance = getattr(dummy_instance, method_name)
                return set(func_instance())
        except Exception:
            # 如果算子未实现这些方法，或实例化失败，返回 None
            return None

    def apply_hard_constraints(self, task_registry: Dict):
        """
        硬约束校验：调用 get_supported_inputs/outputs，如果不匹配则概率归零。
        """
        print("\nApplying data-type hard constraints to zero out invalid connections...")
        import vtk
        
        # 临时静音 VTK 全局警告，避免由于空管线探测引起的 vtkArrayCalculator 等刷屏报错
        old_warning_status = vtk.vtkObject.GetGlobalWarningDisplay()
        vtk.vtkObject.GlobalWarningDisplayOff()

        zeroed_count = 0
        for src in self.task_names:
            # 强制规则节点不受数据类型约束的影响
            if src in MUST_FOLLOW_RULES:
                continue
                
            for dst in self.task_names:
                if self.prior_matrix[src][dst] > 0:
                    src_cls = task_registry.get(src)
                    dst_cls = task_registry.get(dst)
                    
                    if src_cls and dst_cls:
                        # 使用安全的包裹函数获取类型
                        out_types = self._safe_get_types(src_cls, 'get_supported_output_types')
                        in_types = self._safe_get_types(dst_cls, 'get_supported_input_types')
                        
                        # 只有当两个类型都能成功获取时，才进行严格校验
                        if out_types is not None and in_types is not None:
                            # 如果没有交集，说明数据类型绝对不兼容，概率直接归零
                            if not out_types.intersection(in_types):
                                self.prior_matrix[src][dst] = 0.0
                                zeroed_count += 1

        # 恢复 VTK 的全局警告设置
        vtk.vtkObject.SetGlobalWarningDisplay(old_warning_status)
                            
        print(f"Zeroed out {zeroed_count} incompatible edge transitions.")
        self._normalize_matrix(self.prior_matrix)

    def parse_benchmark(self, benchmark_dir: str):
        """步骤3：解析Benchmark文件夹中的YAML，统计实际边数"""
        print(f"\nParsing benchmark workflows from {benchmark_dir}...")
        yaml_files = []
        for pattern in ["easy-case*", "mid-case*", "hard-case*"]:
            yaml_files.extend(glob.glob(os.path.join(benchmark_dir, pattern, "*.yaml")))

        if not yaml_files:
            print("  No YAML files found in the benchmark directory.")
            return

        edges_found = 0
        for yml_path in yaml_files:
            try:
                with open(yml_path, 'r', encoding='utf-8') as f:
                    data = yaml.safe_load(f)
                
                if not data or "tasks" not in data:
                    continue
                    
                tasks = data["tasks"]
                id_to_operator = {tid: t_info.get("from") for tid, t_info in tasks.items()}
                
                for tid, t_info in tasks.items():
                    dst_operator = t_info.get("from")
                    inputs = t_info.get("inputs", [])
                    
                    if not dst_operator or dst_operator not in self.task_names:
                        continue
                        
                    for item in inputs:
                        if isinstance(item, dict) and "data" in item:
                            data_deps = item["data"]
                            if not isinstance(data_deps, list):
                                data_deps = [data_deps]
                            
                            for dep in data_deps:
                                if isinstance(dep, str) and dep.startswith("$"):
                                    src_id = dep.lstrip("$").split(".")[0]
                                    src_operator = id_to_operator.get(src_id)
                                    
                                    if src_operator and src_operator in self.task_names:
                                        self.count_matrix[src_operator][dst_operator] += 1
                                        edges_found += 1
            except Exception as e:
                print(f"  Error parsing {yml_path}: {e}")
                
        print(f"  Successfully found {edges_found} actual edge transitions.")

    def compute_posterior(self, alpha=5.0):
        """
        步骤4：基于贝叶斯平滑计算后验概率。
        如果是 MUST_FOLLOW_RULES 中的节点，强制保持后验概率与先验一致（100% 转移）。
        """
        print(f"\nComputing posterior matrix with Bayesian Smoothing (alpha={alpha})...")
        for src in self.task_names:
            # 强制规则节点不参与平滑计算
            if src in MUST_FOLLOW_RULES:
                for dst in self.task_names:
                    self.posterior_matrix[src][dst] = self.prior_matrix[src][dst]
                continue

            total_src_count = sum(self.count_matrix[src].values())
            
            for dst in self.task_names:
                count_ab = self.count_matrix[src][dst]
                prior_ab = self.prior_matrix[src][dst]
                
                if prior_ab > 0 or count_ab > 0:
                    numerator = count_ab + alpha * prior_ab
                    denominator = total_src_count + alpha
                    self.posterior_matrix[src][dst] = numerator / denominator
                else:
                    self.posterior_matrix[src][dst] = 0.0
                    
        self._normalize_matrix(self.posterior_matrix)

    def _normalize_matrix(self, matrix: Dict):
        """将字典矩阵的每一行进行归一化（使概率和为1）"""
        for src in list(matrix.keys()):
            total = sum(matrix[src].values())
            if total > 0:
                for dst in matrix[src]:
                    matrix[src][dst] /= total

    def export_matrices(self, prior_path: str, posterior_path: str, count_path: str):
        """步骤5：分别导出先验概率、后验概率和原始频率矩阵"""
        
        # 1. 导出先验矩阵
        with open(prior_path, 'w', encoding='utf-8') as f:
            json.dump(self.prior_matrix, f, indent=4)
        
        # 2. 导出后验矩阵
        with open(posterior_path, 'w', encoding='utf-8') as f:
            json.dump(self.posterior_matrix, f, indent=4)
            
        # 3. 导出原始统计频率 (嵌套字典结构: {Src: {Dst: Count}})
        # 将 defaultdict 转换为普通 dict 以方便 JSON 导出
        count_dict = {k: dict(v) for k, v in self.count_matrix.items()}
        with open(count_path, 'w', encoding='utf-8') as f:
            json.dump(count_dict, f, indent=4)
            
        print(f"\n[INFO] Prior Matrix saved to: {prior_path}")
        print(f"[INFO] Posterior Matrix saved to: {posterior_path}")
        print(f"[INFO] Transition Frequency (Counts) saved to: {count_path}")

    def get_top_k_next_nodes(self, src_node: str, matrix_type: str = "posterior", k: int = 5) -> List[Tuple[str, float]]:
        """辅助方法：获取某个算子最有可能的下几个连接节点"""
        matrix = self.posterior_matrix if matrix_type == "posterior" else self.prior_matrix
        
        if src_node not in matrix:
            return []
        
        sorted_dst = sorted(matrix[src_node].items(), key=lambda x: x[1], reverse=True)
        return [(dst, round(prob, 4)) for dst, prob in sorted_dst[:k] if prob > 0]


# =====================================================================
# 3. 执行入口
# =====================================================================
if __name__ == "__main__":
    # 路径配置 (请根据您的实际工程路径修改)
    # 假设该脚本与 filter_name_descriptions.json 在同一级或其父目录
    from pathlib import Path
    BASE_DIR = Path(__file__).parent
    FILTER_DESC_JSON = BASE_DIR /".."/"exp"/"exp_1"/ "external_knowledge" / "filter_name_descriptions.json"
    BENCHMARK_DIR = BASE_DIR  
    
    PRIOR_JSON_PATH = BASE_DIR / "prior_transition_matrix.json"
    POSTERIOR_JSON_PATH = BASE_DIR / "posterior_transition_matrix.json"
    FREQUENCY_JSON_PATH = BASE_DIR / "transition_frequencies.json"

    print("="*60)
    print("Starting Topology Matrix Generation...")
    print("="*60)

    # 1. 初始化并构建先验概率
    manager = TopologyMatrixManager(str(FILTER_DESC_JSON))
    
    # 2. 硬约束校验
    try:
        from gwlalg.alg.alg_task import TASK_REGISTRY, load_all_tasks
        
        load_all_tasks() 
        
        if TASK_REGISTRY:
            manager.apply_hard_constraints(TASK_REGISTRY)
        else:
            print("TASK_REGISTRY is empty. Skipping dynamic hard constraints.")
    except ImportError as e:
        print(f"Failed to import gwlalg.alg.alg_task: {e}. Skipping hard constraints.")
    
    # 3. 解析 Benchmark 修正概率
    if BENCHMARK_DIR.exists():
        manager.parse_benchmark(str(BENCHMARK_DIR))
    else:
        print(f"\nWarning: Benchmark directory {BENCHMARK_DIR} not found. Posterior will be equal to Prior.")
        
    # 4. 计算最终的后验概率 (alpha=5表示对先验的中等置信度)
    manager.compute_posterior(alpha=5.0)
    
    # 5. 分别导出先验和后验矩阵
    manager.export_matrices(str(PRIOR_JSON_PATH), str(POSTERIOR_JSON_PATH),str(FREQUENCY_JSON_PATH))

    # --- 测试演示 ---
    print("\n" + "="*60)
    print("Example Predictions (Posterior)")
    print("="*60)
    test_nodes = ["vtkDataLoader", "SpanNormal", "AddQCriterion", "Slice"]
    for node in test_nodes:
        top_k = manager.get_top_k_next_nodes(node, matrix_type="posterior", k=4)
        print(f"If current node is [{node}], high probability next nodes are:")
        if not top_k:
            print("    -> (None/Terminal Node)")
        for next_node, prob in top_k:
            print(f"    -> {next_node} (Prob: {prob:.1%})")