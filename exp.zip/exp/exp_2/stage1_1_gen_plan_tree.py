import os
import json
from semantic_parser import SemanticParser

def load_query_from_file(file_path: str) -> str:
    """从指定路径加载用户查询文本"""
    base_dir = os.path.dirname(os.path.abspath(__file__))
    # 假设 query 文件放在 prompts 或根目录下，这里根据实际情况调整
    full_path = os.path.join(base_dir, file_path)
    
    try:
        with open(full_path, 'r', encoding='utf-8') as f:
            content = f.read().strip()
            if not content:
                raise ValueError(f"文件 {file_path} 内容为空")
            return content
    except Exception as e:
        print(f"❌ 加载 Query 文件失败: {e}")
        raise e

def main():
    # 1. 配置外部知识库文件列表 (Context)
    knowledge_files = [
        "stage1_filter_name_descriptions.json", 
        "stage1_tree_descriptions.json"
    ]

    # 2. 初始化解析器 (内部已完成 LLM 绑定和知识库加载)
    parser = SemanticParser(context_files=knowledge_files)

    # 3. 从文件加载具体的 User Query / Instruction
    query_file = "query_simple.txt"
    try:
        user_query = load_query_from_file(query_file)
        print(f"✅ 已加载查询内容 (来自 {query_file})")
        
        # 4. 执行意图解析
        # 此时：system = 外部知识库, user = query1.txt 的内容
        print("🚀 正在调用 LLM 进行语义解析...")
        result_dict_json = parser.parse_intent(user_query=user_query)

        # 5. 输出解析后的 Intent Tree 结果
        print("\n--- 解析结果 (Intent Tree) ---")
        print(result_dict_json)

        intent_tree_name = query_file.split(".")[0] + "_intent_tree.json"
        
        # --- 修正部分开始 ---
        with open(intent_tree_name, "w", encoding="utf-8") as f:
            # 使用 json.dump 直接将字典写入文件
            json.dump(result_dict_json, f, indent=4, ensure_ascii=False)
        # --- 修正部分结束 ---

        print(f"✅ 结果已保存至: {intent_tree_name}")
    except Exception as e:
        print(f"❌ 解析失败: {e}")

if __name__ == "__main__":
    main()