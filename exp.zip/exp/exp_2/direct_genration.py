# experiment1_direct_generation.py
import os
import json
import re
import logging
import dotenv
from langchain_openai import ChatOpenAI
from langchain_core.prompts import PromptTemplate

# ==========================================
# 0. 日志与环境变量配置
# ==========================================
logging.basicConfig(level=logging.INFO, format='[%(levelname)s] %(asctime)s - %(message)s')
logger = logging.getLogger(__name__)

dotenv.load_dotenv()

def get_llm_client():
    """初始化大语言模型客户端"""
    return ChatOpenAI(
        base_url="https://uni-api.cstcloud.cn/v1",
        api_key=os.environ.get("DEEPSEEK_API_KEY", "0270fe5dc0bc6c0e8ed986804d699811f1bc0ec9196b551e6482436140324487"),
        model="deepseek-v3:671b",
        temperature=0,
    )

def extract_yaml_content(text: str) -> str:
    """从LLM响应中提取YAML内容"""
    yaml_pattern = r'```(?:yaml)?\s*(.*?)\s*```'
    match = re.search(yaml_pattern, text, re.DOTALL)
    if match:
        return match.group(1).strip()
    return text.strip()

# ==========================================
# 1. 核心类：直接生成器
# ==========================================
class DirectWorkflowGenerator:
    """对比实验1: 无中间规划，直接由Query生成YAML"""
    def __init__(self):
        self.llm = get_llm_client()
        self.prompt = PromptTemplate(
            template="""你是一个专业的数据处理与可视化工作流配置专家。
请根据用户的自然语言查询，直接参考提供的函数描述库，仿照示例工作流的格式，生成目标工作流的YAML配置。

【用户查询】
{user_query}

【可用函数/组件描述库】
{components_json}

【示例工作流YAML】
{example_yaml}

【要求】
1. 直接输出最终的工作流YAML配置。
2. 确保组件名称、参数字段与“可用函数/组件描述库”中的定义匹配。
3. YAML结构必须与“示例工作流YAML”保持一致。
4. 只输出YAML代码，使用 ```yaml ``` 包裹，不要输出任何额外的解释文本。
""",
            input_variables=["user_query", "components_json", "example_yaml"]
        )

    def generate(self, user_query: str, components_json: str, example_yaml: str) -> str:
        logger.info("🧪 [实验1] 正在直接生成工作流YAML (端到端)...")
        chain = self.prompt | self.llm
        response = chain.invoke({
            "user_query": user_query,
            "components_json": components_json,
            "example_yaml": example_yaml
        })
        return extract_yaml_content(response.content)

# ==========================================
# 2. 运行实验
# ==========================================
if __name__ == "__main__":
    current_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(current_dir, "data")
    os.makedirs(data_dir, exist_ok=True)
    
    # 文件路径准备
    func_desc_path = os.path.join(data_dir, "algorithms_for_llm.json")
    example_yaml_path = os.path.join(data_dir, "config", "clip.yaml")
    
    # 自动生成 Mock 数据 (如果文件不存在，防止报错)
    if not os.path.exists(func_desc_path):
        with open(func_desc_path, 'w', encoding='utf-8') as f:
            json.dump([{"name": "ReadVTK", "desc": "读取VTK数据"}], f, ensure_ascii=False)
    if not os.path.exists(example_yaml_path):
        with open(example_yaml_path, 'w', encoding='utf-8') as f:
            f.write("name: example\ntasks:\n  task1:\n    from: ReadVTK\n    inputs:\n      file: 'data.vtk'\n")

    # 读取背景知识文件
    with open(func_desc_path, 'r', encoding='utf-8') as f:
        components_json_str = f.read()
    with open(example_yaml_path, 'r', encoding='utf-8') as f:
        example_yaml_str = f.read()

    # 测试 Query
    user_query = "读入VTK数据，计算展向坐标，提取98%叶高的等值面，绕Z轴顺时针复制3个22.5度扇区，在Z=-0.162位置裁剪，最后转换为Z-Theta视图并输出VTU文件。"

    print("="*60)
    print("🚀 运行对比实验 1 (端到端直接生成)")
    print("="*60)

    # 执行生成
    generator = DirectWorkflowGenerator()
    yaml_result = generator.generate(user_query, components_json_str, example_yaml_str)
    
    # 保存结果
    output_path = os.path.join(data_dir, "exp1_direct_output.yaml")
    with open(output_path, 'w', encoding='utf-8') as f:
        f.write(yaml_result)
        
    print(f"\n✅ 实验1完成！结果已保存至: {output_path}")