# find parameters based on tree structure

# Input is a tree structure with taskids in it
# tree structure is like this
# {
#     "task_sequence": [
#         {
#             "task_id": "T1",
#             "task_description": "Load multi-block VTK data from specified file path",
#             "component_name": [
#                 "vtkmDataLoader"
#             ]
#         },
#         {
#             "task_id": "T2",
#             "task_description": "Preprocess and clean the loaded multi-block dataset",
#             "component_name": [
#                 "Preprocess"
#             ]
#         },
#         ...
# }
# this is the pandatic file
# from typing import List, Dict, Optional
# from pydantic import BaseModel, Field

# class Task(BaseModel):
#     """定义单个工作流任务的结构"""
#     task_id: str = Field(..., description="任务的唯一标识符，one word description of the task, such as dataload, data_preprocess, sreamline_analysis, or export. etc")
#     task_description: str = Field(..., description="该任务的具体描述， 比如数据导入，数据预处理，分析，或者导出等等")
#     component_name: List[str] = Field(default=[], description="当前这一步可能会用到的组件库中的组件类型名称")
#     # dependencies: List[str] = Field(default=[], description="依赖的前序任务ID列表")
#     # parameters: Dict[str, str | int | float | bool] = Field(
#     #     default={}, 
#     #     description="组件需要的具体参数，键值对形式"
#     # )

# class IntentPlan(BaseModel):
#     # """
#     # 这是 Agent 的核心技能：将自然语言请求转化为结构化工作流方案。
#     # """
#     # original_query: str = Field(..., description="用户的原始查询内容")
#     # identified_intent: str = Field(..., description="识别出的核心分析目标")
#     # intent_type: str = Field(..., description="分析类型，如：特征追踪、时空对比、可视化生成")
    
#     # explicit_conditions: Dict[str, str] = Field(
#     #     description="明确提取出的限制条件，如时间、空间范围"
#     # )
    
#     # implicit_conditions: Dict[str, Dict[str, str]] = Field(
#     #     description="推测出的隐含条件，包含推测原因"
#     # )
    
#     # reasoning_chain: str = Field(..., description="生成此方案的完整思维链推导过程")
    
#     task_sequence: List[Task] = Field(..., description="可执行的任务序列列表")

# Output is external knowledge based on the tree structure, with associated parameters

# go through each element in the task_sequence
# get the component name and find associated 

# all components information is in this format, the file is under external knowledge filter_parameter_descriptions.json
# [
#     {
#         "task_id": "ArrayCalculator",
#         "name_zh": "计算器",
#         "category": "feature_extract",
#         "description": "Computes new scalar or vector arrays by applying mathematical expressions to existing field variables.\n\nUse Cases:\n1. Deriving custom physical quantities (e.g., velocity magnitude, vorticity) from primitive variables.\n2. Combining multiple scalar fields into a new derived field for specialized visualization.\n3. Performing on-the-fly mathematical transformations to enhance data interpretation.\n4. Computing vector operations such as dot product or cross product between vector fields.\n\nConstraints:\n- Input must contain a single dataset (vtkPolyData or vtkImageData).\n- All variables referenced in the expression must exist in the input dataset.\n- Vector variables must have exactly 3 components.\n- The expression must be mathematically valid and produce a consistent result type.\n- For multi-block datasets, consider applying this filter per block separately.",
#         "arguments": {}
#     },
#     {
#         "task_id": "BandedContour",
#         "name_zh": "带状等值线",
#         "category": "vis",
#         "description": "Generates banded contour regions by discretizing a scalar field into discrete intervals.\n\nUse Cases:\n1. Creating filled contour plots to visualize scalar field distributions.\n2. Generating region-based visualizations for qualitative analysis of field variations.\n\nConstraints:\n- Input must be vtkPolyData type datasets.\n- The specified scalar variable must exist in either point or cell data.\n- Number of bands must be positive integer.",
#         "arguments": {
#             "type": "object",
#             "properties": {
#                 "variable_name": {
#                     "description": "variable name",
#                     "title": "Variable Name",
#                     "type": "string"
#                 },
#                 "num_bands": {
#                     "description": "number of bands",
#                     "title": "Num Bands",
#                     "type": "integer"
#                 }
#             },
#             "required": [
#                 "variable_name",
#                 "num_bands"
#             ]
#         }
#     },
#     {
#         "task_id": "Clip",
#         "name_zh": "裁剪",
#         "category": "vis",
#         "description": "Cuts a dataset using an implicit plane function to extract portions on one side of the plane.\n\nUse Cases:\n1. Isolating regions of interest by cutting away unnecessary portions of the model.\n2. Creating cross-sectional views to examine internal structures.\n3. Preparing data for further analysis on specific subregions.\n\nConstraints:\n- Input must be compatible with vtkTableBasedClipDataSet (supports various dataset types).\n- The clipping plane is defined by origin and normal vector.\n- InsideOut parameter controls which side of the plane is kept.",
#         "arguments": {
#             "type": "object",
#             "properties": {
#                 "origin": {
#                     "description": "定义平面在三维空间中的原点位置坐标 [x, y, z]",
#                     "items": {
#                         "type": "number"
#                     },
#                     "title": "平面原点",
#                     "type": "array"
#                 },
#                 "normal": {
#                     "description": "定义平面在三维空间中的法向量 [x, y, z]",
#                     "items": {
#                         "type": "number"
#                     },
#                     "title": "平面法向量",
#                     "type": "array"
#                 },
#                 "insideout": {
#                     "description": "设置剖切方向，True为内侧，False为外侧",
#                     "title": "剖切方向",
#                     "type": "boolean"
#                 }
#             },
#             "required": [
#                 "origin",
#                 "normal",
#                 "insideout"
#             ]
#         }
#         ....
#     }
# ]

#extract associated item and write it into another json file

import json
from typing import List, Dict, Any
from pydantic import BaseModel, Field
from workflow_schema import IntentPlan
import os
from conn_pattern_extraction.matrix_reader import MatrixReader

input_json_path = "query_simple_intent_tree.json"
operator_description_path = os.path.join("external_knowledge", "filter_parameter_descriptions.json")
output_json_path = "stage1_selected_operator_knowledge.json"
transition_matrix_path = "conn_pattern_extraction/transition_frequencies.json"   


# sample input value is like this
#  [('MergeDataSets', 1), ('oneVTKDataWriter', 1), ('RenderServer', 1)]
def normalize_and_get_high_probability_tasks(item_lists: List[tuple]):
    normalized_values = []
    high_prob_tasks = []
    total_sum = sum(item[1] for item in item_lists)

    for item in item_lists:
        probability = item[1]*1.0 / total_sum
        normalized_values.append(probability)
        if probability>0.1 and item[1]>1:
            high_prob_tasks.append(item[0])

    print(normalized_values)
    return high_prob_tasks

# 1. 加载输入数据
with open(input_json_path, 'r', encoding='utf-8') as f:
    input_data = json.load(f)
    intent_plan = IntentPlan(**input_data)

# 2. 加载外部知识库
with open(operator_description_path, 'r', encoding='utf-8') as f:
    operator_knowledge_list = json.load(f)

# 创建查询字典
knowledge_lookup = {item['task_id']: item for item in operator_knowledge_list}

enriched_output = []

# --- 修改部分：使用 set 记录已经添加过的组件 ID，防止重复 ---
seen_components = set() 

all_potential_component_names=set()

expanded_potential_component_names=set()


for task in intent_plan.task_sequence:
    for comp in task.potential_component_names:
        all_potential_component_names.add(comp)

# for each one in expanded_potential_component_names, expand through connection matrix
print("all_potential_component_names:\n", all_potential_component_names)

# for each element in expanded_potential_component_names, find its connected incoming and outgoing components
# normalized value > %50
reader = MatrixReader(transition_matrix_path)

for comp in all_potential_component_names:
    print("enrich comp:",comp)

    # 查询 FilterDict 的入度 (谁连接到它)
    in_connections = reader.get_connections(comp, direction="inbound")
    print(f"Test Inbound: {in_connections}")

    high_prob_tasks = normalize_and_get_high_probability_tasks(in_connections)
    for item in high_prob_tasks:
        expanded_potential_component_names.add(item)

    # 查询 FilterDict 的出度 (它连接到谁)
    out_connections = reader.get_connections(comp, direction="outbound")
    print(f"Test Outbound: {out_connections}")

    high_prob_tasks = normalize_and_get_high_probability_tasks(out_connections)
    for item in high_prob_tasks:
        expanded_potential_component_names.add(item)

    print("expanded_potential_component_names:", expanded_potential_component_names)

# merge expanded_potential_component_names into all_potential_component_names
all_potential_component_names = all_potential_component_names.union(expanded_potential_component_names)
print("all_potential_component_names after merge:", all_potential_component_names)

# 3. 遍历任务序列
# for task in intent_plan.task_sequence:
#     for comp in task.potential_component_names:
        # 如果该组件不在知识库中，或者在这个 task 里已经添加过了，就跳过

for comp in all_potential_component_names:

    if comp in knowledge_lookup and comp not in seen_components:
        print("find comp",comp)
        component_info={}
        original_component_info=knowledge_lookup[comp]
        component_info["component_name"]=original_component_info["task_id"]
        component_info["description"]=original_component_info["description"]
        component_info["arguments"]=original_component_info["arguments"]

        seen_components.add(comp)  # 标记为已处理
        enriched_output.append(component_info)
    else:
        continue
    # -------------------------------------------------------


# 4. 保存到新的 JSON 文件
with open(output_json_path, 'w', encoding='utf-8') as f:
    json.dump(enriched_output, f, indent=4, ensure_ascii=False)

print(f"Enriched parameters successfully saved to {output_json_path}")

# TODO also need to expand based on connection information