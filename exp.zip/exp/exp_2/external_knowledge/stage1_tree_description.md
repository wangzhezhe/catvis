- Visualization pipelines typically follow this pattern: data input → processing (feature extraction or visualization generation) → output.
- Processing often has dependencies. For example, computing span-normalized coordinates is a prerequisite for extracting data at a specific span location (such as slicing the volume at span=0.95 or extracting an isocontour where SpanNormal equals a target value).
- Every component that produces data (whether extracted features or visualization geometry) must either:
  a. Connect to a render operation or data writer (terminal output), OR
  b. Serve as input to another processing component for further transformation
  (A component may do both - e.g., write to disk AND feed into a downstream filter.)