You could follow these rules strictly when generating a workflow.

## Structure Rules

A workflow file has two top-level fields:
- `name`: a short string identifier for the workflow
- `params`: global parameters accessible via `$globals.params.<key>`
- `tasks`: a dictionary of task definitions, each with a unique ID as the key

## Task Definition Rules

Each task must contain exactly these fields:
- `name`: a human-readable Chinese or English label for the task
- `from`: the operator name (must be chosen from the provided operator list)
- `inputs`: a list of key-value pairs defining the input arguments
- `output`: a string identifier for the output of this task

## Data Flow Rules

- The output of a task is referenced by other tasks using the syntax:
  `$<TaskID>.<output_field>`
- For example, if task `IDLoadingData` has `output: IDLoadingData_output`, 
  downstream tasks reference it as `$IDLoadingData.IDLoadingData_output`
- Every task except the first must receive its primary `data` input from 
  the output of a preceding task
- Multiple tasks can reference the same upstream output, enabling branching pipelines
- Tasks are executed in dependency order, not necessarily in the order 
  they appear in the file

## Task ID Rules

- Each task must have a unique ID as its dictionary key (e.g. `IDLoadingData`, 
  `IDPreprocess`, `IDIso`)
- If multiple tasks use the same operator, distinguish them with a numeric 
  suffix (e.g. `IDIso1`, `IDIso2`)

## Pipeline Entry and Exit Rules

- Every pipeline must begin with a data loading task such as `vtkmDataLoader` or `vtkDataLoader`
  operator, which reads the input dataset from `$globals.params.input_dataset`
- Every pipeline must end with one or more `oneVTKDataWriter` tasks that write 
  results to disk, specifying `output_dir` and `output_file_name`
- Multiple terminal writers are allowed for pipelines that produce 
  multiple output files

## Branching Rules

- A pipeline can branch from any intermediate task — multiple downstream tasks 
  can consume the same output
- For example, `IDPreprocess` output can feed into both `IDGeometryMapping` 
  and `IDSpanNormal` simultaneously
- Branches can later be merged using the `MergeDataSets` operator

## Operator Usage Rules

- Only operators from the provided operator list may be used in `from` fields
- Do not invent or assume operator names
- Each operator has a fixed set of required and optional parameters 
- Only use parameters defined in the operator description
- Parameter values must match the expected types (string, float, bool, list, etc.)
- When using a render filter like RenderServer, prioritize configuration from inputs over an external config file.

## Response Format Rules

- Output only the raw YAML content. > - DO NOT wrap the output in Markdown code blocks (e.g., no yaml or ).
- DO NOT include any introductory or explanatory text (e.g., no "Here is the workflow...").
