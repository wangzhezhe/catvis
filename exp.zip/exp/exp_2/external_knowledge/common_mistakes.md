Here are common mistakes you should avoid when writing a workflow:

## wrong using of MergeDataSets
**Wrong case:**
  IDMergeData:
    name: Merge Streamlines and High Entropy Volume
    from: MergeDataSets
    inputs:
      - data: $IDStreamline.tip_streamlines
      - data: $IDIsoVolume.high_entropy_region
    output: merged_visualization_data

**Reason:**
MergeDataSets is used to merge multiple data blocks in data field into one, we need to use FilterDict the case when merging data from output of different tasks.

**Correct case:**

  IDFilterDict:
    name: Merge Streamlines and High Entropy Volume
    from: FilterDict
    inputs:
      - data: [$IDStreamline.tip_streamlines, $IDIsoVolume.high_entropy_region]
    output: merged_visualization_data


## wrong setting of renderserver

**Wrong case:**
  IDRender:
    name: Render Visualization Results
    from: RenderServer
    inputs:
      - data:
          span_slice: $IDSlice.span_slice_data
          streamlines: $IDStreamline.streamline_data
          entropy: $IDIsoVolume.entropy_data
      - combine_into_single_image: true
    output: rendered_images

**Reason:**
RenderServer only support one data blocks in data field, we need to use FilterDict the case when merging data from output of different tasks. then give resutls of FilterDict to RenderServer.

**Correct case:**

  IDFilterDict:
    name: Merge Streamlines and High Entropy Volume
    from: FilterDict
    inputs:
      - data: [$IDSlice.span_slice_data, $IDStreamline.streamline_data,$IDIsoVolume.entropy_data]
    output: merged_visualization_data
  IDRender:
    name: Render Visualization Results
    from: RenderServer
    inputs:
      - data: $IDFilterDict.merged_visualization_data
      - combine_into_single_image: true
    output: rendered_images

## output data map to wrong writer
**wrong case**
After SpanNormal，we have added other filter directly

**Reason**
After SpanNormal, the data is still in the form of mult blocks, we need to merge them into one
before executing other parameters or write out as files.
For parameters not related with hub and shroud, such as Streamline, and oneVTKDataWriter, need to prcess the one data block. We need to call MergeDataSets before executing these parameters

**Correct case:**
  IDSpanNormal:
    name: 计算叶高
    from: SpanNormal
    inputs:
      - data: $IDPreprocess.IDPreprocess_output
      - hub: ["R1 Hub Step*"]
      - shroud: ["R1 Shroud Step*"]
      - origin: [0,0,0]
      - axis: [0,0,1]
    output: IDSpanNormal_output

  IDMergeDataSets:
    name: 数据合并
    from: MergeDataSets
    inputs:
      - data: $IDSpanNormal.IDSpanNormal_output
    output: IDMergeDataSets_output

  [...other filters]


## Compute the span by slice
**Wrong case**
After SpanNormal，we use slice to compute the span instead of using the isocontour 
  IDSpanNormal:
    name: Compute Span Normal
    from: SpanNormal
    inputs:
      - data: $IDPreprocess.preprocessed_data
      - hub: ["R1 Hub Step 300 Incr 0"]
      - shroud: ["R1 Shroud Step 300 Incr 0"]
      - origin: [0, 0, 0]
      - axis: [0, 0, 1]
    output: span_normal_data

  IDSlice:
    name: Extract 95% Span Slice
    from: Slice
    inputs:
      - data: $IDSpanNormal.span_normal_data
      - origin: [0, 0, 0.1]
      - normal: [0, 0, 1]
    output: span_slice_data


**Reason**
Wheh using the slice, we did not follow the geometry of the blade, using the isocontour can follow the geometry of the blade

**Correct case**
  IDSpanNormal:
    name: Compute Span Normal
    from: SpanNormal
    inputs:
      - data: $IDPreprocess.preprocessed_data
      - hub: ["R1 Hub Step 300 Incr 0"]
      - shroud: ["R1 Shroud Step 300 Incr 0"]
      - origin: [0, 0, 0]
      - axis: [0, 0, 1]
    output: span_normal_data

  IDIso:
    name: Extract 95% Span Slice
    from: IsoSurface
    inputs:
      - data: $IDSpanNormal.IDSpanNormal_output
      - variable_name: SpanNormal
      - isovalue: 0.95
    output: IDIso_output

## wrong using of FilterDict
**Wrong case**
  IDFilterDict:
    name: Merge Multiple Task Outputs for Rendering
    from: FilterDict
    inputs:
      - data: [$IDSlice.span_slice_data, $IDStreamline.streamline_data, $IDIsoVolume.entropy_data]
    output: merged_visualization_data
**Reason**
IDFilterDict only support two inputs, using FilterList to merge multiple data

**Correct case**
  IDMergeForRender:
    name: Merge Visualization Layers
    from: FilterList
    inputs:
      - data: [$IDIso95Span.span_iso_data, $IDStreamline.streamline_data, $IDIsoVolume.entropy_data]
      - flatten_nested: True
    output: combined_viz_data