import os
import json
import dotenv
from langchain_openai import ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate
from workflow_schema import DagIntentPlan

dotenv.load_dotenv()

class StateAwareDAGParser:
    """实验 4：生成结构化的有向无环图 (DAG) 并在任务中记录数据形态 (Data State)"""
    def __init__(self, context_files: list):
        self.llm_client = ChatOpenAI(
            base_url=os.getenv("CSTCLOUD_BASE_URL"),
            api_key=os.getenv("CSTCLOUD_API_KEY"),
            model="deepseek-v3:671b",
            temperature=0,
        )

        self.external_knowledge = self._load_external_knowledge(context_files)
        # 使用新定义的 DagIntentPlan Schema
        self.json_schema = json.dumps(DagIntentPlan.model_json_schema(), ensure_ascii=False, indent=2)

    def _load_external_knowledge(self, file_names):
        base_dir = os.path.dirname(os.path.abspath(__file__))
        texts = []
        for name in file_names:
            path = os.path.join(base_dir, "external_knowledge", name)
            if os.path.exists(path):
                with open(path, 'r', encoding='utf-8') as f:
                    texts.append(f.read())
        return "\n\n".join(texts)

    def parse_intent(self, user_query: str) -> dict:
        try:
            # 强化提示词：要求严格追踪 dependencies 和 output_data_state
            system_instruction = (
                f"{self.external_knowledge}\n\n"
                "---"
                "You are an expert visualization pipeline architect. Your task is to translate the user's query into a State-Aware Directed Acyclic Graph (DAG) plan.\n"
                "CRITICAL INSTRUCTIONS:\n"
                "1. You MUST define the topological connections using the 'dependencies' list (e.g., if Task B needs the output of Task A, add Task A's ID to Task B's dependencies).\n"
                "2. You MUST explicitly declare the structural morphology of the data after each step in 'output_data_state' (e.g., '3D Volume Mesh', '2D Slice', 'Vector Data').\n"
                "3. You must output a JSON object that strictly follows this JSON Schema:\n"
                f"{self.json_schema}\n"
                "Respond ONLY with the JSON object. Do not include any markdown formatting tags (like ```json or json) or explanations."
            )

            prompt_template = ChatPromptTemplate.from_messages([
                ("system", system_instruction.replace("{", "{{").replace("}", "}}")),
                ("user", "{user_query}")
            ])

            formatted_prompt = prompt_template.format_prompt(user_query=user_query)
            
            with open("m4_full_prompt_debug.txt", "w", encoding="utf-8") as f:
                f.write(formatted_prompt.to_string())

            print("🚀 正在调用 LLM 生成 State-Aware DAG Plan...")
            response = self.llm_client.invoke(formatted_prompt)
            
            raw_content = response.content.strip()
            if raw_content.startswith("```"):
                raw_content = raw_content.strip("`").replace("json", "", 1).strip()

            print(f"LLM Response received.")

            result_dict = json.loads(raw_content)

            # 通过 Pydantic 校验数据合法性
            validated_data = DagIntentPlan(**result_dict)

            return validated_data.model_dump()

        except Exception as e:
            print(f"❌ 实验4解析失败: {e}")
            if 'response' in locals():
                print(f"Raw Response: {response.content}")
            raise e