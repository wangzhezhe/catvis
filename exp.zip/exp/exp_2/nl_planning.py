import os
import json
import time
from pathlib import Path
import dotenv
from typing import List
from openai import OpenAI
from pydantic import BaseModel, Field
from langchain_openai import ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate

dotenv.load_dotenv()

# ==========================================
# 1. Pydantic Schemas 
# ==========================================
class Task(BaseModel):
    """(用于 SemanticParser) 定义单个工作流任务的结构"""
    task_id: str = Field(..., description="任务的唯一标识符，如 dataload, data_preprocess 等")
    task_description: str = Field(..., description="该任务的具体描述，比如数据导入，预处理，分析等")
    component_name: List[str] = Field(default=[], description="当前这一步可能会用到的组件类型名称")

class IntentPlan(BaseModel):
    """(用于 SemanticParser) 线性结构化序列"""
    task_sequence: List[Task] = Field(..., description="可执行的任务序列列表")

class DagTask(BaseModel):
    """(用于 StateAwareDAGParser) 有向无环图节点，包含数据状态感知"""
    task_id: str = Field(..., description="任务的唯一标识符，例如 task_1, task_2")
    task_description: str = Field(..., description="任务的具体描述")
    component_name: List[str] = Field(default=[], description="可能用到的组件类型名称")
    dependencies: List[str] = Field(
        default=[], 
        description="依赖的前序任务 task_id 列表。如果是直接读取原始数据，请填入 ['raw_data']"
    )
    output_data_state: str = Field(
        ..., 
        description="数据经过此Filter之后的结构或形态，例如：'3D Volume Mesh', '2D Surface Mesh', 'Image' 等"
    )

class DagIntentPlan(BaseModel):
    """(用于 StateAwareDAGParser) 包含数据流向和形态变化的 DAG"""
    task_sequence: List[DagTask] = Field(..., description="构成有向无环图的任务节点列表")


# ==========================================
# 2. Parsers (三种规划生成器)
# ==========================================
def get_llm_client():
    # 确保您的环境变量里已经设置了 DEEPSEEK_API_KEY
    api_key = os.environ.get('DEEPSEEK_API_KEY')
    if not api_key:
        raise ValueError("DEEPSEEK_API_KEY is missing or empty in environment variables.")
        
    return OpenAI(
        api_key=api_key,
        base_url="https://api.deepseek.com"
    )

class NLPlanParser:
    """方法 2: 生成自然语言计划 (封装为 JSON)"""
    def __init__(self, external_knowledge_text: str):
        self.llm_client = get_llm_client()
        self.external_knowledge = external_knowledge_text

    def parse_intent(self, user_query: str) -> dict:
        system_instruction = (
            f"{self.external_knowledge}\n\n"
            "---"
            "You are a visualization pipeline architect. Your task is to translate a user's visualization intent into a sequential, natural language execution plan.\n"
            "Instructions:\n"
            "1. Based on the user query and the provided knowledge, decide which visualization operators are needed.\n"
            "2. Briefly explain the purpose of each step.\n"
            "3. Output ONLY a numbered list of steps (Plain text/Markdown). Do NOT generate JSON, YAML, or any strict code structure."
        )
        
        response = self.llm_client.chat.completions.create(
            model="deepseek-chat",  # 指定您需要的模型名
            messages=[
                {"role": "system", "content": system_instruction},
                {"role": "user", "content": user_query}
            ],
            temperature=0,
            stream=False
        )
        
        # 提取回复文本
        content = response.choices[0].message.content.strip()
        # 统一输出为 JSON 格式
        return {"plan_type": "Natural_Language", "content": content}

class SemanticParser:
    """方法 3: 生成结构化任务序列"""
    def __init__(self, external_knowledge_text: str):
        self.llm_client = get_llm_client()
        self.external_knowledge = external_knowledge_text
        self.json_schema = json.dumps(IntentPlan.model_json_schema(), ensure_ascii=False, indent=2)

    def parse_intent(self, user_query: str) -> dict:
        system_instruction = (
            f"{self.external_knowledge}\n\n"
            "---"
            "You must output a JSON object that strictly follows this JSON Schema:\n"
            f"{self.json_schema}\n"
            "Respond ONLY with the JSON object. Do not include any markdown formatting tags (like ```json or json) or explanations."
        )
        
        # Deepseek API 支持强制 JSON 模式 (可选)，这里我们通过 Prompt 强制
        response = self.llm_client.chat.completions.create(
            model="deepseek-chat",
            messages=[
                {"role": "system", "content": system_instruction},
                {"role": "user", "content": user_query}
            ],
            temperature=0,
            stream=False
        )
        
        raw_content = response.choices[0].message.content.strip()
        # 清理可能存在的 Markdown 代码块标记
        if raw_content.startswith("```"):
            raw_content = raw_content.strip("`").replace("json", "", 1).strip()
        
        result_dict = json.loads(raw_content)
        # 通过 Pydantic 验证模型并导出
        return IntentPlan(**result_dict).model_dump()

class StateAwareDAGParser:
    """方法 4: 生成状态感知的有向无环图 (DAG) 规划"""
    def __init__(self, external_knowledge_text: str):
        self.llm_client = get_llm_client()
        self.external_knowledge = external_knowledge_text
        self.json_schema = json.dumps(DagIntentPlan.model_json_schema(), ensure_ascii=False, indent=2)

    def parse_intent(self, user_query: str) -> dict:
        system_instruction = (
            f"{self.external_knowledge}\n\n"
            "---"
            "You are an expert visualization pipeline architect. Your task is to translate the user's query into a State-Aware Directed Acyclic Graph (DAG) plan.\n"
            "CRITICAL INSTRUCTIONS:\n"
            "1. You MUST define the topological connections using the 'dependencies' list.\n"
            "2. You MUST explicitly declare the structural morphology of the data after each step in 'output_data_state' (e.g., '3D Volume Mesh', '2D Surface Mesh').\n"
            "3. You must output a JSON object that strictly follows this JSON Schema:\n"
            f"{self.json_schema}\n"
            "Respond ONLY with the JSON object. Do not include any markdown formatting tags."
        )
        
        response = self.llm_client.chat.completions.create(
            model="deepseek-chat",
            messages=[
                {"role": "system", "content": system_instruction},
                {"role": "user", "content": user_query}
            ],
            temperature=0,
            stream=False
        )
        
        raw_content = response.choices[0].message.content.strip()
        # 清理可能存在的 Markdown 代码块标记
        if raw_content.startswith("```"):
            raw_content = raw_content.strip("`").replace("json", "", 1).strip()
        
        result_dict = json.loads(raw_content)
        # 通过 Pydantic 验证模型并导出
        return DagIntentPlan(**result_dict).model_dump()

# ==========================================
# 3. 基础知识库映射与组合逻辑
# ==========================================
BASE_DIR = Path(__file__).parent
EXTERNAL_DIR = BASE_DIR / "external_knowledge"
CASE_DIR = BASE_DIR / "../../sample_vis_workflow"
RESULT_DIR = BASE_DIR / "results_stage1_plans"

# 将缩写严格映射到具体的文件名（一对一或一对多）
KNOWLEDGE_MAP = {
    "EX": ["prompt_wflow_example.md"],
    "R": ["prompt_wflow_rules.md"],
    "OD": ["filter_name_descriptions.json"],
    "PD": ["filter_parameter_descriptions.json"],
    "DATA": ["data_description.md"],
    "M": ["stage1_tree_descriptions.json"]
}

def load_external_knowledge(keys: list) -> str:
    """根据传入的 keys 列表，合并对应的文件内容并在文件前添加描述性标题"""
    if not isinstance(keys, list):
        keys = [keys]

    # 解析 ALL
    if "ALL" in [k.upper() for k in keys]:
        keys = list(KNOWLEDGE_MAP.keys())

    # 为每个配置类型定义对应的前缀标题
    title_map = {
        "EX": "## Workflow Examples",
        "R": "## Workflow Construction Rules",
        "OD": "## Operator Descriptions (JSON)",
        "PD": "## Operator and Parameter Descriptions (JSON)",
        "DATA": "## Description of the dataset used for visualization",
        "M": "## Intermediate Plan Task Descriptions"
    }

    prompt = ""
    loaded_files = set() # 防止重复加载
    
    for key in keys:
        if key not in KNOWLEDGE_MAP:
            print(f"  [Warning] Unknown knowledge key: {key}. Ignored.")
            continue
            
        # 获取对应的标题，如果没有定义则使用默认标题
        title = title_map.get(key, f"## {key} Knowledge")
        file_names = KNOWLEDGE_MAP[key]
        
        for name in file_names:
            if name in loaded_files:
                continue
                
            path = EXTERNAL_DIR / name
            if path.exists():
                prompt += f"{title}\n"
                prompt += path.read_text(encoding='utf-8') + "\n\n"
                loaded_files.add(name)
            else:
                print(f"  [Warning] File not found: {path}")
                
    return prompt

def find_query_file_and_open(case_dir: Path) -> str:
    for candidate in ["query.txt", "query.md"]:
        p = case_dir / candidate
        if p.exists():
            return p.read_text(encoding='utf-8')
    return ""


# ==========================================
# 4. 执行流程
# ==========================================
def run():
    RESULT_DIR.mkdir(exist_ok=True)
    
    # ==== 核心输入控制：定义每个 Case 本次实验加载的知识组合 ====
    # 列表代表一个整体配置（将列表内的知识合并后作为一次 Prompt 输入）
    BATCH_CONFIGS = {
        "hard-case1": ["EX", "OD", "M"] # 这是一次实验，包含三个模块
    }

    success_count = 0
    fail_count = 0
    fail_details = []

    for case_name, knowledge_keys in BATCH_CONFIGS.items():
        print(f"\n{'='*70}")
        print(f"Processing case: {case_name}")
        print(f"Loading Knowledge: {knowledge_keys}")
        print(f"{'='*70}")
        
        case_path = CASE_DIR / case_name
        if not case_path.exists():
            print(f"  [警告] Case路径不存在: {case_path}")
            continue
            
        query_contents = find_query_file_and_open(case_path)
        if not query_contents:
            print(f"  [警告] 未找到 query.txt")
            continue
            
        case_result_path = RESULT_DIR / case_name
        case_result_path.mkdir(exist_ok=True)
        
        # 将传入的 key 列表合并为一段完整的文本作为外部知识
        # 比如 ["EX", "OD", "M"] 会拼出 3 个文件的内容
        knowledge_text = load_external_knowledge(knowledge_keys)
        
        # 用合并好的知识文本初始化三个解析器
        parsers = {
            "Method2_NL_Plan": NLPlanParser(knowledge_text),
            "Method3_TaskSeq_Plan": SemanticParser(knowledge_text),
            "Method4_DAG_Plan": StateAwareDAGParser(knowledge_text)
        }
        
        # 为了区分不同的实验配置，将 keys 拼接作为文件名的一部分
        config_name_str = "ALL" if "ALL" in (k.upper() for k in (knowledge_keys if isinstance(knowledge_keys, list) else [knowledge_keys])) else "-".join(knowledge_keys)
        
        for method_name, parser in parsers.items():
            print(f"  -> Running {method_name}...")
            try:
                result_dict = parser.parse_intent(query_contents)
                
                # 保存 JSON，文件名包含配置组合
                output_file = case_result_path / f"{config_name_str}_{method_name}.json"
                with open(output_file, "w", encoding="utf-8") as f:
                    json.dump(result_dict, f, indent=4, ensure_ascii=False)
                
                success_count += 1
                time.sleep(1) # API 速率保护
                
            except Exception as e:
                print(f"     [Error] {method_name} failed: {e}")
                fail_details.append(f"{case_name} | {config_name_str} | {method_name}: {e}")
                fail_count += 1

    print(f"\n{'='*70}")
    print(f"批量处理完成统计:")
    print(f"成功生成的 Plan 数: {success_count}")
    print(f"失败的 Plan 数: {fail_count}")
    if fail_details:
        print("\n失败详情:")
        for detail in fail_details:
            print(f"  - {detail}")

if __name__ == "__main__":
    run()