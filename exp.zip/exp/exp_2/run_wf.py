import sys
import os 
import time

print(sys.path)

from gwlalg.workflow import workflow_composer
gwl_catalog = workflow_composer.Catalog()
start_time = time.perf_counter()
#config = './stage2_workflow_results/stage0_result_ground_truth.yaml'
#config = './stage2_workflow_results/test0_stage3_result_humanfix.yaml'
#config = './stage2_workflow_results/test1_stage3_result_humanfix.yaml'
config = './stage2_workflow_results/test2_stage3_result_humanfix.yaml'


# build the workflow
workflow = workflow_composer.Workflow(config)
# run the workflow
workflow.run()    
end_time = time.perf_counter()

elapsed_time = end_time - start_time
print(f"Elapsed time for whole tests: {elapsed_time:.4f} seconds")
