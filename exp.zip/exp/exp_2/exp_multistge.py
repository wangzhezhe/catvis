import os
import json
import time
from pathlib import Path
# 假设 run_exp_and_get_results.py 在父目录中，如果不在请调整 import
from run_exp_and_get_results import (
    load_external_knowledge, 
    generate_workflow_with_retry, 
    extract_yaml
)

# --- 路径配置 ---
BASE_ROOT = Path(r"C:\Users\~Low~\Desktop\文献\压气机\code\automaingworkflow")
CASE_DIR = BASE_ROOT / "sample_vis_workflow"
RESULT_DIR = BASE_ROOT / "exp" / "exp_2" / "results"
# 知识库路径
EXTERNAL_KNOWLEDGE_DIR = BASE_ROOT / "external_knowledge"

# --- 1. 硬编码系统提示词 ---
SYSTEM_PROMPTS = {
    "M1": "You are an expert in scientific visualization. Generate a valid, executable YAML workflow based on the user's intent. Calculate correct numerical thresholds based on data ranges. Output ONLY YAML code.",
    "M2": "You are an expert. Before generating YAML, write your thinking process under a ## Reasoning heading. Identify operators, variables, and parameter logic. Then output the YAML under ## Workflow.",
    "M3_S1": "You are a pipeline architect. Translate user intent into a numbered list of steps (Plan). Do NOT generate YAML code. Output ONLY the numbered list.",
    "M3_S2": "You are a code generator. Translate the provided Execution Plan into executable YAML. Strictly apply parameters from the provided knowledge base.",
    "M4_S1": "You are an architect. Translate user intent into a State-Aware DAG Plan. Format: NodeID, Operator, Purpose, Input, Output_Data_State.",
    "M4_S2": "You are a code generator. Translate the provided DAG Plan into executable YAML. Ensure topological consistency and correct variable mapping."
}

# --- 2. 方案知识库配置 ---
# 定义每个方案需要加载的知识模块
KNOWLEDGE_CONFIG = {
    "M1": ["example", "rules", "param_desc", "data_desc"],
    "M2": ["example", "rules", "param_desc", "data_desc"],
    "M3_S1": ["operator_desc", "data_desc"],
    "M3_S2": ["rules", "param_desc", "data_desc", "example"],
    "M4_S1": ["operator_desc", "data_desc"],
    "M4_S2": ["rules", "param_desc", "data_desc", "example"]
}

def get_sys_prompt(mode):
    return SYSTEM_PROMPTS.get(mode, "You are an assistant.")

def run_ablation():
    RESULT_DIR.mkdir(parents=True, exist_ok=True)
    TEST_CASES = ["hard-case3", "hard-case4", "hard-case5"] 

    for case_name in TEST_CASES:
        case_path = CASE_DIR / case_name / "query.txt"
        if not case_path.exists():
            print(f"  [Error] Query not found: {case_path}")
            continue
            
        query = case_path.read_text(encoding="utf-8")
        case_result_path = RESULT_DIR / f"{case_name}_ablation"
        case_result_path.mkdir(exist_ok=True)
        
        print(f"\n>>> Processing: {case_name}")

        # --- M1 ---
        sys_p = f"{get_sys_prompt('M1')}\n\n{load_external_knowledge(KNOWLEDGE_CONFIG['M1'])}"
        res, _ = generate_workflow_with_retry(query, sys_p, "M1", case_result_path)
        (case_result_path / "M1_workflow.yaml").write_text(extract_yaml(res), encoding="utf-8")

        # --- M2 ---
        sys_p = f"{get_sys_prompt('M2')}\n\n{load_external_knowledge(KNOWLEDGE_CONFIG['M2'])}"
        res, _ = generate_workflow_with_retry(query, sys_p, "M2", case_result_path)
        (case_result_path / "M2_full_response.md").write_text(res, encoding="utf-8")
        (case_result_path / "M2_workflow.yaml").write_text(extract_yaml(res), encoding="utf-8")

        # --- M3 ---
        sys_p1 = f"{get_sys_prompt('M3_S1')}\n\n{load_external_knowledge(KNOWLEDGE_CONFIG['M3_S1'])}"
        plan, _ = generate_workflow_with_retry(query, sys_p1, "M3_S1", case_result_path)
        (case_result_path / "M3_Plan.txt").write_text(plan, encoding="utf-8")
        
        sys_p2 = f"{get_sys_prompt('M3_S2')}\n\n{load_external_knowledge(KNOWLEDGE_CONFIG['M3_S2'])}"
        query2 = f"Query: {query}\n\nPlan: {plan}\n\nYAML:"
        res, _ = generate_workflow_with_retry(query2, sys_p2, "M3_S2", case_result_path)
        (case_result_path / "M3_workflow.yaml").write_text(extract_yaml(res), encoding="utf-8")

        # --- M4 ---
        sys_p1 = f"{get_sys_prompt('M4_S1')}\n\n{load_external_knowledge(KNOWLEDGE_CONFIG['M4_S1'])}"
        dag, _ = generate_workflow_with_retry(query, sys_p1, "M4_S1", case_result_path)
        (case_result_path / "M4_DAG.yaml").write_text(dag, encoding="utf-8")
        
        sys_p2 = f"{get_sys_prompt('M4_S2')}\n\n{load_external_knowledge(KNOWLEDGE_CONFIG['M4_S2'])}"
        query2 = f"Query: {query}\n\nDAG Plan: {dag}\n\nYAML:"
        res, _ = generate_workflow_with_retry(query2, sys_p2, "M4_S2", case_result_path)
        (case_result_path / "M4_workflow.yaml").write_text(extract_yaml(res), encoding="utf-8")

        print(f"  [Success] {case_name} done.")

if __name__ == "__main__":
    run_ablation()