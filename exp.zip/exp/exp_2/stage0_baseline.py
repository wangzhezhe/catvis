# Use prompt to generate workflow template
# There are four types of combination
# only using example in external_knowledge\prompt_wflow_example.md
# using example in external_knowledge\prompt_wflow_example.md+external_knowledge\prompt_wflow_rules.md
# using example in external_knowledge\prompt_wflow_example.md+external_knowledge\prompt_wflow_rules.md+filter_name_descriptions.json
# using example in external_knowledge\prompt_wflow_example.md+external_knowledge\prompt_wflow_rules.md+filter_parameter_descriptions.json
# using .env file CSTCLOUD_API_KEY to get api key and CSTCLOUD_BASE_URL to get base url
# go through case test folder and execute case by case

import os
import json
from pathlib import Path
from openai import OpenAI
from dotenv import load_dotenv
from pathlib import Path
from langchain_openai import ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate
load_dotenv()

model_client = "aihubmix"
if model_client=="aihubmix":
    model = "DeepSeek-V3"
    llm_client = ChatOpenAI(
        base_url=os.getenv("AIHUBMIX_BASE_URL"),
        api_key=os.getenv("AIHUBMIX_API_KEY"),
        model=model,
        temperature=0,
    )

else:
    llm_client = ChatOpenAI(
        base_url=os.getenv("CSTCLOUD_BASE_URL"),
        api_key=os.getenv("CSTCLOUD_API_KEY"),
        model="deepseek-v3:671b",
        temperature=0,
    )


BASE_DIR = Path(__file__).parent.parent
print("base dir:",BASE_DIR)

EXTERNAL_DIR = BASE_DIR / "exp_1" / "external_knowledge"

def get_selected_configs(selected_config="ALL"):
    """根据 selected_config 返回要运行的配置"""
    # 如果是字符串 "ALL"，返回全部配置
    if selected_config == "ALL":
        print(f"将运行全部 {len(CONFIGS)} 种配置: {list(CONFIGS.keys())}")
        return CONFIGS
    
    # 如果是字符串且是单个配置名
    elif isinstance(selected_config, str) and selected_config in CONFIGS:
        print(f"将运行单个配置: {selected_config}")
        return {selected_config: CONFIGS[selected_config]}
    
    # 如果是列表，返回列表中的配置
    elif isinstance(selected_config, list):
        selected = {}
        for config_name in selected_config:
            if config_name in CONFIGS:
                selected[config_name] = CONFIGS[config_name]
            else:
                print(f"警告: 无效的配置 '{config_name}'，跳过")
        
        if not selected:
            print(f"警告: 没有有效的配置，将使用全部配置")
            return CONFIGS
        
        print(f"将运行 {len(selected)} 种配置: {list(selected.keys())}")
        return selected
    
    # 其他情况，默认返回全部
    else:
        print(f"警告: 无效的配置选择 '{selected_config}'，将使用全部配置")
        print(f"可用配置: {list(CONFIGS.keys())}")
        return CONFIGS
    
print("EXTERNAL_DIR is:",EXTERNAL_DIR)
def load_external_knowledge(components: list[str]) -> str:
    prompt = ""
    
    if "example" in components:
        example_path = EXTERNAL_DIR / "prompt_wflow_example.md"
        if example_path.exists():
            prompt += "## Workflow Examples\n"
            # 显式转换确保万无一失，虽然 read_text 理论上返回 str
            content = str(example_path.read_text(encoding="utf-8"))
            prompt += content + "\n\n"
        else:
            print(f"Warning: {example_path} not found.")

    if "rules" in components:
        rules_path = EXTERNAL_DIR / "prompt_wflow_rules.md"
        prompt += "## Workflow Construction Rules\n"
        prompt += rules_path.read_text(encoding="utf-8") + "\n\n"

    if "operator_desc" in components:
            desc_path = EXTERNAL_DIR / "filter_name_descriptions.json"
            # 直接读取文件内容并追加
            prompt += "## Operator Descriptions (JSON)\n"
            prompt += desc_path.read_text(encoding="utf-8") + "\n\n"

    if "param_desc" in components:
        param_path = EXTERNAL_DIR / "filter_parameter_descriptions.json"
        # 直接读取文件内容并追加
        prompt += "## Operator and Parameter Descriptions (JSON)\n"
        prompt += param_path.read_text(encoding="utf-8") + "\n\n"

    if "data_desc" in components:
        param_path = EXTERNAL_DIR / "data_description.md"
        # 直接读取文件内容并追加
        prompt += "## Description of the dataset used for visualization\n"
        prompt += param_path.read_text(encoding="utf-8") + "\n\n"

    return prompt



import time
def generate_workflow(query: str, system_prompt: str, config_name: str = "default", case_result_path: Path = None) -> tuple[str, str]:
    """
    调用 LLM 生成 workflow，并返回 (正式内容, 思考过程)
    """
    try:
        start_time = time.time()
        response = client.chat.completions.create(
            model=MODEL,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": query},
            ],
            temperature=0,  # 确保结果一致性
            stream=False
        )

        end_time = time.time()
        duration = end_time - start_time

        message_obj = response.choices[0].message
        
        # 1. 提取正式回答
        content = message_obj.content or ""
        
        # 2. 提取思考过程 (支持 DeepSeek 系列模型的 reasoning_content)
        reasoning = getattr(message_obj, 'reasoning_content', "")

        usage = response.usage # 包含 prompt_tokens, completion_tokens 等
        print(f"    Usage: {usage}")

        # 3. 如果提供了路径，将思考过程单独存证，方便分析模型为何这样构造 Workflow
        if case_result_path:

            # 3. 记录 Usage 和耗时 (修正覆盖问题和类型问题)
            usage_log_path = case_result_path / f"{config_name}_usage.log"
            usage_info = (
                f"Model: {MODEL}\n"
                f"Prompt Tokens: {usage.prompt_tokens}\n"  # the tokem used for input
                f"Completion Tokens: {usage.completion_tokens}\n" # the token used for output
                f"Total Tokens: {usage.total_tokens}\n"
                f"Duration: {duration:.2f}s\n"
            )
            usage_log_path.write_text(usage_info, encoding="utf-8")


        if case_result_path and reasoning:
            log_file = case_result_path / f"{config_name}_reasoning.log"
            log_file.write_text(reasoning, encoding="utf-8")
            
            print(f"    Thinking process saved to {log_file.name}")

        

        return content, reasoning

    except Exception as e:
        print(f"    Error during API call: {e}")
        return "", ""


def get_unique_dir(base_path: Path) -> Path:
    """如果目录已存在，则添加 _1, _2 等后缀"""
    if not base_path.exists():
        return base_path
    counter = 1
    while True:
        new_path = base_path.with_name(f"{base_path.name}_{counter}")
        if not new_path.exists():
            return new_path
        counter += 1

def extract_yaml(raw: str) -> str:
    """从LLM返回内容中提取yaml代码块"""
    if "```yaml" in raw:
        return raw.split("```yaml")[1].split("```")[0].strip()
    elif "```" in raw:
        return raw.split("```")[1].split("```")[0].strip()
    return raw.strip()


def find_query_file_and_open(case_dir: Path) -> Path | None:
    """在case目录中找query文件"""
    for candidate in ["query.txt", "query.md"]:
        p = case_dir / candidate
        if p.exists():
            query_path=p
            return query_path.read_text(encoding='utf-8')
    return ""


query_file_name = Path("query_simple.txt")
def run():
    # load external information
    config_list = ["example", "rules", "param_desc","data_desc"]
    system_prompt=""  
    for config in config_list:
        system_prompt += load_external_knowledge(config)
    
    # load the query
    query_contents = query_file_name.read_text(encoding='utf-8')

    print("Query:",query_contents)

    prompt_template = ChatPromptTemplate.from_messages([
        ("system", system_prompt.replace("{", "{{").replace("}", "}}")),
        ("user", query_contents)
    ])
    
    formatted_prompt = prompt_template.format_prompt()

    # 5. 保存 Prompt 到文件 (Debug 用)
    with open("stage0_prompt_debug.txt", "w", encoding="utf-8") as f:
        f.write(formatted_prompt.to_string())
    print("✅ Prompt 已保存至 stage0_prompt_debug.txt")


    invoke = True
    if invoke:
        print("🚀 正在调用 LLM...")
        start_time = time.time()
        # 注意：LangChain invoke 返回的是 BaseMessage 对象
        response = llm_client.invoke(formatted_prompt)
        
        duration = time.time() - start_time

        # --- 5. 提取数据 (Content, Reasoning, Usage) ---
        content = response.content
        
        # 提取 DeepSeek 特有的推理内容 (LangChain 映射在 additional_kwargs 或 response_metadata 中)
        reasoning = response.additional_kwargs.get("reasoning_content", "")
        
        # 提取 Usage 信息 (LangChain 存放在 response_metadata)
        usage = response.response_metadata.get("token_usage", {})
        prompt_tokens = usage.get("prompt_tokens", 0)
        completion_tokens = usage.get("completion_tokens", 0)
        total_tokens = usage.get("total_tokens", 0)

        # --- 6. 保存所有结果 ---
        # 保存正式结果
        Path(f"stage0_result.yaml").write_text(content, encoding="utf-8")

        # 保存推理过程
        if reasoning:
            Path(f"stage0_result_reasoning.log").write_text(reasoning, encoding="utf-8")

        # 保存 Usage 数据 (模仿你提供的逻辑)
        usage_info = (
            f"Model: {llm_client.model_name}\n"
            f"Prompt Tokens: {prompt_tokens}\n"
            f"Completion Tokens: {completion_tokens}\n"
            f"Total Tokens: {total_tokens}\n"
            f"Duration: {duration:.2f}s\n"
        )
        Path("stage0_usage.log").write_text(usage_info, encoding="utf-8")

        print(f"✅ 完成！Tokens: {total_tokens}, 耗时: {duration:.2f}s")


if __name__ == "__main__":
    run()