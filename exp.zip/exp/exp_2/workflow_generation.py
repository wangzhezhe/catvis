import os
import json
from openai import OpenAI
from pathlib import Path
import dotenv 

dotenv.load_dotenv()
# 定义知识库映射字典
KNOWLEDGE_MAP = {
    "EX": ["prompt_wflow_example.md"],
    "R": ["prompt_wflow_rules.md"],
    "OD": ["filter_name_descriptions.json"],
    "PD": ["filter_parameter_descriptions.json"],
    "DATA": ["data_description.md"],
    "M": ["stage1_tree_descriptions.json"]
}

# 为每个配置类型定义对应的前缀标题
TITLE_MAP = {
    "EX": "## Workflow Examples",
    "R": "## Workflow Construction Rules",
    "OD": "## Operator Descriptions (JSON)",
    "PD": "## Operator and Parameter Descriptions (JSON)",
    "DATA": "## Description of the dataset used for visualization",
    "M": "## Intermediate Plan Task Descriptions"
}

class WorkflowGenerator:
    def __init__(self, knowledge_keys: list):
        """
        初始化生成器
        :param knowledge_keys: 外部知识组合，例如 ["EX", "R", "PD", "DATA"] 或 "ALL"
        """
        api_key = os.environ.get('DEEPSEEK_API_KEY')
        if not api_key:
            raise ValueError("DEEPSEEK_API_KEY is missing or empty in environment variables.")
        
        self.llm_client = OpenAI(
            api_key=api_key,
            base_url="https://api.deepseek.com"
        )
        
        self.base_dir = Path(__file__).parent
        # 加载配置好的知识库文件
        self.external_knowledge = self._load_external_knowledge(knowledge_keys)

    def _load_external_knowledge(self, keys: list) -> str:
        """根据传入的 keys 列表，合并对应的文件内容并在文件前添加描述性标题"""
        if not isinstance(keys, list):
            keys = [keys]

        if "ALL" in [k.upper() for k in keys]:
            keys = list(KNOWLEDGE_MAP.keys())

        prompt = ""
        loaded_files = set() # 防止重复加载
        
        for key in keys:
            if key not in KNOWLEDGE_MAP:
                print(f"  [Warning] Unknown knowledge key: {key}. Ignored.")
                continue
                
            title = TITLE_MAP.get(key, f"## {key} Knowledge")
            file_names = KNOWLEDGE_MAP[key]
            
            for name in file_names:
                if name in loaded_files:
                    continue
                    
                path = self.base_dir / "external_knowledge" / name
                if path.exists():
                    prompt += f"{title}\n"
                    prompt += path.read_text(encoding='utf-8') + "\n\n"
                    loaded_files.add(name)
                else:
                    print(f"  [Warning] File not found: {path}")
                    
        return prompt

    def generate(self, original_query: str, plan_data) -> str:
        """
        核心方法：将 Plan 作为动态上下文，结合静态知识库生成工作流
        :param original_query: 用户的原始查询文本
        :param plan_data: Stage 1 生成的计划 (可以是 dict 也可以是字符串)
        """
        system_prompt = (
            "You are a Visualization Workflow Generator.\n\n"
            f"{self.external_knowledge}\n\n"
            "Task: Generate a precise YAML workflow based on the provided 'Intermediate Plan' and 'Original Query'.\n"
            "Constraints:\n"
            "1. Map the Plan nodes to the detailed parameters defined in the Knowledge Base.\n"
            "2. Ensure parameter types and dependencies are strictly consistent with the Parameter Descriptions.\n"
            "3. If the Plan contradicts the Parameter Schema in the Knowledge Base, prioritize the Parameter Schema.\n"
            "4. Output ONLY the valid YAML code block starting with ```yaml and ending with ```."
        )

        # 兼容自然语言计划 (M2/M3的纯文本形式) 和 结构化计划 (M4的字典形式)
        if isinstance(plan_data, dict):
            # 如果是 NLPlanParser 封装的那种带有 plan_type 的字典
            if plan_data.get("plan_type") == "Natural_Language":
                plan_content = plan_data.get("content", "")
            else:
                plan_content = json.dumps(plan_data, indent=2, ensure_ascii=False)
        else:
            plan_content = str(plan_data)

        user_prompt = (
            f"Original Query: {original_query}\n\n"
            f"Intermediate Plan:\n{plan_content}"
        )

        response = self.llm_client.chat.completions.create(
            model="deepseek-chat",
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt}
            ],
            temperature=0,
            stream=False
        )
        
        return self._extract_yaml(response.choices[0].message.content)

    def _extract_yaml(self, text: str) -> str:
        """从 LLM 返回的文本中提取 YAML 代码块"""
        if "```yaml" in text:
            return text.split("```yaml")[1].split("```")[0].strip()
        elif "```" in text:
            return text.split("```")[1].split("```")[0].strip()
        return text.strip()
    
def main():
    import glob
    from pathlib import Path

    # 配置路径
    input_dir = Path(r"C:\Users\~Low~\Desktop\文献\压气机\code\automaingworkflow\exp\exp_2\results_stage1_plans\hard-case1")
    case_dir = Path(r"C:\Users\~Low~\Desktop\文献\压气机\code\automaingworkflow\sample_vis_workflow\hard-case1")
    output_dir = input_dir / "generated_workflows"
    output_dir.mkdir(exist_ok=True)

    # 查找所有 JSON 计划文件
    json_files = list(input_dir.glob("*_Plan.json"))

    if not json_files:
        print(f"No JSON plan files found in {input_dir}")
        return

    print(f"Found {len(json_files)} plan files.")

    # 读取原始查询（从 case 目录下的 query.txt 或 query.md）
    def get_original_query(case_path: Path) -> str:
        """从 case 目录读取原始查询"""
        for candidate in ["query.txt", "query.md"]:
            query_file = case_path / candidate
            if query_file.exists():
                return query_file.read_text(encoding='utf-8')
        return ""

    original_query = get_original_query(case_dir)
    if not original_query:
        print(f"Warning: No query file found in {case_dir}, using default query.")
        original_query = "Generate visualization workflow for the given data."

    # 初始化生成器（知识组合应与生成 plan 时使用的配置一致）
    # 根据 BATCH_CONFIGS 中的配置，hard-case1 使用的是 ["EX", "OD", "M"]
    generator = WorkflowGenerator(knowledge_keys=["EX", "OD","PD", "DATA"])

    for json_path in json_files:
        print(f"\nProcessing: {json_path.name}")

        # 读取计划文件
        with open(json_path, "r", encoding="utf-8") as f:
            plan_data = json.load(f)

        # 生成工作流
        try:
            yaml_output = generator.generate(original_query, plan_data)

            # 构建输出文件名：将 _Plan.json 替换为 _workflow.yaml
            output_filename = json_path.name.replace("_Plan.json", "_workflow.yaml")
            output_path = output_dir / output_filename

            # 保存 YAML 文件
            with open(output_path, "w", encoding="utf-8") as f:
                f.write(yaml_output)

            print(f"  ✓ Workflow saved to: {output_path}")

        except Exception as e:
            print(f"  ✗ Failed to generate workflow: {e}")

    print("\nAll workflows generated successfully.")

if __name__ == "__main__":
    main()