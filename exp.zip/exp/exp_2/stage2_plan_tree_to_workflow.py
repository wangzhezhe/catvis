import os
import json
from semantic_parser import SemanticParser
from langchain_openai import ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate
import time
from pathlib import Path
def main():

    # 文件路径定义
    path_operators = "selected_operator_knowledge.json"
    path_plan_tree = "query_simple_intent_tree.json"
    path_workflow_rule = os.path.join("..", "exp_1", "external_knowledge", "prompt_wflow_rules.md")
    path_data_info = os.path.join("..", "exp_1", "external_knowledge", "data_description.md")
    examples_info = os.path.join("..", "exp_1", "external_knowledge", "prompt_wflow_example.md")
    common_mistakes_path = os.path.join("..", "exp_2", "external_knowledge", "common_mistakes.md")

    # 1. 读取文件并转换为字符串
    # 对于 JSON，重新 dump 可以保证格式整洁并过滤非必要字符
    with open(path_plan_tree, 'r', encoding='utf-8') as f:
        plan_tree_content = json.dumps(json.load(f), indent=2, ensure_ascii=False)

    with open(path_operators, 'r', encoding='utf-8') as f:
        operators_content = json.dumps(json.load(f), indent=2, ensure_ascii=False)

    with open(path_workflow_rule, 'r', encoding='utf-8') as f:
        workflow_rules_content = f.read()

    with open(path_data_info, 'r', encoding='utf-8') as f:
        workflow_data_content = f.read()

    with open(examples_info, 'r', encoding='utf-8') as f:
        examples_info_contents = f.read()

    with open(common_mistakes_path, 'r', encoding='utf-8') as f:
        common_mistakes_info = f.read()

    # 2. 按照指定顺序组装 System Prompt
    system_instruction = f"""
    # Role
    You are a Workflow Synthesis Engine. Your task is to generate a formal workflow by mapping user intents to specific operator schemas.

    # Context Data

    ## 1. PLAN TREE (Intent & Logic)
    This is the skeletal structure of the task. 
    **CRITICAL WARNING**: The keys and values in the 'parameters' field here are purely SEMANTIC (placeholders). Do NOT use these keys in the final output.
    ---
    {plan_tree_content}
    ---

    ## 2. SELECTED OPERATORS (Technical Ground Truth)
    This is the ONLY source for valid parameter names and data types. 
    When you see a node in the Plan Tree, find its corresponding operator here and use the defined parameter keys.
    ---
    {operators_content}
    ---

    ## 3. WORKFLOW RULES (Output Specification)
    Follow these syntax rules for the final generation.
    ---
    {workflow_rules_content}
    ---

    ## 4. DATA DESCRIPTION
    The information of processing data is provided as follows.

    ---
    {workflow_data_content}
    ---

    ## 5. OUTPUT EXMPLAES

    ---
    {examples_info_contents}
    ---
    
    ## 6. COMMON MISTAKES

    ---
    {common_mistakes_info}
    ---

    # Mapping Instructions
    1. **Identify Node**: Look at a node in [PLAN TREE].
    2. **Semantic Interpretation**: Understand what the semantic parameters in that node are trying to achieve.
    3. **Formal Mapping**: Find the equivalent operator in [SELECTED OPERATORS]. Map the semantic intent to the **actual keys** defined in the operator's schema.
    4. **Final Assembly**: Construct the node according to [WORKFLOW RULES].
    5. Following [DATA DESCRIPTION] for variables names in the dataset
    6. Following [OUTPUT EXMPLAES] for output format

    # Constraints
    - NEVER use a parameter key that does not exist in [SELECTED OPERATORS].
    - The [PLAN TREE] is a guide for "what to do", but [SELECTED OPERATORS] is the manual for "how to write it".
    - Avoid mistakes listed in [COMMON MISTAKES].
    - Output only the final workflow using english
    """

    #- Output only the final workflow template wrapped by ```yaml, using english

    prompt_template = ChatPromptTemplate.from_messages([
        ("system", system_instruction.replace("{", "{{").replace("}", "}}")),
        ("user", "Generate the final workflow template now.")
    ])
    
    formatted_prompt = prompt_template.format_prompt()

    # 5. 保存 Prompt 到文件 (Debug 用)
    with open("stage2_full_workflow_prompt_debug.txt", "w", encoding="utf-8") as f:
        f.write(formatted_prompt.to_string())
    print("✅ Prompt 已保存至 full_workflow_prompt_debug.txt")


    start_time = time.time()
    
    model_client = "aihubmix"
    if model_client=="aihubmix":
        model = "DeepSeek-V3"
        llm_client = ChatOpenAI(
            base_url=os.getenv("AIHUBMIX_BASE_URL"),
            api_key=os.getenv("AIHUBMIX_API_KEY"),
            model=model,
            temperature=0,
        )

    else:
        llm_client = ChatOpenAI(
            base_url=os.getenv("CSTCLOUD_BASE_URL"),
            api_key=os.getenv("CSTCLOUD_API_KEY"),
            model="deepseek-v3:671b",
            temperature=0,
        )

    invoke = True
    if invoke:
        print("🚀 正在调用 LLM...")
        # 注意：LangChain invoke 返回的是 BaseMessage 对象
        response = llm_client.invoke(formatted_prompt)
        
        duration = time.time() - start_time

        # --- 5. 提取数据 (Content, Reasoning, Usage) ---
        content = response.content
        
        # 提取 DeepSeek 特有的推理内容 (LangChain 映射在 additional_kwargs 或 response_metadata 中)
        reasoning = response.additional_kwargs.get("reasoning_content", "")
        
        # 提取 Usage 信息 (LangChain 存放在 response_metadata)
        usage = response.response_metadata.get("token_usage", {})
        prompt_tokens = usage.get("prompt_tokens", 0)
        completion_tokens = usage.get("completion_tokens", 0)
        total_tokens = usage.get("total_tokens", 0)

        # --- 6. 保存所有结果 ---
        # 保存正式结果
        Path(f"stage2_result.yaml").write_text(content, encoding="utf-8")

        # 保存推理过程
        if reasoning:
            Path(f"stage2_result_reasoning.log").write_text(reasoning, encoding="utf-8")

        # 保存 Usage 数据 (模仿你提供的逻辑)
        usage_info = (
            f"Model: {llm_client.model_name}\n"
            f"Prompt Tokens: {prompt_tokens}\n"
            f"Completion Tokens: {completion_tokens}\n"
            f"Total Tokens: {total_tokens}\n"
            f"Duration: {duration:.2f}s\n"
        )
        Path("stage2_usage.log").write_text(usage_info, encoding="utf-8")

        print(f"✅ 完成！Tokens: {total_tokens}, 耗时: {duration:.2f}s")



if __name__ == "__main__":
    main()