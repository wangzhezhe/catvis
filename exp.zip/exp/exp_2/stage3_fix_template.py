import os
import json
from semantic_parser import SemanticParser
from langchain_openai import ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate
import time
from pathlib import Path
def main():

    # 文件路径定义
    original_template_path = os.path.join("..", "exp_2","stage2_result.yaml")
    common_mistakes_path = os.path.join("..", "exp_2", "external_knowledge", "common_mistakes.md")

    # 1. 读取文件并转换为字符串
    # 对于 JSON，重新 dump 可以保证格式整洁并过滤非必要字符


    with open(original_template_path, 'r', encoding='utf-8') as f:
        original_template_contents = f.read()

    with open(common_mistakes_path, 'r', encoding='utf-8') as f:
        common_mistakes_info = f.read()

    # 2. 按照指定顺序组装 System Prompt
    system_instruction = f"""
## ORIGINAL TEMPLATE
---
{original_template_contents}
---
## COMMON MISTAKES
---
{common_mistakes_info}
---
Fix the workflow template [ORIGINAL TEMPLATE] by according to [COMMON MISTAKES]
"""

    #- Output only the final workflow template wrapped by ```yaml, using english

    prompt_template = ChatPromptTemplate.from_messages([
        ("system", system_instruction.replace("{", "{{").replace("}", "}}")),
        ("user", "Generate the final workflow template, output clean yaml without other explanations or ```yaml ")
    ])
    
    formatted_prompt = prompt_template.format_prompt()

    # 5. 保存 Prompt 到文件 (Debug 用)
    with open("stage3_full_workflow_prompt_debug.txt", "w", encoding="utf-8") as f:
        f.write(formatted_prompt.to_string())
    print("✅ Prompt 已保存至 stage3_full_workflow_prompt_debug.txt")


    start_time = time.time()
    
    model_client = "aihubmix"
    if model_client=="aihubmix":
        model = "DeepSeek-V3"
        llm_client = ChatOpenAI(
            base_url=os.getenv("AIHUBMIX_BASE_URL"),
            api_key=os.getenv("AIHUBMIX_API_KEY"),
            model=model,
            temperature=0,
        )

    else:
        llm_client = ChatOpenAI(
            base_url=os.getenv("CSTCLOUD_BASE_URL"),
            api_key=os.getenv("CSTCLOUD_API_KEY"),
            model="deepseek-v3:671b",
            temperature=0,
        )

    invoke = True
    if invoke:
        print("🚀 正在调用 LLM...")
        # 注意：LangChain invoke 返回的是 BaseMessage 对象
        response = llm_client.invoke(formatted_prompt)
        
        duration = time.time() - start_time

        # --- 5. 提取数据 (Content, Reasoning, Usage) ---
        content = response.content
        
        # 提取 DeepSeek 特有的推理内容 (LangChain 映射在 additional_kwargs 或 response_metadata 中)
        reasoning = response.additional_kwargs.get("reasoning_content", "")
        
        # 提取 Usage 信息 (LangChain 存放在 response_metadata)
        usage = response.response_metadata.get("token_usage", {})
        prompt_tokens = usage.get("prompt_tokens", 0)
        completion_tokens = usage.get("completion_tokens", 0)
        total_tokens = usage.get("total_tokens", 0)

        # --- 6. 保存所有结果 ---
        # 保存正式结果
        Path(f"stage3_result.yaml").write_text(content, encoding="utf-8")

        # 保存推理过程
        if reasoning:
            Path(f"stage3_result_reasoning.log").write_text(reasoning, encoding="utf-8")

        # 保存 Usage 数据 (模仿你提供的逻辑)
        usage_info = (
            f"Model: {llm_client.model_name}\n"
            f"Prompt Tokens: {prompt_tokens}\n"
            f"Completion Tokens: {completion_tokens}\n"
            f"Total Tokens: {total_tokens}\n"
            f"Duration: {duration:.2f}s\n"
        )
        Path("stage3_usage.log").write_text(usage_info, encoding="utf-8")

        print(f"✅ 完成！Tokens: {total_tokens}, 耗时: {duration:.2f}s")



if __name__ == "__main__":
    main()