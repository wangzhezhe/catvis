import os
import json
import dotenv
from langchain_openai import ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate
from workflow_schema import IntentPlan

dotenv.load_dotenv()

class SemanticParser:
    def __init__(self, context_files: list):



        model_client = "aihubmix"
        if model_client=="aihubmix":
            model = "DeepSeek-V3"
            self.llm_client = ChatOpenAI(
                base_url=os.getenv("AIHUBMIX_BASE_URL"),
                api_key=os.getenv("AIHUBMIX_API_KEY"),
                model=model,
                temperature=0,
            )

        else:
            self.llm_client = ChatOpenAI(
                base_url=os.getenv("CSTCLOUD_BASE_URL"),
                api_key=os.getenv("CSTCLOUD_API_KEY"),
                model="deepseek-v3:671b",
                temperature=0,
            )

        # 加载静态外部知识
        self.external_knowledge = self._load_external_knowledge(context_files)
        
        # 获取 IntentPlan 的 JSON Schema 字符串
        # model_json_schema() 是 Pydantic V2 的方法，V1 请使用 .schema_json()
        self.json_schema = json.dumps(IntentPlan.model_json_schema(), ensure_ascii=False, indent=2)

    def _load_external_knowledge(self, file_names):
        base_dir = os.path.dirname(os.path.abspath(__file__))
        texts = []
        for name in file_names:
            path = os.path.join(base_dir, "external_knowledge", name)
            if os.path.exists(path):
                with open(path, 'r', encoding='utf-8') as f:
                    texts.append(f.read())
        return "\n\n".join(texts)

    def parse_intent(self, user_query: str) -> dict:
        """
        通过 Prompt 强制 LLM 输出符合 Schema 的 JSON 字符串
        """
        try:
            # 构建系统提示词，加入 Schema 约束
            system_instruction = (
                "Here are capabilities of all components we could use in a library to compose the workflow, use these components when generating intent tree\n"
                f"{self.external_knowledge}\n\n"
                "---"
                "You must output a JSON object that strictly follows this JSON Schema:\n"
                f"{self.json_schema}\n"
                "Respond ONLY with the JSON object. Do not include any markdown formatting tags (like ```json or json) or explanations."
            )

            prompt_template = ChatPromptTemplate.from_messages([
                ("system", system_instruction.replace("{", "{{").replace("}", "}}")),
                ("user", "{user_query}")
            ])


            formatted_prompt = prompt_template.format_prompt(user_query=user_query)
            
            with open("stage1_full_prompt_debug.txt", "w", encoding="utf-8") as f:
                # 现在的 formatted_prompt 是一个 PromptValue 对象，它拥有 to_string() 方法
                f.write(formatted_prompt.to_string())

            # 4. 调用 LLM
            # 注意：这里直接传 formatted_prompt 即可，或者保持 chain 结构
            response = self.llm_client.invoke(formatted_prompt)
            
            # 5. 后置处理与解析
            raw_content = response.content.strip()
            if raw_content.startswith("```"):
                raw_content = raw_content.strip("`").replace("json", "", 1).strip()

            print(f"LLM Response: {raw_content}")

            # 解析 JSON 字符串
            result_dict = json.loads(raw_content)

            # (可选) 重新通过 Pydantic 校验，确保数据完整性
            validated_data = IntentPlan(**result_dict)

            return validated_data.model_dump()

        except Exception as e:
            print(f"❌ 语义解析失败: {e}")
            # 打印原始内容方便排查
            if 'response' in locals():
                print(f"Raw Response: {response.content}")
            raise e