from typing import List, Dict, Any
from pydantic import BaseModel, Field

class Task(BaseModel):
    """定义单个工作流任务的结构"""
    task_id: str = Field(..., description="任务的唯一标识符，one word description of the task, such as dataload, data_preprocess, sreamline_analysis, or export. etc")
    task_description: str = Field(..., description="该任务的具体描述， 比如数据导入，数据预处理，分析，或者导出等等")
    potential_component_names: List[str] = Field(default=[], description="当前这一步可能会用到的组件库中的组件类型名称,可能会使用到多个相关的组件")
    # dependencies: List[str] = Field(default=[], description="依赖的前序任务ID列表")
    potential_parameters: Dict[str, Any] = Field(
         default={}, 
         description="组件可能需要的具体参数，键值对形式"
    )

class IntentPlan(BaseModel):
    # """
    # 这是 Agent 的核心技能：将自然语言请求转化为结构化工作流方案。
    # """
    # original_query: str = Field(..., description="用户的原始查询内容")
    # identified_intent: str = Field(..., description="识别出的核心分析目标")
    # intent_type: str = Field(..., description="分析类型，如：特征追踪、时空对比、可视化生成")
    
    # explicit_conditions: Dict[str, str] = Field(
    #     description="明确提取出的限制条件，如时间、空间范围"
    # )
    
    # implicit_conditions: Dict[str, Dict[str, str]] = Field(
    #     description="推测出的隐含条件，包含推测原因"
    # )
    
    # reasoning_chain: str = Field(..., description="生成此方案的完整思维链推导过程")
    
    task_sequence: List[Task] = Field(..., description="可执行的任务序列列表")