import matplotlib.pyplot as plt
import numpy as np

# 原始数据准备
cases = ["baseline", "test1_stage2", "test1_stage3", "test2_stage2", "test2_stage3", "tets3_stage2", "test3_stage3"]
added_tasks = [2, 1, 0, 2, 1, 1, 0]
removed_tasks = [0, 2, 0, 2, 3, 3, 2]
modified_tasks = [5, 2, 1, 1, 1, 1, 1]
modified_lines = [10, 3, 2, 1, 1, 1, 1]
connection_changed = [5, 3, 0, 5, 4, 4, 1]

# 计算平均每项任务修改的行数 (Avg lines / Modified task)
avg_lines = [(ml / mt) if mt > 0 else 0 for ml, mt in zip(modified_lines, modified_tasks)]

# ----------------- 精确按阶段分组合并 -----------------
# 索引定义
idx_base = [0]          # Baseline
idx_stage2 = [1, 3, 5]  # Stage 2 对应的所有测试
idx_stage3 = [2, 4, 6]  # Stage 3 对应的所有测试

# 辅助统计函数：计算指定索引数据的均值和样本标准差
def get_mean_std(data, indices):
    vals = [data[i] for i in indices]
    if len(indices) == 1:
        return vals[0], 0 # Baseline 没有标准差，返回 0
    return np.mean(vals), np.std(vals, ddof=1) # ddof=1 计算样本标准差

# 按组聚合数据
groups = [idx_base, idx_stage2, idx_stage3]

means_added, stds_added = zip(*[get_mean_std(added_tasks, g) for g in groups])
means_removed, stds_removed = zip(*[get_mean_std(removed_tasks, g) for g in groups])
means_avg, stds_avg = zip(*[get_mean_std(avg_lines, g) for g in groups])
means_conn, stds_conn = zip(*[get_mean_std(connection_changed, g) for g in groups])

# 新的横坐标标签
new_cases = ["Baseline", "Stage 2\n(Mean + SD)", "Stage 3\n(Mean + SD)"]
# -----------------------------------------------------

# 颜色和标签定义
COLORS = {
    "added":   "#547dbd",
    "removed": "#82d8db",
    "avg":     "#82aadb",
    "conn":    "#c3e3d5",
}
LABELS = {
    "added":   "Added tasks",
    "removed": "Removed tasks",
    "avg":     "Avg lines / Modified task",
    "conn":    "Connection changed",
}

# 绘图设置
n_groups = len(new_cases)
bar_width = 0.18
x = np.arange(n_groups)
offsets = np.array([-1.5, -0.5, 0.5, 1.5]) * bar_width

# 使用 subplots 结构组织画布
fig, ax = plt.subplots(figsize=(10, 6))

# 误差棒样式参数
error_config = {'ecolor': 'dimgray', 'elinewidth': 1.5, 'capsize': 4}

# 【核心改动】: 使用 (下限值, 上限值) 的形式，将下限值全部设为 0，实现只向上画误差棒
ax.bar(x + offsets[0], means_added,   bar_width, yerr=[np.zeros_like(stds_added), stds_added],     label=LABELS["added"],   color=COLORS["added"],   zorder=2, error_kw=error_config)
ax.bar(x + offsets[1], means_removed, bar_width, yerr=[np.zeros_like(stds_removed), stds_removed], label=LABELS["removed"], color=COLORS["removed"], zorder=2, error_kw=error_config)
ax.bar(x + offsets[2], means_avg,     bar_width, yerr=[np.zeros_like(stds_avg), stds_avg],         label=LABELS["avg"],     color=COLORS["avg"],     zorder=2, error_kw=error_config)
ax.bar(x + offsets[3], means_conn,    bar_width, yerr=[np.zeros_like(stds_conn), stds_conn],       label=LABELS["conn"],    color=COLORS["conn"],    zorder=2, error_kw=error_config)

# 图表装饰
ax.set_xticks(x)
ax.set_xticklabels(new_cases, fontsize=14)
ax.set_ylabel("Difference", fontsize=14, color="dimgray")
ax.tick_params(axis="y", labelcolor="dimgray", labelsize=10)
ax.grid(axis="y", linestyle="--", alpha=0.4, zorder=0)
ax.legend(loc="upper right", fontsize=14, framealpha=0.8)

plt.tight_layout()
plt.savefig("exp2_results_avg.png", dpi=150, bbox_inches="tight")