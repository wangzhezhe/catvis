import os
import glob
import json
import yaml
from context_preparation_funcs import enrich_tasks_with_knowledge

knowledge_file_path = os.path.abspath(
    os.path.join(os.path.dirname(__file__), "..", "global_knowledge_full", "algorithms_with_args.yaml")
)

OUTPUT_DIR = os.path.join(os.path.dirname(__file__), "output_results")

def run_local_yaml_tests():
    """
    Scans the current directory for *.yaml files and runs validations.
    """
    yaml_files = glob.glob("*.yaml")
    
    if not yaml_files:
        print("[-] No *.yaml test cases found within the directory path.")
        return

    print(f"[+] Found {len(yaml_files)} file(s) to process.\n" + "="*60)
    
    passed_runs = 0
    failed_runs = 0

    os.makedirs(OUTPUT_DIR, exist_ok=True)


    for file_path in yaml_files:
        print(f"File Target: {file_path}")
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                content = f.read()
            
            # Execute processing framework
            taskids, results, status_msg = enrich_tasks_with_knowledge(content, knowledge_file_path)

            # TODO output results for testing in a file
            base_filename = os.path.splitext(os.path.basename(file_path))[0]
            output_file_name = f"{base_filename}_result.yaml"  # 改为 yaml 后缀
            output_file_path = os.path.join(OUTPUT_DIR, output_file_name)

            with open(output_file_path, "w", encoding="utf-8") as out_f:
                if status_msg == "success":
                    # 💡 因为 results 已经是 yaml 字符串了，直接 write 写入文件！
                    out_f.write(results)
                else:
                    yaml.safe_dump([{"error_msg": status_msg}], out_f)

            if status_msg == "success":
                print("  Status: PASSED ✅")
                # 💡 打印匹配到的 taskids 列表，避免去遍历字符串
                print(f"  Matched: {taskids}")
                passed_runs += 1
            else:
                print("  Status: FAILED ❌")
                print(f"  Notice: {status_msg}")
                failed_runs += 1
                
        except Exception as e:
            print("  Status: CRITICAL EXCEPTION 💥")
            print(f"  Details: {e}")
            failed_runs += 1
            
        print("-" * 60)

    print(f"Execution Summary: {passed_runs} passed, {failed_runs} failed/rerun flags.")

if __name__ == "__main__":
    # Create the folder and dummy file if it doesn't exist for test environment stability
    run_local_yaml_tests()