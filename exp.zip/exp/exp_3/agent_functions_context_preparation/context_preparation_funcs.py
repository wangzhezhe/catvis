import os
import json
import yaml
from typing import List, Dict, Any, Tuple




def clean_and_parse_llm_output(raw_llm_output: str) -> Tuple[Any, str]:
    """
    Cleans markdown wrappers and safely parses the YAML string into Python objects.
    
    Returns:
        Tuple[parsed_data, error_message]
    """
    text = raw_llm_output.strip()
    
    # 1. Strip Markdown Code Blocks
    if text.startswith("```yaml"):
        text = text[7:]
    elif text.startswith("```json"):
        text = text[7:]
    elif text.startswith("```"):
        text = text[3:]
        
    if text.endswith("```"):
        text = text[:-3]
        
    text = text.strip()

    # 2. Try parsing the YAML/JSON text
    try:
        parsed_data = yaml.safe_load(text)
        return parsed_data, "success"
    except yaml.YAMLError as e:
        return None, f"YAML syntax error: {e}"
    except Exception as e:
        return None, f"Unexpected parsing error: {e}"


def enrich_tasks_with_knowledge(raw_llm_output: str, full_parameter_file_path:str) -> Tuple[List[Dict[str, Any]], str]:
    """
    Validates the parsed data and matches task IDs against the external knowledge base.
    
    Returns:
        Tuple[enriched_data_list, status_or_error_message]
    """
    # 1. Parse YAML Data
    parsed_data, msg = clean_and_parse_llm_output(raw_llm_output)
    #print("get parsed data:", parsed_data)
    if parsed_data is None:
        return [], [], f"Parsing failed. Reason: {msg}. Context preparation may need to rerun."

    # 2. Extract explicit Task IDs depending on the LLM output format
    # Supports list: ["vtkDataLoader", "Slice"] or dictionary keys: {"vtkDataLoader": ..., "Slice": ...}
    task_ids = []
    if isinstance(parsed_data, list):
        task_ids = [str(item) for item in parsed_data]
    elif isinstance(parsed_data, dict):
        task_ids = list(parsed_data.keys())
    else:
        return [], [], "Invalid format: LLM output is neither a list nor a dictionary. Context preparation may need to rerun."

    if not task_ids:
        return task_ids, [], "Input structural layout is empty. Context preparation may need to rerun."

    # 3. Load External Knowledge Reference Base
    if not os.path.exists(full_parameter_file_path):
        return task_ids, [], f"External knowledge file missing at: {full_parameter_file_path}"

    try:
        with open(full_parameter_file_path, "r", encoding="utf-8") as f:
            knowledge_list = yaml.safe_load(f)

        # 稳妥起见，确保解析出来的是列表结构
        if not isinstance(knowledge_list, list):
            return task_ids, [], "Invalid knowledge file structure: Root elements must be a sequential List."

        knowledge_lookup = {item["task_id"]: item for item in knowledge_list}
    except Exception as e:
        return task_ids, [], f"Failed to load or parse knowledge JSON. Error: {e}"

    # 4. Enrich found components
    enriched_output = []
    seen_components = set()

    for task_id in task_ids:
        if task_id in knowledge_lookup and task_id not in seen_components:
            seen_components.add(task_id)
            original_info = knowledge_lookup[task_id]
            #print("original_info",original_info)
            
            # 1. 先构建好数据结构
            component_data = {
                "component_name": original_info["task_id"],
                "description": original_info.get("description", ""),
                "arguments": original_info.get("arguments", {})
            }
            
            # 3. 追加到结果列表中
            enriched_output.append(component_data)

    enriched_output_string = yaml.dump(enriched_output, sort_keys=False, allow_unicode=True)

    if not enriched_output_string:
        return [], [], "No valid task IDs matched the external knowledge data. Context preparation may need to rerun."

    return task_ids, enriched_output_string, "success"