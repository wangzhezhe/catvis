import os
import threading
from typing import Callable, Optional
from langchain_openai import ChatOpenAI
import time
from pathlib import Path
from typing import Callable, Optional, List, Dict, Any

from dotenv import load_dotenv
load_dotenv()

class LLMClientManager:
    """LLM 客户端单例管理器"""
    
    # 隐藏的类级别单例实例与线程锁
    _instance: Optional[ChatOpenAI] = None
    _lock = threading.Lock()
    @classmethod
    def get_client(cls, model_client: str = "cstcloud") -> ChatOpenAI:
        """
        获取 ChatOpenAI 客户端的单例实例（线程安全）
        
        Args:
            model_client: 客户端提供商名称，默认为 "cstcloud"
        """
        # 双重检查锁定（Double-Checked Locking），兼顾性能与线程安全
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    print(f"[LLM Init] 正在首次初始化客户端提供商: '{model_client}'...")
                    base_url=os.getenv("CSTCLOUD_BASE_URL")
                    
                    print("debug base_url:",base_url)
                    
                    if model_client == "aihubmix":
                        model = "DeepSeek-V3"
                        cls._instance = ChatOpenAI(
                            base_url=os.getenv("AIHUBMIX_BASE_URL"),
                            api_key=os.getenv("AIHUBMIX_API_KEY"),
                            model=model,
                            temperature=0,
                        )
                    elif model_client == "cstcloud":
                        cls._instance = ChatOpenAI(
                            base_url=os.getenv("CSTCLOUD_BASE_URL"),
                            api_key=os.getenv("CSTCLOUD_API_KEY"),
                            #model="deepseek-v4-flash",
                            #model="deepseek-v3.2",
                            model="qwen3.5",
                            temperature=0,
                        )
                        
        return cls._instance
    

    # @classmethod
    # def call_and_save_response(
    #     cls,
    #     llm_client: ChatOpenAI,
    #     formatted_prompt,
    #     output_dir_name,
    #     output_file_suffix: str,
    #     tools: Optional[List[Dict[str, Any]]] = None,
    #     on_chunk: Optional[Callable[[str], None]] = None,
    # ):
    #     start_time = time.time()
    #     print("🚀 AI Thinking...")
    #     # 注意：LangChain invoke 返回的是 BaseMessage 对象
    #     resp_content = ""
    #     usage = {}
    #     try:
    #         for chunk in llm_client.stream(formatted_prompt):
    #             chunk_content = getattr(chunk, "content", "") or ""
    #             if chunk_content:
    #                 resp_content += chunk_content
    #                 if on_chunk is not None:
    #                     on_chunk(chunk_content)

    #             chunk_usage = getattr(chunk, "response_metadata", {}).get("token_usage", {})
    #             if chunk_usage:
    #                 usage = chunk_usage
    #     except Exception:
    #         if resp_content:
    #             raise

    #         response = llm_client.invoke(formatted_prompt)
    #         usage = response.response_metadata.get("token_usage", {})
    #         resp_content = response.content
    #         if on_chunk is not None:
    #             on_chunk(resp_content)
        
    #     prompt_tokens = usage.get("prompt_tokens", 0)
    #     completion_tokens = usage.get("completion_tokens", 0)
    #     total_tokens = usage.get("total_tokens", 0)
    #     duration = time.time() - start_time

    #     usage_info = (
    #     f"Model: {llm_client.model_name}\n"
    #     f"Prompt Tokens: {prompt_tokens}\n"
    #     f"Completion Tokens: {completion_tokens}\n"
    #     f"Total Tokens: {total_tokens}\n"
    #     f"Duration: {duration:.2f}s\n"
    #     )   
        
    #     result_file_name = output_file_suffix+".yaml"
    #     response_log_name = output_file_suffix+".log"

    #     os.makedirs(output_dir_name, exist_ok=True)
        
    #     result_file_path = os.path.join(output_dir_name, result_file_name)
    #     response_log_path = os.path.join(output_dir_name, response_log_name)

        
    #     Path(result_file_path).write_text(resp_content, encoding="utf-8")
    #     Path(response_log_path).write_text(usage_info, encoding="utf-8")
        
    #     return resp_content

    @classmethod
    def call_and_save_response(
        cls,
        llm_client: ChatOpenAI,
        formatted_prompt,
        output_dir_name: str,
        output_file_suffix: str,
        tools: Optional[List[Dict[str, Any]]] = None,
        on_chunk: Optional[Callable[[str], None]] = None,
    ):
        start_time = time.time()
        
        import sys
        sys.stderr.write(f"🚀 [{llm_client.model_name}] AI Thinking & Routing...\n")
        sys.stderr.flush()

        active_client = llm_client
        if tools:
            active_client = llm_client.bind_tools(tools)

        resp_content = ""
        final_tool_calls = []
        usage = {}

        # 💡 新增：用来累加或保存流式工具调用的列表
        tool_call_chunks = None 

        try:
            for chunk in active_client.stream(formatted_prompt):
                chunk_content = getattr(chunk, "content", "") or ""
                if chunk_content:
                    resp_content += chunk_content
                    if on_chunk is not None:
                        on_chunk(chunk_content)

                # 💡 工具流式碎片合并
                if hasattr(chunk, "tool_calls") and chunk.tool_calls:
                    if tool_call_chunks is None:
                        tool_call_chunks = chunk.tool_calls
                    else:
                        # 核心：利用 LangChain 的 ToolCallChunk 相加机制自动拼接 args 字符串
                        tool_call_chunks = [
                            tc1 + tc2 for tc1, tc2 in zip(tool_call_chunks, chunk.tool_calls)
                        ] if len(tool_call_chunks) == len(chunk.tool_calls) else chunk.tool_calls

                # 💡 你关心的 Token 提取部分放这里：每次循环都尝试更新，直到最后一个 chunk 拿到完整数据
                chunk_usage = getattr(chunk, "response_metadata", {}).get("token_usage", {})
                if chunk_usage:
                    usage = chunk_usage
                else:
                    # 保留你的兜底策略
                    fallback_usage = getattr(chunk, "usage_metadata", {})
                    if fallback_usage:
                        usage = {
                            "prompt_tokens": fallback_usage.get("input_tokens", 0),
                            "completion_tokens": fallback_usage.get("output_tokens", 0),
                            "total_tokens": fallback_usage.get("total_tokens", 0)
                        }
            
            # 💡 循环安全结束后，把合并完整的工具调用赋值给 final_tool_calls
            if tool_call_chunks:
                final_tool_calls = tool_call_chunks

        except Exception as e:
            sys.stderr.write(f"⚠️ 流式传输异常，转为阻塞同步调用: {str(e)}\n")
            if resp_content or final_tool_calls:
                raise
            response = active_client.invoke(formatted_prompt)
            usage = response.response_metadata.get("token_usage", {})
            resp_content = response.content
            if hasattr(response, "tool_calls"):
                final_tool_calls = response.tool_calls
            if on_chunk is not None and resp_content:
                on_chunk(resp_content)
        
        # 【修正点4】如果经过前面的流式提取后还是 0，尝试从环境变量或硬编码安全归零，避免报错
        prompt_tokens = usage.get("prompt_tokens") or usage.get("input_tokens") or 0
        completion_tokens = usage.get("completion_tokens") or usage.get("output_tokens") or 0
        total_tokens = usage.get("total_tokens") or (prompt_tokens + completion_tokens)
        duration = time.time() - start_time

        # 组织最终写进 .log 文件的文本
        usage_info = (
            f"Model: {llm_client.model_name}\n"
            f"Prompt Tokens: {prompt_tokens}\n"
            f"Completion Tokens: {completion_tokens}\n"
            f"Total Tokens: {total_tokens}\n"
            f"Duration: {duration:.2f}s\n"
        )   
        
        os.makedirs(output_dir_name, exist_ok=True)
        response_log_path = os.path.join(output_dir_name, f"{output_file_suffix}.log")
        
        # 确保数据被写进日志文件
        Path(response_log_path).write_text(usage_info, encoding="utf-8")

        if final_tool_calls:
            result_file_path = os.path.join(output_dir_name, f"{output_file_suffix}_tool_calls.json")
            Path(result_file_path).write_text(str(final_tool_calls), encoding="utf-8")
            return final_tool_calls
        else:
            result_file_path = os.path.join(output_dir_name, f"{output_file_suffix}.yaml")
            Path(result_file_path).write_text(resp_content, encoding="utf-8")
            return resp_content