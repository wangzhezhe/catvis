from typing import Dict, Any, Optional
# 假设你的声明在 agents.py 中，如果在同文件则不需要这行
# from agents import BaseAgentTask, AgentStatus 
from agents import *

class WorkflowEngine:
    def __init__(self, start_agent: BaseAgentTask,  global_context: Optional[Dict[str, Any]] = None):
        """
        工作流引擎初始化
        
        Args:
            start_agent: 初始的 Dummy Agent 实例 (通常是 DummyStartAgent)
            agents_map: 包含所有实例化好的 Agent 注册表，例如 {"WorkflowRunner": runner_instance, ...}
            global_context: 全局共享的上下文变量字典
        """
        self.current_agent = start_agent
    

    def start(self):
        print("🚀 Workflow Engine 启动...")
        
        while self.current_agent is not None:
            print(f"\n--- 🤖 [Loop] 当前执行 Agent: {self.current_agent.name} ---")
            
            # 1. 执行当前 Agent 的业务逻辑
            self.current_agent.run()

            # 2. 调用 Agent 自身的决策函数，获取当前状态
            status = self.current_agent.determin_status()
            print(f"▶️ [{self.current_agent.name}] 决策状态为: {status.name}")

            # 3. 根据状态，在引擎层动态干预或调整路由方向
            if status == AgentStatus.STOP:
                print(f"🏁 [{self.current_agent.name}] 触发停止信号，工作流正常结束。")
                break
                
            elif status == AgentStatus.OTHERS:
                print(f"🚨 [{self.current_agent.name}] 触发异常或人机交互信号！")
                # 策略：如果状态是 OTHERS，自动将下一步指向 Correction 节点
                if "CorrectionAgent" in self.agents_map:
                    self.current_agent.next_agent_name = "CorrectionAgent"
                else:
                    print("⚠️ 警告: 状态为 OTHERS 但注册表中无 CorrectionAgent，将按原逻辑流转。")

            elif status == AgentStatus.CONTINUE:
                # 4. 获取下一个 Agent 实例
                try:
                    # 调用你写好的 get_next_agent，它会去 agents_map 找 self.next_agent_name
                    next_agent = self.current_agent.get_next_agent()
                except ValueError as e:
                    print(f"🛑 流转中断: {str(e)}")
                    break

            # 5. 推进当前指针
            self.current_agent = next_agent

        print("\n🏁 Workflow 执行完毕，引擎退出。")



