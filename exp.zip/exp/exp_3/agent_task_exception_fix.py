from agent_task import BaseAgentTask, AgentStatus
import time 
from utils.openai_client import LLMClientManager
from agent_functions_exception_fix.fix_errors import FUNC_REGISTRY, PREPARATION_TOOLS

class ExceptionFixAgent(BaseAgentTask):
    """负责驱动和执行核心科学可视化工作流的 Agent"""

    
    def __init__(self, name: str = "ExceptionFix",global_context_dir: str = "global_exception_fix"):
        super().__init__(name=name)
        if self.llm_agent_client is None:
            self.llm_agent_client = LLMClientManager.get_client()
        self.upper_run_iteration_count = 5
        self.promopt_dir = "prompts_"+name
        self.results_dir = "results_"+name
        self.load_global_context_from_dir_path(global_context_dir)
        self.user_prompt = "return proporiate function call and operations to prepare the workflow"
        self.run_iteration_count = 0
        self.current_iteration_status = AgentStatus.CONTINUE
        
    def set_input(self, input):
        self.add_local_context("Last execution log", input)

    def get_output(self):
        # give the fix suggestions
        return self.fix_output_msg

    def run(self):
        print(f"[{self.name}] 正在分析Exception...")
        
        self.generate_final_prompt(self.promopt_dir)
        output_file_suffix = f"results_{self.run_iteration_count}"

        # 核心修改：将从 exception_fix_functions 导入的 PREPARATION_TOOLS 传给管理器
        results = LLMClientManager.call_and_save_response(
            self.llm_agent_client,
            self.formatted_prompt,
            self.results_dir,
            output_file_suffix,
            tools=PREPARATION_TOOLS  # 将工具挂载进 LangChain 客户端
        )

        print(results)

        # 核心逻辑：根据新版 LLMClientManager 返回的结果类型做分支处理
        if isinstance(results, list):
            # 进入工具调用链处理（LangChain 格式的 tool_calls 列表）
            for tool_call in results:
                # 提取工具名称（LangChain 的格式是字典里的 'name' 键）
                func_name = tool_call.get("name")
                tool_id = tool_call.get("id")
                
                if not func_name or func_name.strip() == "" or tool_id is None:
                    print(f"[{self.name}] 检测到错误工具调用，已自动过滤: {tool_call}")
                    continue

                print(f"[{self.name}] LLM 成功触发工具路由，准备执行函数: {func_name}")
                
                # 从注册表中动态查找并执行
                if func_name in FUNC_REGISTRY:
                    target_func = FUNC_REGISTRY[func_name]

                    func_args = tool_call.get("args", {})
                    
                    # 💡 2. 安全检查：如果大模型犯傻传回了空 args，但函数却需要参数，我们要给它防御性兜底
                    if func_name == "parameter_error_in_filter" and not func_args.get("component_name_list"):
                        # 强行给它一个兜底的组件名列表（根据上一轮的错误，这里可以用 Render 相关的组件）
                        func_args = {"component_name_list": []}
                        print(f"[{self.name}] 警告：LLM 未生成参数，已启动防御性注入: {func_args}")

                    # 💡 3. 使用 ** 动态解包传递参数
                    execution_result = target_func(**func_args)
                    
                    self.fix_output_msg = execution_result
                    self.add_local_context(f"Fix_Context_From_{func_name}", execution_result)
                    
                    if execution_result == "success":
                        self.current_iteration_status = AgentStatus.STOP
                        print(f"[{self.name}] 工具 [{func_name}] 执行成功 迭代结束")

                    else:
                        print(f"[{self.name}] 工具 [{func_name}] 执行成功，修复内容已生成。")



                else:
                    print(f"[{self.name}] 警告：LLM 返回了未在 FUNC_REGISTRY 注册的工具: {func_name}, 跳过")
                    
        else:
            # 兜底：如果没匹配上工具，results 是普通的回复文本内容
            print(f"[{self.name}] LLM 未匹配到特定工具，走文本修复建议路径。")
            self.fix_output_msg = results
            self.add_local_context("General_Fix_Suggestion", results)


        self.run_iteration_count = self.run_iteration_count + 1

        return
        
    def determin_status(self) -> AgentStatus:
        print(f"[{self.name}] 检测工作流执行结果")
        if self.current_iteration_status == AgentStatus.STOP:
            print(f"[{self.name}] 检测到工作流已结束")
            return AgentStatus.STOP
        if self.run_iteration_count >= self.upper_run_iteration_count:
            print(f"[{self.name}] 迭代达到上限")
            return AgentStatus.STOP
        return self.current_iteration_status
    
    

    

