from agent_task import BaseAgentTask, AgentStatus
import time
import os
from utils.openai_client import LLMClientManager
from agent_functions_context_preparation.context_preparation_funcs import enrich_tasks_with_knowledge
from langchain_core.prompts import ChatPromptTemplate

class ContextPreparationAgent(BaseAgentTask):
    """agent for preparing the context"""
    
    def __init__(self, name: str = "context_preparation_agent", global_context_dir: str = "global_context_preparation"):
        super().__init__(name=name)
        if self.llm_agent_client is None:
            self.llm_agent_client = LLMClientManager.get_client()

        # load global context
        self.load_global_context_from_dir_path(global_context_dir)
        self.prompt_result_dir = "prompts_context_preparation"
        self.results_data_dir = "results_context_preparation"
        self.knowledge_all_func_parameters =  os.path.abspath(os.path.join(os.path.dirname(__file__),  "global_knowledge_full", "algorithms_with_args.yaml"))
        self.current_status = AgentStatus.CONTINUE


    def get_output(self):
        # generate the full context
        output_context = ""
        added_context_keys = set()
        
        for k, v in self.local_context_map.items():
            if k in added_context_keys:
                continue
            output_context += f"#{k}:\n{v}\n---\n"
        
        return output_context
    

    def set_input(self, input):
        self.add_local_context("Last execution msg", input)


    

    def run(self):

        # self.skip_run = True
        # if self.skip_run:
        #     return
        
        print(f"[{self.name}] 正在更新上下文信息...")

        self.generate_final_prompt(self.prompt_result_dir)
        output_file_suffix = f"results_{self.run_iteration_count}"

        results = LLMClientManager.call_and_save_response(
            self.llm_agent_client,
            self.formatted_prompt,
            self.results_data_dir,
            output_file_suffix
        )

        print(f"[{self.name}] 获取LLM返回结果: {results}")

        # parse results and prepar context
        task_ids, expanded_knowledge, status_msg = enrich_tasks_with_knowledge(results, self.knowledge_all_func_parameters)

        if status_msg != "success":
            # there is issue in parsing
            self.current_status  = AgentStatus.STOP


        #print(f"[{self.name}] 获取Conetxt生成结果: {expanded_knowledge}")

        # add knowledge to current context
        self.add_local_context("#Component parameters", expanded_knowledge)
        task_ids_str = ",".join(task_ids)
        self.add_local_context("#Component_name we may used in this task", task_ids_str)
        self.add_local_context("#User's intents", self.user_prompt)


        return
    def determin_status(self) -> AgentStatus:
        return self.current_status