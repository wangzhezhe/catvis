from agent_task import BaseAgentTask, AgentStatus
import time 
from utils.openai_client import LLMClientManager
import utils
from agent_functions_wf_task.run_wf import run_wf, get_last_logs
import os

class TemplateGenerationAgent(BaseAgentTask):
    """负责驱动和执行核心科学可视化工作流的 Agent"""

    
    def __init__(self, name: str = "TemplateGeneration",global_context_dir: str = "global_wf_generation"):
        super().__init__(name=name)
        if self.llm_agent_client is None:
            self.llm_agent_client = LLMClientManager.get_client()
        self.upper_run_iteration_count = 100
        self.wf_template_promopt_dir = "prompts_wf_template"
        self.results_data_dir = "results_wf_template"
        self.global_context_dir = global_context_dir
        self.external_knowledge_dir = "global_knowledge_full"
        self.load_global_context_from_dir_path(global_context_dir)
        self.user_prompt = "generate workflow template based on provided context, only use the taskid listed in context do not makeup task that does not exist in the taskid list"
        
        self.run_iteration_count = 0

        self.wf_template = ""
        self.exec_result = ""
    def set_input(self, input):
        if self.run_iteration_count == 0 :
            self.set_local_context("#Context of template generation", input)
            data_path = os.path.join(self.external_knowledge_dir, "data_description.md")
            dataset_info = self.get_contents_from_file(data_path)
            self.set_local_context("#Data set information for processing",dataset_info)
        else:   
            self.clear_local_context()
            self.set_local_context("##Last generated workflow template", self.wf_template)  
            self.set_local_context("##Fix suggestions", str(input))

    def get_output(self):
        output = ""
        # output += "Last workflow template:\n"
        # output += self.wf_template
        # output += "\n"
        # output += "Last execution result:\n"
        output += self.exec_result
        return output


    def run(self):
        print(f"[{self.name}] 工作流执行模版生成...")

        
        self.generate_final_prompt(self.wf_template_promopt_dir)
        output_file_suffix = f"results_{self.run_iteration_count}"

        results = LLMClientManager.call_and_save_response(
            self.llm_agent_client,
            self.formatted_prompt,
            self.results_data_dir,
            output_file_suffix
        )

        # print execution result and get the feedback
        # run the workflow template and get the feedback
        result_file = os.path.join(self.results_data_dir, f"results_{self.run_iteration_count}.yaml")
        output_log_file_path = os.path.join(self.results_data_dir, f"workflow_exec_{self.run_iteration_count}.log")
        exec_message = run_wf(result_file,output_log_file_path)

        #print(exec_message)

        # get the feedback
        self.wf_template = results
        self.exec_result = get_last_logs(output_log_file_path)

        self.run_iteration_count+=1
        
        return
        
    def determin_status(self) -> AgentStatus:
        print(f"[{self.name}] 检测工作流执行结果")
        if self.run_iteration_count >= self.upper_run_iteration_count:
            print(f"[{self.name}] 迭代达到上限")
            return AgentStatus.STOP
        return AgentStatus.CONTINUE
    
    

    

