from __future__ import annotations  
from abc import ABC, abstractmethod
from typing import Dict, Any, Optional, Tuple
from enum import Enum, auto
import time
import os
from langchain_core.prompts import ChatPromptTemplate

class AgentStatus(Enum):
    """定义 Agent 执行结果的标准状态枚举"""
    CONTINUE = auto()  # 正常结束，准备流转到下一个 Agent
    STOP = auto()      # 满足终止条件，工作流彻底结束
    OTHERS = auto()    # 异常情况、或需要人工干预等特殊状态


AGENTS_MAP: Dict[str, BaseAgentTask] = {} # using future annotations to avoid issue of parsing the class

class BaseAgentTask(ABC):
    """所有 Agent 任务的公共父类"""
    
    def __init__(self, name: str):
        self.name = name
        
        self.global_context_folder = f"global_context"

        self.local_context_folder_prefix=f"{self.name}_local_context"
        
        self.next_agent_name = ""

        # 🌟 局部变量管理 (Agent Key-Value Management)
        # 专门存放当前 Agent 局部的、私有的配置或中间状态，实现 POMDP 的局部观察隔离
        self.local_context_map: Dict[str, str] = {}
        
        # 由 WorkflowEngine 运行时动态注入的全局共享上下文
        self.global_context_map: Dict[str, Any] = {}

        self.run_iteration_count = 0

        self.user_prompt = ""
        self.system_prompt = ""
        self.llm_agent_client = None
        
        # 每次初始化新实例时，自动以 name 行为 Key 注册到全局 Map 中
        if self.name in AGENTS_MAP:
            print(f"⚠️ [Warning] Agent 名为 '{self.name}' 的实例已被覆盖注册。")
        AGENTS_MAP[self.name] = self

    @abstractmethod
    def run(self):
        """
        执行当前 Agent 的核心逻辑。
        
        Args:
            context: 全局工作流上下文（共享状态）
            
        Returns:
            Tuple[updated_context_diff, execution_status]: 
                - updated_context_diff: 当前 Agent 产生的新数据/增量修改
                - execution_status: 执行状态（例如 "success", "failed", "need_human"）
        """
        # for each iteration, the iteration count will increase
        pass


    # ==========================================================
    # 🌟 核心补全：保存局部上下文到磁盘
    # ==========================================================
    def save_local_context(self):
        """
        将当前内存中的 local_context_map 持久化到本地目录中。
        目录命名规则: {local_context_folder_prefix}_{run_iteration_count}
        每个 Key 对应一个文件名，每个 Value 对应文件内容。
        """
        # 1. 动态生成当前迭代轮数的文件夹名称
        target_dir = f"{self.local_context_folder_prefix}_{self.run_iteration_count}"
        
        # 2. 如果文件夹不存在，则递归创建它
        os.makedirs(target_dir, exist_ok=True)
        print(f"[{self.name}] save context into dir: '{target_dir}'")
        
        # 3. 遍历 local_context_map，将 KV 写入文件
        for key, value in self.local_context_map.items():
            # 安全处理文件名，防止包含非法字符
            safe_filename = "".join([c for c in key if c.isalpha() or c.isdigit() or c in (' ', '_', '-')]).rstrip()
            file_path = os.path.join(target_dir, safe_filename)
            
            try:
                with open(file_path, "w", encoding="utf-8") as f:
                    f.write(str(value))
            except Exception as e:
                print(f"❌ [{self.name}] unable to write context file {safe_filename}: {str(e)}")


    @abstractmethod
    def determin_status(self):
        pass


    def get_output(self):
        pass

    def set_input(self, input):
        pass

    def clear_local_context(self):
        self.local_context_map.clear()

    
    def get_contents_from_file(self, file_path):
        with open(file_path, "r", encoding="utf-8") as f:
            contents =  f.read()
            return contents  

    def load_global_context_from_dir_path(self, dir_path: str):
        for file_name in os.listdir(dir_path):
            file_path = os.path.join(dir_path, file_name)
            with open(file_path, "r", encoding="utf-8") as f:
                self.global_context_map[file_name] = f.read()

    def add_local_context(self, key: str, value: str):
        self.local_context_map[key] = value
        return

    def add_global_context(self, key: str, value: str):
        self.global_context_map[key] = value
        return

    def set_local_context(self, key: str, value: str):
        self.local_context_map[key] = value
        return
    
    def set_global_context(self, key: str, value: str):
        self.global_context_map[key] = value
        return
    
    def set_user_prompt(self, user_prompt: str):
        self.user_prompt = user_prompt
        return   
    

    def generate_final_prompt(self, result_dir: str = "prompt_results") -> str:
        # generate system prompt according to context map
        # empty the system prompt in last cycle
        self.system_prompt = ""
        added_context_keys = set()
        
        for k, v in self.global_context_map.items():
            self.system_prompt += f"#{k}:\n{v}\n---\n"
            added_context_keys.add(k)
            
        for k, v in self.local_context_map.items():
            if k in added_context_keys:
                continue
            self.system_prompt += f"#{k}:\n{v}\n---\n"
        
        
        prompt_template = ChatPromptTemplate.from_messages([
        ("system", self.system_prompt.replace("{", "{{").replace("}", "}}")),
        ("user", self.user_prompt)
        ])
        
        self.formatted_prompt = prompt_template.format_prompt()
        # crete dir if not exists
        os.makedirs(result_dir, exist_ok=True)
        
        file_path = os.path.join(result_dir, "final_prompt_"+str(self.run_iteration_count)+".txt")
        try:
            with open(file_path, "w", encoding="utf-8") as f:
                f.write(str(self.formatted_prompt.to_string()))
        except Exception as e:
                print(f"❌ [{self.name}] unable to write context file {file_path}: {str(e)}")

    def get_next_agent(self) -> Optional['BaseAgentTask']:
        """
        根据当前的全局 context 和刚刚执行完的状态，决定下一个 Agent 是谁。
        如果返回 None，则意味着整个工作流结束。
        """
        # 无论如何都指向第一个真正的 Agent
        agents_map = AGENTS_MAP
        next_agent = agents_map.get(self.next_agent_name)
        if next_agent is None:
            raise ValueError(f"Next agent '{self.next_agent_name}' not found in agents_map")
        return next_agent


class DummyStartAgent(BaseAgentTask):
    """Dummy 初始 Agent，仅用于引导至第一个真正的 Agent"""
    
    def __init__(self, name: str = "DummyStart"):
        super().__init__(name)

    def run(self):
        # 啥也不干，直接返回成功
        print(f"[DummyStart] Dummy agent run...")
        return

    def determin_status(self):
        return AgentStatus.CONTINUE
    
