from agent_workflow import WorkflowEngine
from agent_task import DummyStartAgent
from agent_task_context_preparaion import ContextPreparationAgent
from agent_task_wftemplate_generation import TemplateGenerationAgent
from agent_task_exception_fix import ExceptionFixAgent
if __name__ == "__main__":
    # 1. 实例化各个具体的 Agent

    # init nodes
    dummy_start = DummyStartAgent("dummy_start")
    context_preparation_agent = ContextPreparationAgent("context_preparation_agent")
    context_preparation_agent.set_user_prompt("analysis the tip vortex of the dataset")
    template_generation_agent = TemplateGenerationAgent("template_generation_agent")
    exception_fix_agent = ExceptionFixAgent("exception_fix_agent")

    # init edges
    dummy_start.next_agent_name = "context_preparation_agent"
    context_preparation_agent.next_agent_name = "template_generation_agent"
    template_generation_agent.next_agent_name = "exception_fix_agent"
    exception_fix_agent.next_agent_name = "template_generation_agent"

    # 4. 初始化引擎并启动
    engine = WorkflowEngine(
        start_agent=dummy_start, 
    )

    # 启动引擎
    engine.start()