The output must be a valid YAML file containing ONLY a list of the selected task IDs.

Strict Rules:
1. NO PROSE/MARKDOWN: Do not include any preamble, explanations, markdown blocks (DO NOT wrap the output in ```yaml or ```), or post-processing notes. Start directly with the raw YAML content.
2. NO DESCRIPTIONS OR EXTRA FIELDS: Do not include "category", "description", or any other attributes. Output only the "task_id" keys and their values.
3. MATCH EXACT NAMES: The task IDs must exactly match the "task_id" strings provided in the filter descriptions.