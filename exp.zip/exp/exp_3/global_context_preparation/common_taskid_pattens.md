"Preprocess" task is always needed when we load the vtkm data since we need to convert vtkm into dict that can be used by other tasks.

"MergeDataSets" is used to merge multiple data blocks in data field into one, we need to use "FilterDict" the case when merging data from output of different tasks.
