from run_wf import run_wf
import os

config = os.path.join(os.path.dirname(__file__), "../wf_template_results/results_0.yaml")
log_file_path = "workflow_exec.log"
msg = run_wf(config, log_file_path)

print(msg)


# typical erros Task type [ExtractBlock] not registered
# reasons: the task name might be wrong, refer to task list and fix the template
