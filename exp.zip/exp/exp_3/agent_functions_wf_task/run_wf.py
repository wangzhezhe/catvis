from gwlalg.workflow import workflow_composer
from gwlalg.alg import alg_task
import time
from contextlib import redirect_stdout, redirect_stderr
import os
import traceback
import logging
def run_wf(yaml_path:str,log_file_path: str):
    with open(log_file_path, "w", encoding="utf-8") as f:
        # 同时重定向标准输出(print等)和标准错误(底层的error/warning等)到同一个文件
        with redirect_stdout(f), redirect_stderr(f):

            # 🛠️ 【核心修复】动态调整 logging 模块的 handler，让流式的 logger 也写入该文件
            root_logger = logging.getLogger()
            old_handlers = root_logger.handlers[:]  # 备份原有的 handler

            # 创建一个往文件写的临时 handler
            file_handler = logging.StreamHandler(f)
            # 如果需要保持原有的格式，可以给它加个 formatter（可选）
            if old_handlers and old_handlers[0].formatter:
                file_handler.setFormatter(old_handlers[0].formatter)

            # 清空原 handler 并加入文件 handler
            root_logger.handlers = [file_handler]

            # --- 以下进入原本的执行逻辑，所有的输出都会乖乖写入 log_file_path ---

            print(
                f"=== Workflow Started at {time.strftime('%Y-%m-%d %H:%M:%S')} ==="
            )

            try:

                alg_task.load_all_tasks()
                # gwl_catalog = workflow_composer.Catalog()
                start_time = time.perf_counter()
                config = yaml_path
                msg = "success"
                # build the workflow
                workflow = workflow_composer.Workflow(config)
                # run the workflow
                workflow.run()
                end_time = time.perf_counter()
                print(f"Elapsed time for whole tests: {end_time - start_time:.4f} seconds")
                return msg
        
            except Exception as e:
                # 【核心修改】在这里手动把崩溃的详细堆栈打印出来
                # 因为此时 redirect_stderr 正在生效，它会被乖乖写入 log_file_path 文件中
                print("\n[ERROR] Workflow execution failed!")
                traceback.print_exc()

                # 依然保持你原本的逻辑，把错误简述 return 出去
                return str(e)
        
            finally:
                # 恢复旧的 handlers 之前，先把当前的临时文件 handler 彻底剥离并关掉
                root_logger = logging.getLogger()
                if file_handler in root_logger.handlers:
                    root_logger.removeHandler(file_handler)
                if file_handler:
                    file_handler.close()  # 🌟 关键：主动释放对文件的占用
                    
                root_logger.handlers = old_handlers  # 完美恢复原状

def get_last_logs(
    log_file_path: str, num_lines: int = 50
) -> str:
    """直接读取文件所有行，并返回最后 N 行。"""
    if not os.path.exists(log_file_path):
        return f"Log file not found: {log_file_path}"

    try:
        with open(log_file_path, "r", encoding="utf-8", errors="ignore") as f:
            lines = f.readlines()
            # 取最后 N 行并拼接成一个大字符串
            return "".join(lines[-num_lines:])
    except Exception as e:
        return f"Error reading log file: {str(e)}"
