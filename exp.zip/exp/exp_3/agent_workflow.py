from typing import Dict, Any, Optional
# 假设你的声明在 agents.py 中，如果在同文件则不需要这行
# from agents import BaseAgentTask, AgentStatus 
from agent_task import *

class WorkflowEngine:
    def __init__(self, start_agent: BaseAgentTask,  global_context: Optional[Dict[str, Any]] = None):
        """
        工作流引擎初始化
        
        Args:
            start_agent: 初始的 Dummy Agent 实例 (通常是 DummyStartAgent)
            agents_map: 包含所有实例化好的 Agent 注册表，例如 {"WorkflowRunner": runner_instance, ...}
            global_context: 全局共享的上下文变量字典
        """
        self.current_agent = start_agent
        self.is_paused = False  # 🟩 新增：暂停状态标识


    def pause(self):
        """主动暂停引擎（通常在外部调用，或者在 Agent 内部通过某种信号触发）"""
        print("⏸️  Engine 收到暂停指令，将在当前步骤执行完后挂起...")
        self.is_paused = True


    def resume(self, external_input: Optional[Any] = None):
        """恢复执行引擎。如果暂停期间有外部输入（如审批结果），可以通过参数传进来"""
        if not self.is_paused:
            print("⚠️  Engine 未处于暂停状态，无需恢复。")
            return
        
        print("▶️  Engine 恢复运行...")
        self.is_paused = False
        
            
        # 重新调用 start 恢复循环
        self.start()

    def start(self):
        print("🚀 Workflow Engine 启动...")
        
        while self.current_agent is not None:
            # 🟩 检查点 1：如果在进入下一步前被标记为了暂停，则优雅跳出
            if self.is_paused:
                print(f"⏸️  [Pause] 引擎已安全暂停。当前指针停留在: {self.current_agent.name}，等待唤醒。")
                return  # 用 return 退出当前 start()，但不销毁引擎，保留 current_agent
            
            print(f"\n--- 🤖 [Loop] 当前执行 Agent: {self.current_agent.name} 迭代轮次 {self.current_agent.run_iteration_count} ---")
            
            # 1. 执行当前 Agent 的业务逻辑
            self.current_agent.run()

            # 2. 调用 Agent 自身的决策函数，获取当前状态
            status = self.current_agent.determin_status()
            print(f"▶️ [{self.current_agent.name}] 决策状态为: {status.name}")

            # 3. 根据状态，在引擎层动态干预或调整路由方向
            if status == AgentStatus.STOP:
                print(f"🏁 [{self.current_agent.name}] 触发停止信号，工作流正常结束。")
                break
                
            elif status == AgentStatus.OTHERS:
                print(f"🚨 [{self.current_agent.name}] 触发异常或人机交互信号！")
                # 策略：如果状态是 OTHERS，自动将下一步指向 Correction 节点
                # self.pause()
                # continue
                raise ValueError("⚠️  [Exception] TODO 检测到OTHERS 状态，待更新")

            elif status == AgentStatus.CONTINUE:
                # 4. 获取下一个 Agent 实例
                try:
                    # 调用你写好的 get_next_agent，它会去 agents_map 找 self.next_agent_name
                    next_agent = self.current_agent.get_next_agent()
                except ValueError as e:
                    print(f"🛑 流转中断: {str(e)}")
                    break

            # 5. 推进当前指针
            output_of_last_agent = self.current_agent.get_output()
            self.current_agent = next_agent
            self.current_agent.set_input(output_of_last_agent)
            

        print("\n🏁 Workflow 执行完毕，引擎退出。")



