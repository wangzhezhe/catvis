import os
import matplotlib.pyplot as plt
import networkx as nx
import pandas as pd

# 支持中文显示
plt.rcParams["font.sans-serif"] = ["SimHei"]  # 用来正常显示中文标签
plt.rcParams["axes.unicode_minus"] = False  # 用来正常显示负号


def build_and_visualize_kg(nodes_path, edges_path):
    # 1. 初始化有向图
    G = nx.DiGraph()

    # 2. 读取节点 CSV
    print("正在加载节点数据...")
    if not os.path.exists(nodes_path):
        print(f"错误：找不到文件 {nodes_path}")
        return
    nodes_df = pd.read_csv(nodes_path)

    for _, row in nodes_df.iterrows():
        node_id = row["node_id"]
        G.add_node(
            node_id,
            category=row["category"],
            label_zh=row["label_zh"],
            description=row["description"],
        )

    # 3. 读取关系边 CSV 并进行去重过滤
    print("正在加载并去重边关系...")
    if not os.path.exists(edges_path):
        print(f"错误：找不到文件 {edges_path}")
        return
    edges_df = pd.read_csv(edges_path)

    duplicate_count = 0
    added_count = 0

    for _, row in edges_df.iterrows():
        source = row["source"]
        target = row["target"]
        edge_type = row["edge_type"]

        # 容错处理：如果边对应的节点不存在，则跳过
        if not G.has_node(source) or not G.has_node(target):
            continue

        # 核心去重逻辑：如果两点间已存在同类型的边，则不再重复添加
        if G.has_edge(source, target) and G[source][target].get("type") == edge_type:
            duplicate_count += 1
            continue

        G.add_edge(
            source,
            target,
            type=edge_type,
            description=str(row["description"]) if pd.notna(row["description"]) else "",
        )
        added_count += 1

    print(f"【图结构构建完毕】")
    print(f"  - 总节点数: {G.number_of_nodes()}")
    print(f"  - 总关系边数: {G.number_of_edges()} (成功过滤掉 {duplicate_count} 条重复边)")

    # 4. 绘图准备：根据 category 属性为节点和边分类着色
    # 节点颜色映射
    color_map = []
    labels = {}
    for node, attrs in G.nodes(data=True):
        # 提取中文标签作为展示文字
        labels[node] = attrs.get("label_zh", node)

        category = attrs.get("category")
        if category == "Scenario":
            color_map.append("#3182bd")  # 场景层：蓝色
        elif category == "Feature":
            color_map.append("#e6550d")  # 特征层：橙色
        elif category == "Task":
            color_map.append("#31a354")  # 算法层：绿色
        else:
            color_map.append("#969696")  # 默认：灰色

    # 边颜色/线型映射
    edge_colors = []
    edge_styles = []
    for u, v, attrs in G.edges(data=True):
        etype = attrs.get("type")
        if etype == "INVESTIGATES":
            edge_colors.append("#e6550d")
            edge_styles.append("-")  # 实线
        elif etype == "RESOLVED_BY":
            edge_colors.append("#31a354")
            edge_styles.append("-")  # 实线
        else:  # DEPENDS_ON
            edge_colors.append("#7f7f7f")
            edge_styles.append("--")  # 虚线

    # 5. 渲染图像
    print("\n正在生成可视化图表，请稍候...")
    plt.figure(figsize=(16, 12), dpi=100)

    # 使用 Graphviz 的 layout（如果本地没装 graphviz，会自动降级为 spring_layout）
    try:
        pos = nx.nx_pydot.graphviz_layout(G, prog="dot")
    except:
        # 使用 networkx 自带的弹簧布局，并增加节点间距
        pos = nx.spring_layout(G, k=0.5, iterations=50, seed=42)

    # 绘制节点
    nx.draw_networkx_nodes(
        G, pos, node_color=color_map, node_size=1200, alpha=0.85
    )

    # 绘制边
    nx.draw_networkx_edges(
        G,
        pos,
        edge_color=edge_colors,
        style=edge_styles,
        width=1.5,
        arrows=True,
        arrowsize=15,
    )

    # 绘制标签文字（带微调防止重叠）
    nx.draw_networkx_labels(
        G,
        pos,
        labels=labels,
        font_size=9,
        font_family="sans-serif",
        font_weight="bold",
    )

    # 制作图例
    plt.plot([], [], "o", color="#3182bd", label="分析场景 (Scenario)")
    plt.plot([], [], "o", color="#e6550d", label="流场特征 (Feature)")
    plt.plot([], [], "o", color="#31a354", label="可视化算法 (Task)")
    plt.plot([], [], "-", color="#e6550d", label="关注 (INVESTIGATES)")
    plt.plot([], [], "-", color="#31a354", label="解析 (RESOLVED_BY)")
    plt.plot([], [], "--", color="#7f7f7f", label="数据依赖 (DEPENDS_ON)")
    plt.legend(loc="upper left", scatterpoints=1, fontsize=11, frameon=True)

    plt.title("科学可视化系统：分析场景与算法知识图谱", fontsize=16, pad=20)
    plt.axis("off")
    plt.tight_layout()

    # 保存并展示
    output_img = "vis_knowledge_graph.png"
    plt.savefig(output_img, bbox_inches="tight")
    print(f"✨ 可视化结果已成功保存为本地图片: {output_img}")
    plt.show()

    return G


if __name__ == "__main__":
    # 执行构建
    kg_graph = build_and_visualize_kg("nodes.csv", "edges.csv")