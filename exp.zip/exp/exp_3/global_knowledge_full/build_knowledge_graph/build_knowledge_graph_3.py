import pandas as pd
import networkx as nx
from pyvis.network import Network

def generate_interactive_web_kg(nodes_path, edges_path):
    # 1. 依然使用 NetworkX 处理核心的去重清洗逻辑
    G = nx.DiGraph()
    
    nodes_df = pd.read_csv(nodes_path)
    for _, row in nodes_df.iterrows():
        G.add_node(
            row["node_id"],
            category=row["category"],
            label_zh=row["label_zh"],
            description=row["description"] if pd.notna(row["description"]) else ""
        )

    edges_df = pd.read_csv(edges_path)
    for _, row in edges_df.iterrows():
        source, target, edge_type = row["source"], row["target"], row["edge_type"]
        if G.has_node(source) and G.has_node(target):
            if G.has_edge(source, target) and G[source][target].get("type") == edge_type:
                continue
            G.add_edge(source, target, type=edge_type)

    # 清洗：只保留有 edge 关联的活跃节点
    isolated_nodes = list(nx.isolates(G))
    G.remove_nodes_from(isolated_nodes)

    # 2. 初始化 pyvis 网络对象 (指定有向图, 宽边界面)
    # notebook=False 表示在本地脚本运行，生成独立的 html
    net = Network(height="900px", width="100%", directed=True, bgcolor="#222222", font_color="white")
    
    # 3. 将 NetworkX 的图结构直接打包装入 pyvis
    for node, attrs in G.nodes(data=True):
        # 不同的 category 赋予不同的视觉颜色
        cat = attrs["category"]
        color = "#3182bd" if cat == "Scenario" else "#e6550d" if cat == "Feature" else "#31a354"
        
        # title 属性是 pyvis 极其强大的地方：鼠标悬停在节点上时弹出的 HTML 浮窗描述
        hover_html = f"<b>[{cat}] {attrs['label_zh']}</b><br/>ID: {node}<br/>描述: {attrs['description']}"
        
        net.add_node(
            node, 
            label=attrs["label_zh"], 
            title=hover_html,  # 鼠标悬停提示
            color=color,
            size=25 if cat == "Scenario" else 20 if cat == "Feature" else 15
        )

    # 转换边关系
    for u, v, attrs in G.edges(data=True):
        etype = G[u][v].get("type")
        color = "#e6550d" if etype == "INVESTIGATES" else "#31a354" if etype == "RESOLVED_BY" else "#7f7f7f"
        net.add_edge(u, v, color=color, width=1.5)

    # 4. 物理引擎微调 (开启物理模拟，让节点拖拽时有果冻般的弹性碰撞感，松开手会自动收敛稳定)
    net.toggle_physics(True)
    
    # 可选：如果你希望图谱默认是层次化（上下层）展开的，可以开启 hierarchical 布局
    # net.set_options('{"layout": {"hierarchical": {"enabled": true, "direction": "UD", "sortMethod": "directed"}}}')

    # 5. 生成独立 Web 网页
    output_html = "interactive_knowledge_graph.html"
    net.write_html(output_html)
    print(f"✨ 动态交互式网页已生成: {output_html}，直接双击在浏览器打开即可！")

if __name__ == "__main__":
    # 需要先 pip install pyvis
    generate_interactive_web_kg("nodes.csv", "edges.csv")