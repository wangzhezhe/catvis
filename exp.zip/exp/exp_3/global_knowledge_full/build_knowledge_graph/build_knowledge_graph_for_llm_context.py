import os
import networkx as nx
import pandas as pd
import yaml  # 如果提示找不到，请先 pip install pyyaml


def export_feature_task_mapping(nodes_path, edges_path):
    # 1. 依然通过你现有的两张 CSV 构建基础图结构
    G = nx.DiGraph()

    if not os.path.exists(nodes_path) or not os.path.exists(edges_path):
        print("错误：请确保 nodes.csv 和 edges.csv 在当前目录下。")
        return

    # 加载节点
    nodes_df = pd.read_csv(nodes_path)
    for _, row in nodes_df.iterrows():
        G.add_node(
            row["node_id"], category=row["category"], label_zh=row["label_zh"]
        )

    # 加载关系边
    edges_df = pd.read_csv(edges_path)
    for _, row in edges_df.iterrows():
        source, target, edge_type = row["source"], row["target"], row["edge_type"]
        if G.has_node(source) and G.has_node(target):
            G.add_edge(source, target, type=edge_type)

    # 2. 核心提取逻辑：遍历特征节点，捞出其绑定的底层算法 ID
    llm_context_list = []

    # 过滤出所有分类为 'Feature' 的节点
    feature_nodes = [
        (n, attrs)
        for n, attrs in G.nodes(data=True)
        if attrs.get("category") == "Feature"
    ]

    for node_id, attrs in feature_nodes:
        feature_label = attrs.get("label_zh", node_id)

        # 找出当前特征节点指向的所有下游活跃邻居
        supported_tasks = []
        for neighbor in G.successors(node_id):
            # 严格校验边的类型必须是 RESOLVED_BY
            if G[node_id][neighbor].get("type") == "RESOLVED_BY":
                supported_tasks.append(neighbor)

        # 只有当这个特征绑定了算法时，才导出给 LLM（防止空特征干扰）
        if supported_tasks:
            item = {
                "Feature": f"{feature_label} ({node_id})",
                "Supported_Tasks": supported_tasks,
            }
            llm_context_list.append(item)

    # 3. 输出为适合 LLM 阅读的 YAML 格式文本
    print("\n" + "=" * 20 + " 成功生成 LLM 上下文配置 " + "=" * 20)

    # 使用 yaml.dump 格式化输出，allow_unicode=True 确保中文不乱码
    yaml_text = yaml.dump(
        llm_context_list, allow_unicode=True, default_flow_style=False, sort_keys=False
    )
    print(yaml_text)

    # 4. 可选：同时保存为本地文件，方便大模型框架（如 LangChain 或 LlamaIndex）直接读取
    output_file = "llm_feature_map.yaml"
    with open(output_file, "w", encoding="utf-8") as f:
        f.write(yaml_text)
    print("=" * 60)
    print(f"✨ 导出成功！LLM 上下文词典已保存至本地: {output_file}")


if __name__ == "__main__":
    # 执行导出
    export_feature_task_mapping("nodes.csv", "edges.csv")