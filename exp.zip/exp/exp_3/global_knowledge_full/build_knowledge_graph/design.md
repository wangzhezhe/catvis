INVESTIGATES
RESOLVED_BY
DEPENDS_ON
CONSUME
PRODUCEEDBY


1. DEPENDS_ON (数据流依赖) 连接方向：分析场景 (Scenario) $\rightarrow$ 数据加载算子 (Task)业务含义：表达该分析场景在刚启动时，需要从磁盘或实验设备中加载什么类型的基础数据。这是整个可视化管线（Pipeline）的数据源头。实例（来自 edges.csv）：solver_validation $\xrightarrow{\text{DEPENDS_ON}}$ vtkmDataLoader （加载多块仿真 .vtm 数据）endwall_flow_control... $\xrightarrow{\text{DEPENDS_ON}}$ vtkDataLoaderByList （加载实验台测点数据列表）


2. INVESTIGATES (探究/关注)连接方向：分析场景 (Scenario) $\rightarrow$ 流场特征/物理量 (Feature)业务含义：表达某个特定的研究场景把什么流体机械物理现象、形变特征或气动性能指标作为它的研究核心。它是连接学术论文和代码算子的桥梁。实例（来自 edges.csv）：steady_simulation_... $\xrightarrow{\text{INVESTIGATES}}$ Tip_Leakage_Vortex （定常模拟场景关注叶顶泄漏涡行为）fluid_structure_interaction_... $\xrightarrow{\text{INVESTIGATES}}$ Blade_Deformation （流固耦合场景关注叶片弹性形变）


3. RESOLVED_BY (算子解析/实现)连接方向：流场特征/物理量 (Feature) $\rightarrow$ 可视化算法 (Task)业务含义：表达要提取、量化、捕捉或观察某个特定的物理特征，系统底层的算法库（gwlalg）需要调用哪些具体的算法组件。这是图结构实现“复用、去重、不再无限累加”的最核心纽带。实例（来自 edges.csv）：Tip_Leakage_Vortex $\xrightarrow{\text{RESOLVED_BY}}$ AddQCriterion2 （泄漏涡通过 Q 准则算子识别）Flow_Separation $\xrightarrow{\text{RESOLVED_BY}}$ SurfaceStreamline （流动分离通过固壁表面极限流线来表达）Shock_Wave $\xrightarrow{\text{RESOLVED_BY}}$ Slice （通道激波通过截面切片提取）

node type

task按照types比如 VisTask_IO VisTask_Turbo VisTask_General
task还需要加数据的 比如 SingleBlock Data， MultiBlock Data

scenarios, 应该再分 按部件来 涡轮Turbine 压气机Compressor 燃烧室Combustor


steady_simulation_and_tip_flow_characterization $\xrightarrow{\text{INVESTIGATES}}$ Tip_Leakage_Vortex
Tip_Leakage_Vortex $\xrightarrow{\text{RESOLVED_BY}}$ AddQCriterion2
AddQCriterion2 $\xrightarrow{\text{CONSUMES}}$ MultiBlockData
$$\text{MultiBlockData} \xrightarrow{\text{LOADED_BY}} \text{vtkmDataLoader}$$ 