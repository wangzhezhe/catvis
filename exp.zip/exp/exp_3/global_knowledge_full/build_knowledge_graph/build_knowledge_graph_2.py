import os
import json
import pandas as pd
import networkx as nx
import matplotlib.pyplot as plt

# 支持中文显示
plt.rcParams["font.sans-serif"] = ["SimHei"]
plt.rcParams["axes.unicode_minus"] = False

def build_active_knowledge_graph(nodes_path, edges_path):
    # 1. 初始化有向图
    G = nx.DiGraph()

    # 2. 预加载所有节点
    if not os.path.exists(nodes_path) or not os.path.exists(edges_path):
        print("错误：请确保 nodes.csv 和 edges.csv 在当前目录下。")
        return

    nodes_df = pd.read_csv(nodes_path)
    for _, row in nodes_df.iterrows():
        G.add_node(
            row["node_id"],
            category=row["category"],
            label_zh=row["label_zh"],
            description=row["description"] if pd.notna(row["description"]) else ""
        )

    # 3. 加载并去重边关系
    edges_df = pd.read_csv(edges_path)
    for _, row in edges_df.iterrows():
        source, target, edge_type = row["source"], row["target"], row["edge_type"]
        if G.has_node(source) and G.has_node(target):
            # 去重
            if G.has_edge(source, target) and G[source][target].get("type") == edge_type:
                continue
            G.add_edge(source, target, type=edge_type, description=str(row["description"]) if pd.notna(row["description"]) else "")

    # ==================== 核心拓展：只保留有 Edge 关联的节点 ====================
    # nx.isolates(G) 可以直接找出所有度为 0 (既没有入度也没有出度) 的孤立节点
    isolated_nodes = list(nx.isolates(G))
    total_before = G.number_of_nodes()
    
    # 从图中安全移除这些孤立节点
    G.remove_nodes_from(isolated_nodes)
    
    print(f"【节点清洗完毕】")
    print(f"  - 原始节点总数: {total_before}")
    print(f"  - 剔除孤立节点数: {len(isolated_nodes)}")
    print(f"  - 剩余活跃节点数 (有Edge关联): {G.number_of_nodes()}")
    print(f"  - 活跃关系边总数: {G.number_of_edges()}")
    # ============================================================================

    # 4. 导出精简后的结构数据 (JSON 格式)
    active_data = {
        "nodes": [
            {
                "node_id": node,
                "category": attrs["category"],
                "label_zh": attrs["label_zh"],
                "description": attrs["description"]
            }
            for node, attrs in G.nodes(data=True)
        ],
        "edges": [
            {
                "source": u,
                "target": v,
                "edge_type": attrs["type"],
                "description": attrs["description"]
            }
            for u, v, attrs in G.edges(data=True)
        ]
    }
    
    json_output = "active_vis_graph.json"
    with open(json_output, "w", encoding="utf-8") as f:
        json.dump(active_data, f, ensure_ascii=False, indent=2)
    print(f"✨ 精简后的活跃图数据已导出至: {json_output}")

    # 5. 可视化渲染（仅包含活跃节点）
    plt.figure(figsize=(16, 12), dpi=100)
    
    # 颜色配置
    color_map = []
    labels = {}
    for node, attrs in G.nodes(data=True):
        labels[node] = attrs.get("label_zh", node)
        cat = attrs.get("category")
        if cat == "Scenario": color_map.append("#3182bd")
        elif cat == "Feature": color_map.append("#e6550d")
        elif cat == "Task": color_map.append("#31a354")
        else: color_map.append("#969696")

    edge_colors = [
        "#e6550d" if attrs.get("type") == "INVESTIGATES" else 
        "#31a354" if attrs.get("type") == "RESOLVED_BY" else "#7f7f7f"
        for u, v, attrs in G.edges(data=True)
    ]

    # 布局计算
    pos = nx.spring_layout(G, k=0.6, iterations=60, seed=42)
    
    nx.draw_networkx_nodes(G, pos, node_color=color_map, node_size=1100, alpha=0.85)
    nx.draw_networkx_edges(G, pos, edge_color=edge_colors, width=1.2, arrows=True, arrowsize=12)
    nx.draw_networkx_labels(G, pos, labels=labels, font_size=8, font_weight="bold")

    plt.title("科学可视化系统：活跃分析场景与算法知识图谱 (已剔除未激活组件)", fontsize=14, pad=20)
    plt.axis("off")
    plt.tight_layout()
    
    img_output = "active_vis_graph.png"
    plt.savefig(img_output, bbox_inches="tight")
    print(f"✨ 活跃拓扑图已保存为: {img_output}")
    plt.show()

    return G

if __name__ == "__main__":
    active_kg = build_active_knowledge_graph("nodes.csv", "edges.csv")