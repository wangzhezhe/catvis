from pathlib import Path

def remove_operation_files(folder_name="context-vis-json"):
    # Target the directory relative to where the script is run
    folder_path = Path(folder_name)
    
    # Check if the folder actually exists to avoid errors
    if not folder_path.exists() or not folder_path.is_dir():
        print(f"Error: The folder '{folder_name}' does not exist.")
        return

    print(f"Scanning '{folder_name}' for *_operations.json files...\n")
    deleted_count = 0

    # Iterate through all files matching the pattern
    for file_path in folder_path.glob("*_operations.json"):
        try:
            # Delete the file
            file_path.unlink()
            print(f"Deleted: {file_path.name}")
            deleted_count += 1
        except Exception as e:
            print(f"Failed to delete {file_path.name}: {e}")

    print(f"\nDone! Total files removed: {deleted_count}")

if __name__ == "__main__":
    remove_operation_files()