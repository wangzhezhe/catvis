# VTK Dataset Analysis: Rotor37-100-101325pa_001.vtm

# The data can be accessed by using ..\..\datasets\Rotor37-100-101325pa_001\Rotor37-100-101325pa_001.vtm in template file

## Global Spatial Bounds
- **X Range:** [0.1623, 0.2547]
- **Y Range:** [-0.0911, 0.0894]
- **Z Range:** [-0.0419, 0.1067]

## Data Set Blocks (Sub-meshes)
| Block Name | X Range | Y Range | Z Range |
|---|---|---|---|
| **Step 300 Incr 0** | [0.16, 0.25] | [-0.09, 0.09] | [-0.04, 0.11] |
| **R1 Blade Step 300 Incr 0** | [0.18, 0.25] | [-0.03, 0.02] | [0.00, 0.04] |
| **R1 Hub Step 300 Incr 0** | [0.16, 0.19] | [-0.07, 0.05] | [-0.04, 0.11] |
| **R1 Inlet Step 300 Incr 0** | [0.16, 0.25] | [-0.09, -0.04] | [-0.04, -0.04] |
| **R1 Outlet Step 300 Incr 0** | [0.19, 0.23] | [0.01, 0.09] | [0.11, 0.11] |
| **R1 Shroud Step 300 Incr 0** | [0.22, 0.25] | [-0.09, 0.09] | [-0.04, 0.11] |
| **R1 to R1 Internal Side 1 Step 300 Incr 0** | [0.24, 0.25] | [-0.03, 0.02] | [0.01, 0.03] |
| **R1 to R1 Internal Side 2 Step 300 Incr 0** | [0.24, 0.25] | [-0.03, 0.02] | [0.01, 0.03] |
| **R1 to R1 Periodic 1 Side 1 Step 300 Incr 0** | [0.16, 0.25] | [-0.09, 0.05] | [-0.04, 0.11] |
| **R1 to R1 Periodic 1 Side 2 Step 300 Incr 0** | [0.17, 0.25] | [-0.05, 0.09] | [-0.04, 0.11] |

hub is "R1 Hub Step 300 Incr 0"
shroud is "R1 Shroud Step 300 Incr 0"
blade is "R1 Blade Step 300 Incr 0"

## axis of rotation direction
[0,0,1]

## Variable Data Ranges
| Variable | Components | Data Range (Min, Max) |
|---|---|---|
| `Thermal Conductivity` | 1 | [2.6100e-02, 2.6100e-02] |
| `Specific Heat` | 1 | [1.0044e+03, 1.0044e+03] |
| `Density` | 1 | [2.5011e-01, 2.4694e+00] |
| `Beta Density` | 1 | [5.8413e-06, 1.0000e+00] |
| `Total Density` | 1 | [8.0433e-02, 1.7475e+00] |
| `Static Entropy` | 1 | [-3.7995e+01, 4.1628e+02] |
| `Shear Strain Rate` | 1 | [1.1616e+02, 3.6751e+07] |
| `Static Enthalpy` | 1 | [-7.0455e+04, 1.1022e+05] |
| `Mach Number` | 1 | [1.0000e-15, 1.7654e+00] |
| `Volume Porosity` | 1 | [1.0000e+00, 1.0000e+00] |
| `Pressure` | 1 | [2.0142e+04, 2.7810e+05] |
| `Absolute Pressure` | 1 | [2.0142e+04, 2.7810e+05] |
| `Total Pressure` | 1 | [4.0277e+03, 1.7831e+05] |
| `Temperature` | 1 | [2.2800e+02, 4.0789e+02] |
| `Total Temperature` | 1 | [1.6241e+02, 4.0789e+02] |
| `Turbulent Kinetic Energy` | 1 | [3.2126e+00, 8.7813e+03] |
| `Aspect Ratio` | 1 | [1.0807e+00, 1.5582e+03] |
| `Rothalpy.Beta` | 1 | [0.0000e+00, 1.0000e+00] |
| `Polytropic Compression Efficiency` | 1 | [6.7997e-04, 1.0000e+00] |
| `Isentropic Compression Efficiency` | 1 | [6.5213e-04, 1.0000e+00] |
| `Isothermal Compressibility` | 1 | [3.5958e-06, 4.9646e-05] |
| `Courant Number` | 1 | [6.5137e-01, 1.4040e+04] |
| `Volume of Finite Volumes` | 1 | [1.7123e-17, 3.1627e-08] |
| `Total Density in Rel Frame` | 1 | [2.5011e-01, 3.2943e+00] |
| `Total Density in Stn Frame` | 1 | [4.5295e-01, 4.4004e+00] |
| `Rothalpy` | 1 | [-1.3633e+05, 1.1022e+05] |
| `Total Enthalpy in Stn Frame` | 1 | [-5.3759e+04, 2.0983e+05] |
| `Total Enthalpy` | 1 | [-4.7816e+04, 2.0794e+05] |
| `Polytropic Expansion Efficiency` | 1 | [1.3922e-01, 1.0000e+00] |
| `Isentropic Expansion Efficiency` | 1 | [1.5641e-01, 1.0000e+00] |
| `Wall Heat Transfer Coefficient` | 1 | [0.0000e+00, 8.8373e+03] |
| `Isentropic Total Enthalpy` | 1 | [-1.1599e+05, 1.8705e+05] |
| `Polytropic Total Enthalpy` | 1 | [-1.4059e+05, 1.8965e+05] |
| `Mach Number in Stn Frame` | 1 | [1.0000e-15, 1.3900e+00] |
| `Mesh Expansion Factor` | 1 | [1.0001e+00, 1.2569e+01] |
| `Nonoverlap Fraction` | 1 | [0.0000e+00, 4.2599e-01] |
| `Orthogonality Angle` | 1 | [4.4987e-01, 1.5651e+00] |
| `Real Partition Number` | 1 | [1.0000e+00, 1.2000e+01] |
| `Rotational Energy` | 1 | [4.9740e+04, 1.0671e+05] |
| `Local Speed of Sound` | 1 | [3.0276e+02, 4.0494e+02] |
| `Specific Heat Capacity at Constant Volume` | 1 | [7.1730e+02, 7.1730e+02] |
| `Specific Volume` | 1 | [4.0496e-01, 3.9982e+00] |
| `Turbulence Eddy Dissipation` | 1 | [1.2446e+04, 4.5566e+10] |
| `Turbulence Eddy Frequency` | 1 | [3.6375e+04, 1.0274e+08] |
| `Wall Adjacent Temperature` | 1 | [0.0000e+00, 4.0789e+02] |
| `U` | 1 | [-1.8028e+02, 2.4934e+02] |
| `V` | 1 | [-7.4375e+01, 5.1730e+02] |
| `W` | 1 | [-2.0630e+02, 3.5355e+02] |
| `Dynamic Viscosity` | 1 | [1.8310e-05, 1.8310e-05] |
| `Eddy Viscosity` | 1 | [2.0452e-05, 4.4180e-02] |
| `Solver Y Plus` | 1 | [0.0000e+00, 1.2452e+01] |
| `Node UserID` | 1 | [1.0000e+00, 9.4720e+05] |
| `VectorVelocity` | 3 | [-1.8028e+02, 2.4934e+02] / [-7.4375e+01, 5.1730e+02] / [-2.0630e+02, 3.5355e+02] |
