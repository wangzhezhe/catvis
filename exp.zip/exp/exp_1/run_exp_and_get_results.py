# Use prompt to generate workflow template
# There are four types of combination
# only using example in external_knowledge\prompt_wflow_example.md
# using example in external_knowledge\prompt_wflow_example.md+external_knowledge\prompt_wflow_rules.md
# using example in external_knowledge\prompt_wflow_example.md+external_knowledge\prompt_wflow_rules.md+filter_name_descriptions.json
# using example in external_knowledge\prompt_wflow_example.md+external_knowledge\prompt_wflow_rules.md+filter_parameter_descriptions.json
# using .env file CSTCLOUD_API_KEY to get api key and CSTCLOUD_BASE_URL to get base url
# go through case test folder and execute case by case



import os
import json
from pathlib import Path
from openai import OpenAI
from dotenv import load_dotenv
from pathlib import Path

load_dotenv()

client = OpenAI(
    api_key=os.getenv("CSTCLOUD_API_KEY"),
    base_url=os.getenv("CSTCLOUD_BASE_URL"),
)

print("client base url:",client.base_url)

BASE_DIR = Path(__file__).parent
print("base dir:",BASE_DIR)

EXTERNAL_DIR = BASE_DIR / "external_knowledge"
CASE_DIR = BASE_DIR / "../../sample_vis_workflow"
RESULT_DIR = BASE_DIR / "results"

CONFIGS = {
    "EX": ["example"],
    "EX-R": ["example", "rules"],
    "EX-R-OD": ["example", "rules", "operator_desc"],
    "EX-R-OD-PD": ["example", "rules", "param_desc"], # param_desc have contained operator_desc
    "EX-R-OD-PD-DATA": ["example", "rules", "param_desc","data_desc"], # param_desc have contained operator_desc
}

# 可选值: "EX", "EX-R", "EX-R-OD", "EX-R-OD-PD", "ALL"
def get_selected_configs(selected_config="ALL"):
    """根据 selected_config 返回要运行的配置"""
    # 如果是字符串 "ALL"，返回全部配置
    if selected_config == "ALL":
        print(f"将运行全部 {len(CONFIGS)} 种配置: {list(CONFIGS.keys())}")
        return CONFIGS
    
    # 如果是字符串且是单个配置名
    elif isinstance(selected_config, str) and selected_config in CONFIGS:
        print(f"将运行单个配置: {selected_config}")
        return {selected_config: CONFIGS[selected_config]}
    
    # 如果是列表，返回列表中的配置
    elif isinstance(selected_config, list):
        selected = {}
        for config_name in selected_config:
            if config_name in CONFIGS:
                selected[config_name] = CONFIGS[config_name]
            else:
                print(f"警告: 无效的配置 '{config_name}'，跳过")
        
        if not selected:
            print(f"警告: 没有有效的配置，将使用全部配置")
            return CONFIGS
        
        print(f"将运行 {len(selected)} 种配置: {list(selected.keys())}")
        return selected
    
    # 其他情况，默认返回全部
    else:
        print(f"警告: 无效的配置选择 '{selected_config}'，将使用全部配置")
        print(f"可用配置: {list(CONFIGS.keys())}")
        return CONFIGS
    
print("EXTERNAL_DIR is:",EXTERNAL_DIR)
def load_external_knowledge(components: list[str]) -> str:
    prompt = ""
    
    if "example" in components:
        example_path = EXTERNAL_DIR / "prompt_wflow_example.md"
        if example_path.exists():
            prompt += "## Workflow Examples\n"
            # 显式转换确保万无一失，虽然 read_text 理论上返回 str
            content = str(example_path.read_text(encoding="utf-8"))
            prompt += content + "\n\n"
        else:
            print(f"Warning: {example_path} not found.")

    if "rules" in components:
        rules_path = EXTERNAL_DIR / "prompt_wflow_rules.md"
        prompt += "## Workflow Construction Rules\n"
        prompt += rules_path.read_text(encoding="utf-8") + "\n\n"

    if "operator_desc" in components:
            desc_path = EXTERNAL_DIR / "filter_name_descriptions.json"
            # 直接读取文件内容并追加
            prompt += "## Operator Descriptions (JSON)\n"
            prompt += desc_path.read_text(encoding="utf-8") + "\n\n"

    if "param_desc" in components:
        param_path = EXTERNAL_DIR / "filter_parameter_descriptions.json"
        # 直接读取文件内容并追加
        prompt += "## Operator and Parameter Descriptions (JSON)\n"
        prompt += param_path.read_text(encoding="utf-8") + "\n\n"

    if "data_desc" in components:
        param_path = EXTERNAL_DIR / "data_description.md"
        # 直接读取文件内容并追加
        prompt += "## Description of the dataset used for visualization\n"
        prompt += param_path.read_text(encoding="utf-8") + "\n\n"

    return prompt


MODEL = "deepseek-v3:671b"
def check_api_connectivity():
    """在正式开始前测试 API 是否连通"""
    print(f"正在测试 API 连接: {client.base_url} ...", end="", flush=True)
    try:
        # 发送一个极简的请求来测试连通性
        client.chat.completions.create(
            model=MODEL,
            messages=[{"role": "user", "content": "hi"}],
            max_tokens=5
        )
        print(" [OK] 连接成功！")
        return True
    except Exception as e:
        print(f" [FAILED] 无法连接到 API。错误信息: {e}")
        return False

import time
def generate_workflow(query: str, system_prompt: str, config_name: str = "default", case_result_path: Path = None) -> tuple[str, str]:
    """
    调用 LLM 生成 workflow，并返回 (正式内容, 思考过程)
    """
    try:
        start_time = time.time()
        response = client.chat.completions.create(
            model=MODEL,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": query},
            ],
            temperature=0,  # 确保结果一致性
            stream=False
        )

        end_time = time.time()
        duration = end_time - start_time

        message_obj = response.choices[0].message
        
        # 1. 提取正式回答
        content = message_obj.content or ""
        
        # 2. 提取思考过程 (支持 DeepSeek 系列模型的 reasoning_content)
        reasoning = getattr(message_obj, 'reasoning_content', "")

        usage = response.usage # 包含 prompt_tokens, completion_tokens 等
        print(f"    Usage: {usage}")

        # 3. 如果提供了路径，将思考过程单独存证，方便分析模型为何这样构造 Workflow
        if case_result_path:

            # 3. 记录 Usage 和耗时 (修正覆盖问题和类型问题)
            usage_log_path = case_result_path / f"{config_name}_usage.log"
            usage_info = (
                f"Model: {MODEL}\n"
                f"Prompt Tokens: {usage.prompt_tokens}\n"  # the tokem used for input
                f"Completion Tokens: {usage.completion_tokens}\n" # the token used for output
                f"Total Tokens: {usage.total_tokens}\n"
                f"Duration: {duration:.2f}s\n"
            )
            usage_log_path.write_text(usage_info, encoding="utf-8")


        if case_result_path and reasoning:
            log_file = case_result_path / f"{config_name}_reasoning.log"
            log_file.write_text(reasoning, encoding="utf-8")
            
            print(f"    Thinking process saved to {log_file.name}")

        

        return content, reasoning

    except Exception as e:
        print(f"    Error during API call: {e}")
        return "", ""

def generate_workflow_with_retry(query: str, system_prompt: str, config_name: str = "default", 
                                  case_result_path: Path = None, max_retries: int = 3, 
                                  retry_delay: int = 5) -> tuple[str, str]:
    """
    调用 LLM 生成 workflow，支持重试机制
    返回 (正式内容, 思考过程)
    """
    for attempt in range(max_retries):
        try:
            start_time = time.time()
            response = client.chat.completions.create(
                model=MODEL,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": query},
                ],
                temperature=0,
                stream=False
            )

            end_time = time.time()
            duration = end_time - start_time

            message_obj = response.choices[0].message

            # 提取正式回答
            content = message_obj.content or ""

            # 提取思考过程
            reasoning = getattr(message_obj, 'reasoning_content', "")

            usage = response.usage
            print(f"    Usage: {usage}")

            # 保存 Usage 和耗时
            if case_result_path:
                usage_log_path = case_result_path / f"{config_name}_usage.log"
                usage_info = (
                    f"Model: {MODEL}\n"
                    f"Prompt Tokens: {usage.prompt_tokens}\n"
                    f"Completion Tokens: {usage.completion_tokens}\n"
                    f"Total Tokens: {usage.total_tokens}\n"
                    f"Duration: {duration:.2f}s\n"
                )
                usage_log_path.write_text(usage_info, encoding="utf-8")

            if case_result_path and reasoning:
                log_file = case_result_path / f"{config_name}_reasoning.log"
                log_file.write_text(reasoning, encoding="utf-8")
                print(f"    Thinking process saved to {log_file.name}")

            return content, reasoning

        except Exception as e:
            print(f"    Attempt {attempt + 1}/{max_retries} failed: {e}")
            if attempt < max_retries - 1:
                print(f"    Retrying in {retry_delay} seconds...")
                time.sleep(retry_delay)
            else:
                print(f"    All {max_retries} attempts failed.")
                return "", ""

    return "", ""

def get_unique_dir(base_path: Path) -> Path:
    """如果目录已存在，则添加 _1, _2 等后缀"""
    if not base_path.exists():
        return base_path
    counter = 1
    while True:
        new_path = base_path.with_name(f"{base_path.name}_{counter}")
        if not new_path.exists():
            return new_path
        counter += 1

def extract_yaml(raw: str) -> str:
    """从LLM返回内容中提取yaml代码块"""
    if "```yaml" in raw:
        return raw.split("```yaml")[1].split("```")[0].strip()
    elif "```" in raw:
        return raw.split("```")[1].split("```")[0].strip()
    return raw.strip()


def find_query_file_and_open(case_dir: Path) -> Path | None:
    """在case目录中找query文件"""
    for candidate in ["query.txt", "query.md"]:
        p = case_dir / candidate
        if p.exists():
            query_path=p
            return query_path.read_text(encoding='utf-8')
    return ""


def get_tier(case_name: str) -> str:
    if case_name.startswith("easy"):
        return "easy"
    elif case_name.startswith("mid"):
        return "medium"
    elif case_name.startswith("hard"):
        return "hard"
    return "unknown"

def run():

    RESULT_DIR.mkdir(exist_ok=True)
    BATCH_CONFIGS = {
        # "hard-case1": "ALL",
        # "hard-case2": "ALL",
        "hard-case3": "ALL",
        "hard-case4": "ALL",
        "hard-case5": "ALL"
    }

    # prepare system prompt
    for config_name, components in CONFIGS.items():
        print(f"\n{'='*50}")
        print(f"Configuration: {config_name}")
        print(f"{'='*50}")
        system_prompt=""  
        system_prompt += load_external_knowledge(components)
        
        # TODO wirte system prompt in a file label by case_config_name
        prompt_filename = f"{config_name}_prompt.txt"
        # prompt_filepath = RESULT_DIR / prompt_filename
        # prompt_filepath.write_text(system_prompt, encoding="utf-8")
        # print(f"Input System prompt saved to: {prompt_filepath}")


    # 收集所有case目录
    case_dirs = sorted([d for d in CASE_DIR.iterdir() if d.is_dir()])

    print("case_dirs",case_dirs)

    summary = []

    # test the hard case
    # test_case = Path('../../sample_vis_workflow/easy-case4')
    success_count = 0
    fail_count = 0
    fail_details = []

    # 遍历批量配置
    for case_name, config_choice in BATCH_CONFIGS.items():
        print(f"\n{'='*70}")
        print(f"Processing case: {case_name}")
        print(f"{'='*70}")
        
        # 构建case路径
        case_path = CASE_DIR / case_name
        
        # 检查case是否存在
        if not case_path.exists():
            print(f"  警告: Case路径不存在: {case_path}")
            fail_details.append(f"{case_name}: 路径不存在")
            fail_count += 1
            continue
        
        # 读取query内容
        query_contents = find_query_file_and_open(case_path)
        if not query_contents:
            print(f"  警告: 未找到 query.txt 或 query.md 文件")
            fail_details.append(f"{case_name}: 未找到query文件")
            fail_count += 1
            continue
        
        print(f"  Query内容: {query_contents[:100]}..." if len(query_contents) > 100 else f"  Query内容: {query_contents}")
        
        # 创建case结果目录
        case_result_path = RESULT_DIR / case_name
        case_result_path.mkdir(exist_ok=True)
        
        # 保存query文件
        query_filepath = case_result_path / f"{case_name}_query.txt"
        query_filepath.write_text(query_contents, encoding="utf-8")
        
        # 获取要运行的配置
        selected_configs = get_selected_configs(config_choice)
        
        # 针对当前case，运行选定的配置
        case_success = False
        for config_name, components in selected_configs.items():
            print(f"    - Testing Configuration: {config_name}")
            
            # 加载外部知识构建系统提示词
            system_prompt = load_external_knowledge(components)
            
            # 保存系统提示词
            prompt_filename = f"{config_name}_system_prompt.txt"
            (case_result_path / prompt_filename).write_text(system_prompt, encoding="utf-8")
            
            try:
                # 调用 LLM 生成 workflow（带重试机制）
                raw_response, reasoning = generate_workflow_with_retry(
                    query_contents,
                    system_prompt,
                    config_name=config_name,
                    case_result_path=case_result_path,
                    max_retries=3,
                    retry_delay=5
                )
                
                if not raw_response:
                    print(f"      [Skip] No response for {config_name}")
                    fail_details.append(f"{case_name}/{config_name}: 无响应")
                    continue
                
                # 提取 YAML 内容
                yaml_content = extract_yaml(raw_response)
                
                # 保存结果
                raw_output_file = case_result_path / f"{config_name}_raw_response.md"
                raw_output_file.write_text(raw_response, encoding="utf-8")
                
                yaml_output_file = case_result_path / f"{config_name}_workflow.yaml"
                yaml_output_file.write_text(yaml_content, encoding="utf-8")
                
                print(f"      Done. Saved to {yaml_output_file}")
                case_success = True
                success_count += 1
                time.sleep(1)  # 请求间隔
                
            except Exception as e:
                print(f"      Error calling LLM for {config_name}: {e}")
                fail_details.append(f"{case_name}/{config_name}: {str(e)}")
        
        if case_success:
            print(f"  Case {case_name} 处理完成")
        else:
            print(f"  Case {case_name} 所有配置均失败")
            fail_count += 1
        
        time.sleep(2)  # case之间的间隔
    
    # 输出统计结果
    print(f"\n{'='*70}")
    print(f"批量处理完成统计:")
    print(f"{'='*70}")
    print(f"成功生成的配置数: {success_count}")
    print(f"失败的配置/case数: {len(fail_details)}")
    if fail_details:
        print(f"\n失败详情:")
        for detail in fail_details:
            print(f"  - {detail}")
    print(f"{'='*70}")


if __name__ == "__main__":
    run()