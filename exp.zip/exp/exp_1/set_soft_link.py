import sys
import os 
import time

print(sys.path)

# from gwlalg.workflow import workflow_composer
# from gwlalg.alg import alg_task
from pathlib import Path

# set soft link for datasets
# 设置路径
current_dir = Path(__file__).parent
print("current_dir: ", current_dir)
# 假设你的数据集实际位置在项目根目录的 datasets
actual_datasets_path = current_dir / "../../datasets" 
# 目标链接位置（当前目录下）
link_path = current_dir / "datasets"

def setup_dataset_link():
    if not link_path.exists():
        try:
            # Windows 下创建目录软链接需要 target_is_directory=True
            # 注意：在 Windows 上运行此脚本可能需要管理员权限
            os.symlink(actual_datasets_path.resolve(), link_path, target_is_directory=True)
            print(f"Successfully created symlink: {link_path} -> {actual_datasets_path}")
        except OSError as e:
            print(f"Failed to create symlink: {e}")
            print("Tip: Run your terminal as Administrator.")
    else:
        print("Dataset link already exists.")

# 在加载任务前执行
setup_dataset_link()

# alg_task.load_all_tasks()

# # gwl_catalog = workflow_composer.Catalog()
# start_time = time.perf_counter()
# config_list = ["EX_workflow.yaml","EX-R_workflow.yaml","EX-R-OD_workflow.yaml","EX-R-OD-PD_workflow.yaml","EX-R-OD-PD-DATA_workflow.yaml"]


# for config in config_list:

#     # build the workflow
#     workflow = workflow_composer.Workflow(config)
#     # run the workflow
#     workflow.run()    
#     end_time = time.perf_counter()

#     elapsed_time = end_time - start_time
#     print(f"Elapsed time for whole tests: {elapsed_time:.4f} seconds")
