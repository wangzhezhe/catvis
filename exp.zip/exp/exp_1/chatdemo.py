import os
import json
from pathlib import Path
from openai import OpenAI
from dotenv import load_dotenv
from pathlib import Path

load_dotenv()

client = OpenAI(
    api_key=os.getenv("CSTCLOUD_API_KEY"),
    base_url=os.getenv("CSTCLOUD_BASE_URL"),
)

print("client base url:",client.base_url)

def chat_demo_stream(model="deepseek-r1:671b", message="你好，请介绍一下你自己, 100个字", stream=True):
    response = client.chat.completions.create(
        model=model,
        messages=[
            {"role": "user", "content": message}
        ],
        stream=stream,
        # 针对 deepseek-r1 的建议设置
        temperature=0.0
    )

    if stream:
        print("Assistant: ", end="")
        for chunk in response:
            # --- 关键修复：先判断 choices 是否存在且不为空 ---
            if not chunk.choices:
                # 这种情况通常是最后一个 chunk，包含了 usage 信息
                if hasattr(chunk, 'usage') and chunk.usage:
                    print(f"\n[Usage]: Total tokens: {chunk.usage.total_tokens}")
                continue

            delta = chunk.choices[0].delta
            
            # 提取推理过程
            if hasattr(delta, 'reasoning_content') and delta.reasoning_content:
                # 使用灰色字体区分思考过程 (可选)
                print(f"\033[90m{delta.reasoning_content}\033[0m", end="", flush=True)
            
            # 提取内容
            if delta.content:
                print(delta.content, end="", flush=True)
        print()
    else:
        # 非流式部分通常不需要这个判断，因为它是完整返回的
        print(f"Assistant: {response.choices[0].message.content}")


def chat_demo_nonstream(model="deepseek-r1:671b", message="你好，请简要介绍你自己, 100个字"):
    """非流式输出演示 (TODO 完善部分)"""
    print(f"\n--- Starting Non-Stream Chat ({model}) ---")
    response = client.chat.completions.create(
        model=model,
        messages=[
            {"role": "user", "content": message}
        ],
        stream=False,
        temperature=0.0
    )

    message_obj = response.choices[0].message
    
    # 尝试获取思考过程 (CSTCloud API 在非流式下也会返回该字段)
    reasoning = getattr(message_obj, 'reasoning_content', None)
    content = message_obj.content

    if reasoning:
        print(f"Assistant Thinking:\n{reasoning}\n")
    
    print(f"Assistant Content:\n{content}")
    
    # 打印 Token 消耗情况 (可选)
    if hasattr(response, 'usage'):
        print(f"\n[Usage]: Prompt {response.usage.prompt_tokens}, Completion {response.usage.completion_tokens}")

if __name__ == "__main__":
    MODEL = "deepseek-v3:671b"
    chat_demo_stream(model=MODEL)
    print("--- Non-Stream Chat Example---")
    chat_demo_nonstream(model=MODEL)