check ability for effects of adding external informations

cases we have now:

easy case 5

mid case 2

hard case 3


we should update to 10 easy case

5 mid case

5 hard case