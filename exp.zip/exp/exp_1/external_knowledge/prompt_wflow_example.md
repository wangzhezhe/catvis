You are an expert in generating specific workflow templates. 
Your goal is to produce a pure YAML file without any Markdown formatting or code block delimiters.
A workflow is a YAML file that defines a sequence of data processing and visualization tasks. 
You could refer to these examples when generating a workflow.

## Simple Example

**Query:**

Load a dataset from `../../datasets/example/example.vtm`, apply a clip operation 
with origin [0.01, 0.1, -0.2] and normal [0, 0, 1], and write the result to 
the dataset folder.

**Workflow:**
```yaml
name: basic_clip_workflow  
params:  
  input_dataset: ../../datasets/Rotor37-100-101325pa_001/Rotor37-100-101325pa_001.vtm

tasks:
  IDLoadingData:
    name: 读入.vtm数据
    from: vtkmDataLoader
    inputs:
      - data_file: $globals.params.input_dataset
    output: IDLoadingData_output

  IDPreprocess:
    name: 数据预处理
    from: Preprocess
    inputs:
      - data: $IDLoadingData.IDLoadingData_output
      - merge: False
    output: IDPreprocess_output

  IDClip:
    name: 裁剪
    from: Clip
    inputs:
      - data: $IDPreprocess.IDPreprocess_output
      - origin: [0.01, 0.1, -0.2]
      - normal: [0, 0, 1]
      - insideout: True
    output: IDClip_output

  IDoneVTKDataWriter:
    name: 写出单块vtk数据
    from: oneVTKDataWriter
    inputs:
      - data: $IDClip.IDClip_output
      - output_dir: .\data
      - output_file_name: data_test_clip_result.vtp
    output: IDoneVTKDataWriter_output
```
---

## Complex Example
**Query:**
load a data set from ../../datasets/Rotor37-100-101325pa_001/Rotor37-100-101325pa_001.vtm,
preprocess the data, compute span normal, extract isosurface at 98% span,
create two parallel branches with different clip directions and rotation angles,
apply rotational duplication and Z-Theta view transformation on each branch,
merge the two processed results, and output as a single VTU file.

**Workflow:**
```yaml
name: basic_workflow  
params:  
  input_dataset:  ../../datasets/Rotor37-100-101325pa_001/Rotor37-100-101325pa_001.vtm

tasks:
  IDLoadingData:
    name: 读入.vtm数据
    from: vtkmDataLoader
    inputs:
      - data_file: $globals.params.input_dataset
    output: IDLoadingData_output

  IDPreprocess:
    name: 数据预处理
    from: Preprocess
    inputs:
      - data: $IDLoadingData.IDLoadingData_output
      - merge: False
    output: IDPreprocess_output

  IDSpanNormal:
    name: 计算叶高
    from: SpanNormal
    inputs:
      - data: $IDPreprocess.IDPreprocess_output
      - hub: ["R1 Hub Step*"]        # 匹配所有以"R1 Hub Step"开头的块
      - shroud: ["R1 Shroud Step*"]  # 匹配所有以"R1 Shroud Step"开头的块
      - origin: [0,0,0]
      - axis: [0,0,1]
    output: IDSpanNormal_output

  IDIso:
    name: 等值面
    from: IsoSurface
    inputs:
      - data: $IDSpanNormal.IDSpanNormal_output
      - variable_name: SpanNormal
      - isovalue: 0.98
    output: IDIso_output

  IDClip1:
    name: 裁剪
    from: Clip
    inputs:
      - data: $IDIso.IDIso_output
      - origin: [0,0,-0.162]
      - normal: [0,0,1]
      - insideout: True
    output: IDClip1_output

  IDDuplicate1:
    name: 旋转复制
    from: RotDuplication
    inputs:
      - data: $IDClip1.IDClip1_output
      - origin: [0.0, 0.0, 0.0]         # 旋转中心
      - axis_vector: [0.0, 0.0, 1.0]    # 绕Z轴旋转
      - degree: 22.5                    # 每次旋转角度 (360/16)
      - clockwise: True                 # 顺时针旋转
      - num_copies: 3                  # 复制数量
      - merge: True                    # 是否合并输出 (False = 多块输出)
    output: IDDuplicate1_output

  IDZThetaView1:
    name: Z-Theta视图转换
    from: ZThetaView
    inputs:
      - data: $IDDuplicate1.IDDuplicate1_output
      - theta_scale: 0.2
    output: IDZThetaView1_output

  IDClip2:
    name: 裁剪
    from: Clip
    inputs:
      - data: $IDIso.IDIso_output
      - origin: [0,0,-0.162]
      - normal: [0,0,1]
      - insideout: False
    output: IDClip2_output

  IDDuplicate2:
    name: 旋转复制
    from: RotDuplication
    inputs:
      - data: $IDClip2.IDClip2_output
      - origin: [0.0, 0.0, 0.0]         # 旋转中心
      - axis_vector: [0.0, 0.0, 1.0]    # 绕Z轴旋转
      - degree: 11.25                   # 每次旋转角度 (360/32)
      - clockwise: True                 # 顺时针旋转
      - num_copies: 3                  # 复制数量
      - merge: True                    # 是否合并输出 (False = 多块输出)
    output: IDDuplicate2_output

  IDZThetaView2:
    name: Z-Theta视图转换
    from: ZThetaView
    inputs:
      - data: $IDDuplicate2.IDDuplicate2_output
      - theta_scale: 0.2
    output: IDZThetaView2_output

  IDDataCombiner:
    name: 数据字典合并器
    from: FilterList
    inputs:
      - data: ["$IDZThetaView1.IDZThetaView1_output", "$IDZThetaView2.IDZThetaView2_output"]
      - merge_strategy: suffix
    output: IDDataCombiner_output

  IDoneVTKDataWriter:
    name: 写出单块vtk数据
    from: oneVTKDataWriter
    inputs:
      - data: $IDDataCombiner.IDDataCombiner_output
      - output_dir: .\data
      - output_file_name: data_test_ztheta.vtu
    output: Final_output
```