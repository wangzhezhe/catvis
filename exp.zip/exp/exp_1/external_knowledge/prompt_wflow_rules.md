You could follow these rules strictly when generating a workflow.

## Structure Rules

A workflow file has two top-level fields:
- `name`: a short string identifier for the workflow
- `params`: global parameters accessible via `$globals.params.<key>`
- `tasks`: a dictionary of task definitions, each with a unique ID as the key

## Task Definition Rules

Each task must contain exactly these fields:
- `name`: a human-readable Chinese or English label for the task, CRITICAL: remember to add name field in the task definition anayway
- `from`: the operator name (must be chosen from the provided operator list)
- `inputs`: a list of key-value pairs defining the input arguments, each value under the `inputs` field must be a list of key-value pairs
- `output`: a string identifier for the output of this task

## Data Flow Rules

- The output of a task is referenced by other tasks using the syntax:
  `$<TaskID>.<output_value>`
  
  **CRITICAL**: `<output_value>` MUST be exactly the string assigned to the task's `output` field.

- For example:
  ```yaml
  tasks:
    IDLoadData:
      name: LoadData
      from: vtkmDataLoader
      inputs:
        - data_file: $globals.params.input_dataset
      output: loaded_data    # ← 这是 output_value
  
    IDProcess:
      name: Preprocess
      from: Preprocess
      inputs:
        - data: $IDLoadData.loaded_data    # ← 引用时必须写 $IDLoadData.loaded_data
      output: processed_data

- For example, if task `IDLoadingData` has `output: IDLoadingData_output`, 
  downstream tasks reference it as `$IDLoadingData.IDLoadingData_output`
- Every task except the first must receive its primary `data` input from 
  the output of a preceding task
- Multiple tasks can reference the same upstream output, enabling branching pipelines
- Tasks are executed in dependency order, not necessarily in the order they appear in the file


## Data Field Rules

### Single Data Input
- Default format for most operators: `- data: $<TaskID>.<output_field>`
- Use this when an operator expects one dataset
- CRITICAL: Every operator (e.g., Streamline, IsoVolume, Slice) requires a - data field to specify which dataset it is operating on. Do not omit the `- data` input even when other parameters are present.

### Multiple Data Inputs (Array Syntax)
- **Only `FilterList` accepts array/list syntax** for combining multiple outputs
- Format: `- data: [$<TaskID>.<output_field>, $<TaskID>.<output_field>, ...]`
- Example:
  ```yaml
  IDFilterList:
    name: FilterList
    from: FilterList
    inputs:
      - data: [$IDStreamline.IDStreamline_output, $IDIsoVolume.IDIsoVolume_output]
    output: IDFilterList_output
 - Never use list syntax for any other operator (including MergeDataSets)

## Task ID Rules

- Each task must have a unique ID as its dictionary key (e.g. `IDLoadingData`, 
  `IDPreprocess`, `IDIso`)
- If multiple tasks use the same operator, distinguish them with a numeric 
  suffix (e.g. `IDIso1`, `IDIso2`)

## Pipeline Entry and Exit Rules

- Every pipeline must begin with a data loading task such as `vtkmDataLoader` or `vtkDataLoader`
  operator, which reads the input dataset from `$globals.params.input_dataset`
- Every pipeline must end with one or more `oneVTKDataWriter` tasks that write 
  results to disk, specifying `output_dir` and `output_file_name`
- Multiple terminal writers are allowed for pipelines that produce 
  multiple output files

## Branching Rules

- A pipeline can branch from any intermediate task — multiple downstream tasks 
  can consume the same output
- For example, `IDPreprocess` output can feed into both `IDGeometryMapping` 
  and `IDSpanNormal` simultaneously
- Branches can later be merged using the `MergeDataSets` operator

## Operator Usage Rules

- Only operators from the provided operator list may be used in `from` fields
- Do not invent or assume operator names
- Each operator has a fixed set of required and optional parameters 
- Only use parameters defined in the operator description
- Parameter values must match the expected types (string, float, bool, list, etc.)
- When using a render filter like RenderServer, prioritize configuration from inputs over an external config file.

## Response Format Rules

- Output only the raw YAML content. > - DO NOT wrap the output in Markdown code blocks (e.g., no yaml or ).
- DO NOT include any introductory or explanatory text (e.g., no "Here is the workflow...").