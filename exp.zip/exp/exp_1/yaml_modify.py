import os
import re
from pathlib import Path

def modify_file_datasets_path(root_dir, target_folders=None, file_extensions=None):
    """
    遍历指定文件夹下所有子文件夹，修改指定格式文件中的datasets路径
    将 datasets 改为 ../../datasets
    
    Args:
        root_dir: 根目录路径
        target_folders: 要处理的文件夹名称列表，如果为None则处理所有文件夹
        file_extensions: 要处理的文件扩展名列表，如 ['.yaml', '.yml', '.md', '.txt']
                         如果为None，则默认处理所有文件
    """
    root_path = Path(root_dir)
    
    if not root_path.exists():
        print(f"错误: 路径不存在 - {root_dir}")
        return
    
    # 默认处理格式
    if file_extensions is None:
        file_extensions = ['.yaml', '.yml', '.md', '.txt']
    
    # 统计信息
    total_files = 0
    modified_files = 0
    error_files = []
    processed_folders = []
    
    # 遍历所有子文件夹
    for sub_dir in root_path.iterdir():
        if not sub_dir.is_dir():
            continue
        
        # 如果指定了目标文件夹，只处理匹配的文件夹
        if target_folders is not None and sub_dir.name not in target_folders:
            continue
        
        processed_folders.append(sub_dir.name)
        print(f"\n处理文件夹: {sub_dir.name}")
        
        # 查找该文件夹下的所有指定格式文件
        files_to_process = []
        for ext in file_extensions:
            files_to_process.extend(sub_dir.glob(f"*{ext}"))
        
        if not files_to_process:
            print(f"  未找到指定格式文件 ({', '.join(file_extensions)})")
            continue
        
        for file_path in files_to_process:
            total_files += 1
            try:
                # 读取文件内容
                with open(file_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                
                # 检查是否需要修改
                original_content = content
                
                # 替换 datasets 为 ../../datasets
                content = re.sub(r'datasets/', r'../../datasets/', content)
                
                # 如果内容有变化，写回文件
                if content != original_content:
                    with open(file_path, 'w', encoding='utf-8') as f:
                        f.write(content)
                    modified_files += 1
                    print(f"  已修改: {file_path.name}")
                    
                    # 显示修改示例
                    if "input_dataset:" in original_content or "datasets" in original_content:
                        old_paths = re.findall(r'datasets/[^\s\'"\n,]+', original_content)
                        new_paths = re.findall(r'\.\./\.\./datasets/[^\s\'"\n,]+', content)
                        
                        if old_paths and new_paths:
                            for old, new in zip(old_paths[:3], new_paths[:3]):
                                print(f"    旧路径: {old}")
                                print(f"    新路径: {new}")
                            if len(old_paths) > 3:
                                print(f"    ... 还有 {len(old_paths) - 3} 处修改")
                else:
                    print(f"  无需修改: {file_path.name}")
                    
            except Exception as e:
                error_files.append(f"{file_path}: {e}")
                print(f"  错误处理 {file_path.name}: {e}")
    
    # 输出统计信息
    print(f"\n{'='*60}")
    print(f"处理完成统计:")
    print(f"{'='*60}")
    print(f"处理的文件夹: {processed_folders}")
    print(f"处理文件格式: {file_extensions}")
    print(f"扫描文件总数: {total_files}")
    print(f"已修改文件数: {modified_files}")
    if error_files:
        print(f"错误文件数: {len(error_files)}")
        print(f"\n错误详情:")
        for error in error_files:
            print(f"  - {error}")
    print(f"{'='*60}")


def modify_file_datasets_path_dry_run(root_dir, target_folders=None, file_extensions=None):
    """
    预览模式：只显示将要修改的文件，不实际修改
    
    Args:
        root_dir: 根目录路径
        target_folders: 要处理的文件夹名称列表，如果为None则处理所有文件夹
        file_extensions: 要处理的文件扩展名列表
    """
    root_path = Path(root_dir)
    
    if not root_path.exists():
        print(f"错误: 路径不存在 - {root_dir}")
        return
    
    # 默认处理格式
    if file_extensions is None:
        file_extensions = ['.yaml', '.yml', '.md', '.txt']
    
    print(f"\n{'='*60}")
    print(f"预览模式 - 将修改以下文件:")
    print(f"{'='*60}")
    
    total_files = 0
    files_to_modify = []
    processed_folders = []
    
    for sub_dir in root_path.iterdir():
        if not sub_dir.is_dir():
            continue
        
        # 如果指定了目标文件夹，只处理匹配的文件夹
        if target_folders is not None and sub_dir.name not in target_folders:
            continue
        
        processed_folders.append(sub_dir.name)
        
        # 查找该文件夹下的所有指定格式文件
        files_to_process = []
        for ext in file_extensions:
            files_to_process.extend(sub_dir.glob(f"*{ext}"))
        
        for file_path in files_to_process:
            total_files += 1
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                
                # 检查是否包含需要修改的内容
                if 'datasets/' in content and '../../datasets/' not in content:
                    files_to_modify.append(file_path)
                    print(f"\n  {file_path}")
                    
                    # 显示匹配的路径
                    paths = re.findall(r'datasets/[^\s\'"\n,]+', content)
                    for path in paths[:5]:  # 最多显示5个
                        print(f"    将修改: {path} -> ../../{path}")
                    if len(paths) > 5:
                        print(f"    ... 还有 {len(paths) - 5} 处修改")
                        
            except Exception as e:
                print(f"  错误读取 {file_path.name}: {e}")
    
    print(f"\n{'='*60}")
    print(f"预览统计:")
    print(f"{'='*60}")
    print(f"处理的文件夹: {processed_folders}")
    print(f"处理文件格式: {file_extensions}")
    print(f"扫描文件总数: {total_files}")
    print(f"将修改文件数: {len(files_to_modify)}")
    print(f"{'='*60}")
    
    return files_to_modify


if __name__ == "__main__":
    # ========== 配置区域 ==========
    TARGET_DIR = r"C:\Users\~Low~\Desktop\文献\压气机\code\automaingworkflow\exp\exp_1\results"
    
    # ========== 指定要处理的文件夹 ==========
    TARGET_FOLDERS = [
        "easy-case1",
        "easy-case2",
        "easy-case3",
        "easy-case4",
        "easy-case5",
        "easy-case6",
        "easy-case7",
        "easy-case8",
        "easy-case9",
        "easy-case10",
        "mid-case1",
        "mid-case2",
        "mid-case3",
        "mid-case4",
        "mid-case5"
    ]
    
    
    
    # ========== 指定要处理的文件格式 ==========
    # 可选格式: '.yaml', '.yml', '.md', '.txt'
    FILE_EXTENSIONS = ['md']
    
    # ======================================
    
    # 选择模式:
    # True = 预览模式(只显示要修改的文件，不实际修改)
    # False = 实际修改模式
    DRY_RUN = True  # 先预览，确认后再改为 False
    # =============================
    
    print(f"目标目录: {TARGET_DIR}")
    if TARGET_FOLDERS:
        print(f"指定处理文件夹: {TARGET_FOLDERS}")
    else:
        print(f"处理所有文件夹")
    print(f"处理文件格式: {FILE_EXTENSIONS}")
    
    if DRY_RUN:
        print("\n[预览模式] 不会实际修改文件")
        modify_file_datasets_path_dry_run(TARGET_DIR, TARGET_FOLDERS, FILE_EXTENSIONS)
        
        print("\n" + "="*60)
        response = input("确认要实际修改这些文件吗？(y/n): ")
        if response.lower() == 'y':
            print("\n开始实际修改...")
            modify_file_datasets_path(TARGET_DIR, TARGET_FOLDERS, FILE_EXTENSIONS)
        else:
            print("已取消操作")
    else:
        print("\n[实际修改模式] 将直接修改文件")
        modify_file_datasets_path(TARGET_DIR, TARGET_FOLDERS, FILE_EXTENSIONS)
    