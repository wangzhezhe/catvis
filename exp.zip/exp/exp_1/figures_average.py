import matplotlib
matplotlib.use('Agg')  # 使用Agg后端，不需要Qt

import matplotlib.pyplot as plt
import numpy as np

# 五个case的平均数据
configs = ["C1(EX)", "C2(EX-R)", "C3(EX-R-OD)", "C4(EX-R-OD-PD)", "C5(EX-R-OD-PD-DATA)"]

# 原有指标的平均值（基于5个hardcase）
original_metrics = {
    "added_tasks": [7.8, 5.0, 4.2, 3.6, 3.4],
    "removed_tasks": [4.0, 2.2, 1.8, 1.4, 1.0],
    "avg_lines_per_modified": [2.86, 4.25, 3.69, 2.59, 2.73],
    "connection_changed": [3.0, 5.0, 3.2, 3.8, 3.6]
}

# 新指标的平均值
new_metrics = {
    "structural_accuracy": [57.8, 68.8, 78.0, 85.0, 86.8],
    "overall_similarity": [63.2, 71.9, 80.1, 86.0, 87.3]
}

# 创建图表
fig, axes = plt.subplots(2, 3, figsize=(18, 10))
fig.suptitle("Workflow Generation Quality - Average Results (5 Hard Cases)", 
             fontsize=16, fontweight="bold")

# 原有指标1: Added and Removed Tasks
ax1 = axes[0, 0]
x = np.arange(len(configs))
width = 0.35
bars1 = ax1.bar(x - width/2, original_metrics["added_tasks"], width, 
                label='Added Tasks', color='#e74c3c', alpha=0.8)
bars2 = ax1.bar(x + width/2, original_metrics["removed_tasks"], width, 
                label='Removed Tasks', color='#f39c12', alpha=0.8)
ax1.set_xlabel('Configuration', fontsize=11)
ax1.set_ylabel('Number of Tasks', fontsize=11)
ax1.set_title('Added & Removed Tasks', fontsize=12, fontweight='bold')
ax1.set_xticks(x)
ax1.set_xticklabels(configs, rotation=15, ha='right')
ax1.legend()
ax1.grid(axis='y', alpha=0.3)
for bars in [bars1, bars2]:
    for bar in bars:
        height = bar.get_height()
        ax1.text(bar.get_x() + bar.get_width()/2., height + 0.1,
                f'{height:.1f}', ha='center', va='bottom', fontsize=9)

# 原有指标2: Avg Lines per Modified Task
ax2 = axes[0, 1]
bars = ax2.bar(range(len(configs)), original_metrics["avg_lines_per_modified"], 
               color='#82aadb', alpha=0.8)
ax2.set_xlabel('Configuration', fontsize=11)
ax2.set_ylabel('Lines per Modified Task', fontsize=11)
ax2.set_title('Avg Lines per Modified Task', fontsize=12, fontweight='bold')
ax2.set_xticks(range(len(configs)))
ax2.set_xticklabels(configs, rotation=15, ha='right')
ax2.grid(axis='y', alpha=0.3)
for i, bar in enumerate(bars):
    height = bar.get_height()
    ax2.text(bar.get_x() + bar.get_width()/2., height + 0.1,
            f'{height:.2f}', ha='center', va='bottom', fontsize=9)

# 原有指标3: Connection Changed
ax3 = axes[0, 2]
bars = ax3.bar(range(len(configs)), original_metrics["connection_changed"], 
               color='#c3e3d5', alpha=0.8)
ax3.set_xlabel('Configuration', fontsize=11)
ax3.set_ylabel('Number of Changes', fontsize=11)
ax3.set_title('Connection Changes', fontsize=12, fontweight='bold')
ax3.set_xticks(range(len(configs)))
ax3.set_xticklabels(configs, rotation=15, ha='right')
ax3.grid(axis='y', alpha=0.3)
for i, bar in enumerate(bars):
    height = bar.get_height()
    ax3.text(bar.get_x() + bar.get_width()/2., height + 0.1,
            f'{height:.1f}', ha='center', va='bottom', fontsize=9)

# 新指标1: Structural Accuracy
ax4 = axes[1, 0]
bars = ax4.bar(range(len(configs)), new_metrics["structural_accuracy"], 
               color='#547dbd', alpha=0.8)
ax4.set_xlabel('Configuration', fontsize=11)
ax4.set_ylabel('Accuracy (%)', fontsize=11)
ax4.set_title('Structural Accuracy', fontsize=12, fontweight='bold')
ax4.set_xticks(range(len(configs)))
ax4.set_xticklabels(configs, rotation=15, ha='right')
ax4.set_ylim(0, 100)
ax4.grid(axis='y', alpha=0.3)
for i, bar in enumerate(bars):
    height = bar.get_height()
    ax4.text(bar.get_x() + bar.get_width()/2., height + 1,
            f'{height:.1f}%', ha='center', va='bottom', fontsize=9)

# 新指标2: Overall Similarity
ax5 = axes[1, 1]
bars = ax5.bar(range(len(configs)), new_metrics["overall_similarity"], 
               color='#82d8db', alpha=0.8)
ax5.set_xlabel('Configuration', fontsize=11)
ax5.set_ylabel('Similarity (%)', fontsize=11)
ax5.set_title('Overall Similarity', fontsize=12, fontweight='bold')
ax5.set_xticks(range(len(configs)))
ax5.set_xticklabels(configs, rotation=15, ha='right')
ax5.set_ylim(0, 100)
ax5.grid(axis='y', alpha=0.3)
for i, bar in enumerate(bars):
    height = bar.get_height()
    ax5.text(bar.get_x() + bar.get_width()/2., height + 1,
            f'{height:.1f}%', ha='center', va='bottom', fontsize=9)

# 新指标3: 综合对比
ax6 = axes[1, 2]
x = np.arange(len(configs))
width = 0.35
bars1 = ax6.bar(x - width/2, new_metrics["structural_accuracy"], width, 
                label='Structural Accuracy', color='#547dbd', alpha=0.8)
bars2 = ax6.bar(x + width/2, new_metrics["overall_similarity"], width, 
                label='Overall Similarity', color='#82d8db', alpha=0.8)
ax6.set_xlabel('Configuration', fontsize=11)
ax6.set_ylabel('Score (%)', fontsize=11)
ax6.set_title('Performance Comparison', fontsize=12, fontweight='bold')
ax6.set_xticks(x)
ax6.set_xticklabels(configs, rotation=15, ha='right')
ax6.legend()
ax6.set_ylim(0, 100)
ax6.grid(axis='y', alpha=0.3)
for bars in [bars1, bars2]:
    for bar in bars:
        height = bar.get_height()
        ax6.text(bar.get_x() + bar.get_width()/2., height + 1,
                f'{height:.1f}', ha='center', va='bottom', fontsize=9)

plt.tight_layout()
plt.savefig('average_metrics_comparison.png', dpi=150, bbox_inches='tight')
print("图表已保存为: average_metrics_comparison.png")

# 打印统计结果
print("=" * 80)
print("工作流生成质量评估 - 平均结果 (5个Hard Cases)")
print("=" * 80)

print("\n【原有指标 - 平均值】")
print("-" * 60)
print(f"{'配置':<20} {'新增任务':<12} {'删除任务':<12} {'平均修改行数':<15} {'连接变化':<12}")
print("-" * 60)
for i, config in enumerate(configs):
    print(f"{config:<20} {original_metrics['added_tasks'][i]:<12.1f} "
          f"{original_metrics['removed_tasks'][i]:<12.1f} "
          f"{original_metrics['avg_lines_per_modified'][i]:<15.2f} "
          f"{original_metrics['connection_changed'][i]:<12.1f}")

print("\n【新指标 - 平均值】")
print("-" * 60)
print(f"{'配置':<20} {'结构准确率(%)':<15} {'整体相似度(%)':<15}")
print("-" * 60)
for i, config in enumerate(configs):
    print(f"{config:<20} {new_metrics['structural_accuracy'][i]:<15.1f} "
          f"{new_metrics['overall_similarity'][i]:<15.1f}")

print("\n【性能提升 - 相对于C1(EX)】")
print("-" * 60)
print(f"{'配置':<20} {'结构准确率提升':<18} {'整体相似度提升':<18}")
print("-" * 60)
for i, config in enumerate(configs[1:], 1):
    gain_struct = new_metrics['structural_accuracy'][i] - new_metrics['structural_accuracy'][0]
    gain_sim = new_metrics['overall_similarity'][i] - new_metrics['overall_similarity'][0]
    print(f"{config:<20} +{gain_struct:<17.1f}% +{gain_sim:<17.1f}%")

print("\n【最佳配置】")
print(f"  结构准确率最高: C5 (EX-R-OD-PD-DATA) - {new_metrics['structural_accuracy'][4]:.1f}%")
print(f"  整体相似度最高: C5 (EX-R-OD-PD-DATA) - {new_metrics['overall_similarity'][4]:.1f}%")
print(f"  新增任务最少: C5 - {original_metrics['added_tasks'][4]:.1f}个")
print(f"  删除任务最少: C5 - {original_metrics['removed_tasks'][4]:.1f}个")

print("\n" + "=" * 80)