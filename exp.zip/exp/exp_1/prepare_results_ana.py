# create results_ana folder
# do not create if it does not exist

# go through results folder
# for each folder name

# create a folder with the same name under results_ana folder

# for each folder name under results folder
# copy all files ended with yaml into the folder with the same name under results_ana folder 

# copy the ground truth yaml from the sample_vis_workflow 
# for eample the case name is "easy-case1" under the results folder
# find the easy-case1 under the sample_vis_workflow folder
# then copy *.yaml into the folder under the results_ana/easy-case1


import os
import shutil
import glob

def organize_results():
    # Define paths
    results_dir = 'results'
    results_ana_dir = 'results_ana'
    sample_workflow_dir = 'sample_vis_workflow'

    # 1. Check if results_ana folder exists; do not create if it does not
    if not os.path.exists(results_ana_dir):
        print(f"'{results_ana_dir}' does not exist.")
        # create the folder
        os.makedirs(results_ana_dir)
        

    # 2. Go through results folder
    if not os.path.exists(results_dir):
        print(f"Error: '{results_dir}' folder not found.")
        return

    # Iterate through each item in the results directory
    for case_name in os.listdir(results_dir):
        case_path = os.path.join(results_dir, case_name)
        print(f"Processing {case_name}")

        # Process only if it's a directory
        if os.path.isdir(case_path):
            # 3. Create a folder with the same name under results_ana
            target_dir = os.path.join(results_ana_dir, case_name)
            os.makedirs(target_dir, exist_ok=True)

            # 4. Copy all files ending with .yaml from results/case_name to results_ana/case_name
            yaml_files = glob.glob(os.path.join(case_path, "*.yaml"))
            for f in yaml_files:
                shutil.copy2(f, target_dir)
                print(f"Copied {os.path.basename(f)} from results to {target_dir}")

            # 5. Copy ground truth yaml from sample_vis_workflow
            # Find the case name folder under sample_vis_workflow
            sample_source_path = os.path.join("../../",sample_workflow_dir, case_name)
            
            if os.path.exists(sample_source_path):
                sample_yaml_files = glob.glob(os.path.join(sample_source_path, "*.yaml"))
                for f in sample_yaml_files:
                    shutil.copy2(f, target_dir)
                    print(f"Copied ground truth {os.path.basename(f)} from {sample_source_path} to {target_dir}")
            else:
                print(f"Warning: Case '{case_name}' not found in {sample_workflow_dir}")

if __name__ == "__main__":
    organize_results()