import matplotlib.pyplot as plt
import numpy as np

# "C1(EX)", "C2(EX-R)", "C3(EX-R-OD)", "C4(EX-R-OD-PD)", "C5(EX-R-OD-PD-DATA)"
data = {
    "Case1": {
        "labels":    ["C1", "C2", "C3", "C4", "C5"],
        "added":     [12, 8, 8, 7, 6],
        "removed":   [5, 2, 2, 1, 1],
        "modified":  [3, 7, 6, 7, 7],
        "mod_lines": [19, 44, 32, 24, 25],
        "conn":      [2, 7, 1, 2, 2],
    },
    "Case2": {
        "labels":    ["C1", "C2", "C3", "C4", "C5"],
        "added":     [6, 6, 6, 0, 0],
        "removed":   [6, 3, 3, 0, 0],
        "modified":  [7, 7, 7, 13, 13],
        "mod_lines": [10, 25, 28, 28, 31],
        "conn":      [0, 6, 6, 4, 4],
    },
    "Case3": {
        "labels":    ["C1", "C2", "C3", "C4", "C5"],
        "added":     [7, 5, 4, 3, 3],
        "removed":   [5, 3, 1, 2, 0],
        "modified":  [7, 8, 9, 10, 10],
        "mod_lines": [14, 22, 27, 24, 25],
        "conn":      [5, 6, 5, 9, 7],
    },
    "Case4": {
        "labels":    ["C1", "C2", "C3", "C4", "C5"],
        "added":     [6, 2, 3, 1, 3],
        "removed":   [3, 1, 0, 0, 0],
        "modified":  [2, 6, 5, 7, 4],
        "mod_lines": [4, 31, 9, 10, 7],
        "conn":      [2, 4, 0, 4, 0],
    },
    "Case5": {
        "labels":    ["C1", "C2", "C3", "C4", "C5"],
        "added":     [6, 4, 3, 3, 3],
        "removed":   [4, 3, 1, 1, 1],
        "modified":  [2, 3, 4, 4, 5],
        "mod_lines": [13, 14, 21, 15, 13],
        "conn":      [2, 3, 3, 3, 3],
    },
}

# 4 bar groups: added, removed, avg_lines_per_task, connection_changed
COLORS = {
    "added":   "#547dbd",
    "removed": "#82d8db",
    "avg":     "#82aadb",
    "conn":    "#c3e3d5",
}
LABELS = {
    "added":   "Added tasks",
    "removed": "Removed tasks",
    "avg":     "Avg lines / Modified task",
    "conn":    "Connection changed",
}

fig, axes = plt.subplots(1, 5, figsize=(28, 5))
#fig.suptitle("Hardcase Comparison", fontsize=14, fontweight="bold", y=1.01)

n_groups = 4
bar_width = 0.18
offsets = np.array([-1.5, -0.5, 0.5, 1.5]) * bar_width

for ax, (case_name, d) in zip(axes, data.items()):
    x = np.arange(len(d["labels"]))

    avg_lines = [(ml*1.0) / (mt*1.0) if mt > 0 else 0
                 for ml, mt in zip(d["mod_lines"], d["modified"])]

    ax.bar(x + offsets[0], d["added"],   bar_width, label=LABELS["added"],   color=COLORS["added"],   zorder=2)
    ax.bar(x + offsets[1], d["removed"], bar_width, label=LABELS["removed"], color=COLORS["removed"], zorder=2)
    ax.bar(x + offsets[2], avg_lines,    bar_width, label=LABELS["avg"],     color=COLORS["avg"],     zorder=2)
    ax.bar(x + offsets[3], d["conn"],    bar_width, label=LABELS["conn"],    color=COLORS["conn"],    zorder=2)

    ax.set_xticks(x)
    ax.set_xticklabels(d["labels"], fontsize=15)
    ax.set_ylabel("Difference", fontsize=12, color="dimgray")
    ax.tick_params(axis="y", labelcolor="dimgray", labelsize=8)
    #ax.set_ylim(0, max(max(d["added"]), max(d["removed"]), max(avg_lines), max(d["conn"])) * 1.4 + 1)
    ax.set_ylim(0, 14)
    ax.grid(axis="y", linestyle="--", alpha=0.4, zorder=0)
    #ax.set_title(case_name, fontsize=11, fontweight="bold", loc="center")

    ax.legend(loc="upper right", fontsize=10, framealpha=0.8, ncol=2)

plt.tight_layout()
plt.savefig("hardcases.png", dpi=150, bbox_inches="tight")
# plt.show()
