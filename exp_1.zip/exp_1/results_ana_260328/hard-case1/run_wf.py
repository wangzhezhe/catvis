import sys
import os 
import time

print(sys.path)

from gwlalg.workflow import workflow_composer
gwl_catalog = workflow_composer.Catalog()
start_time = time.perf_counter()
#config = './EX_workflow_fix.yaml'
#config = './EX-R_workflow_fix.yaml'
#config = './EX-R-OD_workflow_fix.yaml'
#config = 'EX-R-OD-PD_workflow_fix.yaml'
#config = './EX-R-OD-PD-DATA_workflow_fix.yaml'
config = './gt_temp.yaml'


# build the workflow
workflow = workflow_composer.Workflow(config)
# run the workflow
workflow.run()    
end_time = time.perf_counter()

elapsed_time = end_time - start_time
print(f"Elapsed time for whole tests: {elapsed_time:.4f} seconds")
