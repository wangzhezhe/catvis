```yaml
name: rotor37_complex_analysis
params:
  input_dataset: ../../datasets/Rotor37-100-101325pa_001/Rotor37-100-101325pa_001.vtm

tasks:
  IDLoadingData:
    name: 读取VTM数据
    from: vtkmDataLoader
    inputs:
      - data_file: $globals.params.input_dataset
    output: IDLoadingData_output

  IDPreprocess:
    name: 数据预处理
    from: Preprocess
    inputs:
      - data: $IDLoadingData.IDLoadingData_output
      - merge: False
    output: IDPreprocess_output

  # Branch 1: Surface mapping and streamlines
  IDGeometryMapping:
    name: 几何映射
    from: GeometryMapping
    inputs:
      - data: $IDPreprocess.IDPreprocess_output
    output: IDGeometryMapping_output

  IDSurfaceStreamline:
    name: 表面流线
    from: SurfaceStreamline
    inputs:
      - data: $IDGeometryMapping.IDGeometryMapping_output
      - velocity: ["U_x", "U_y", "U_z"]
      - num_seeds: 100
    output: IDSurfaceStreamline_output

  # Branch 2: Spanwise analysis
  IDSpanNormal:
    name: 计算叶高
    from: SpanNormal
    inputs:
      - data: $IDPreprocess.IDPreprocess_output
      - hub: ["R1 Hub Step*"]
      - shroud: ["R1 Shroud Step*"]
      - origin: [0,0,0]
      - axis: [0,0,1]
    output: IDSpanNormal_output

  IDIso:
    name: 等值面提取
    from: IsoSurface
    inputs:
      - data: $IDSpanNormal.IDSpanNormal_output
      - variable_name: SpanNormal
      - isovalue: 0.98
    output: IDIso_output

  IDDuplicate:
    name: 旋转复制
    from: RotDuplication
    inputs:
      - data: $IDIso.IDIso_output
      - origin: [0.0, 0.0, 0.0]
      - axis_vector: [0.0, 0.0, 1.0]
      - degree: 30.0
      - num_copies: 5
      - merge: True 
    output: IDDuplicate_output

  IDZThetaView:
    name: Z-Theta视图
    from: ZThetaView
    inputs:
      - data: $IDDuplicate.IDDuplicate_output
      - theta_scale: 0.2
    output: IDZThetaView_output

  # Branch 3: Vortex analysis
  IDQCriterion:
    name: Q准则计算
    from: AddQCriterion
    inputs:
      - data: $IDPreprocess.IDPreprocess_output
      - velocity: ["U_x", "U_y", "U_z"]
    output: IDQCriterion_output

  IDIsoVolume:
    name: 等值体积过滤
    from: IsoVolume
    inputs:
      - data: $IDQCriterion.IDQCriterion_output
      - variable_name: Q-criterion
      - lower_iso: 0.1
      - upper_iso: 1.0
      - mode: band
    output: IDIsoVolume_output

  # Merging and output
  IDMergeResults:
    name: 结果合并
    from: FilterList
    inputs:
      - data: ["$IDSurfaceStreamline.IDSurfaceStreamline_output", "$IDZThetaView.IDZThetaView_output", "$IDIsoVolume.IDIsoVolume_output"]
      - merge_strategy: suffix
    output: IDMergeResults_output

  IDWriteSurfaceResults:
    name: 写出表面结果
    from: oneVTKDataWriter
    inputs:
      - data: $IDSurfaceStreamline.IDSurfaceStreamline_output
      - output_dir: ./output
      - output_file_name: surface_results.vtp
      - force_vtp: True
    output: IDWriteSurfaceResults_output

  IDWriteZThetaResults:
    name: 写出Z-Theta结果
    from: oneVTKDataWriter
    inputs:
      - data: $IDZThetaView.IDZThetaView_output
      - output_dir: ./output
      - output_file_name: ztheta_results.vtu
    output: IDWriteZThetaResults_output

  IDWriteVortexResults:
    name: 写出涡结构结果
    from: oneVTKDataWriter
    inputs:
      - data: $IDIsoVolume.IDIsoVolume_output
      - output_dir: ./output
      - output_file_name: vortex_results.vtu
    output: IDWriteVortexResults_output
```