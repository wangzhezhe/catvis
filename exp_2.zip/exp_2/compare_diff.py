import yaml  # pip install pyyaml
import os
from collections import OrderedDict

# normalize the id, so we can compare them
# for each item
# get origianl id, and the module name
# replace self item
# replate the output string, if original id contained in output string, change it
# replace other items, for all other items, if there data contains the original id, change it

# 1. Add this representer to make OrderedDict look like a normal YAML map
def represent_ordereddict(dumper, data):
    return dumper.represent_dict(data.items())
yaml.add_representer(OrderedDict, represent_ordereddict)
def normalize_workflow(data):
    """
    Normalizes a workflow while preserving the original task order.
    """
    if not data or "tasks" not in data:
        return data

    # Use OrderedDict for the mapping and the final task set
    tasks = data["tasks"]
    id_map = OrderedDict()
    module_counts = {}

    # 1. Create unique ID map while respecting original insertion order
    for old_id in tasks.keys():
        module_name = tasks[old_id].get("from", "")
        module_counts[module_name] = module_counts.get(module_name, 0) + 1
        
        # New ID: e.g., vtkmDataLoader_1, Clip_1, Clip_2
        new_id = f"ID_{module_name}_{module_counts[module_name]}"
        new_id_output = new_id+"_output"
        id_map[old_id] = (new_id,new_id_output)
    
    # 2. Reconstruct tasks in an OrderedDict
    normalized_tasks = OrderedDict()
    
    # for each task update its id and output firstly
    for old_id, task in tasks.items():
        new_id,new_id_output = id_map[old_id]
        new_task = task.copy()
        
        # Update output string
        if "output" in new_task and isinstance(new_task["output"], str):
            new_task["output"] = new_id_output
            
        # Update inputs (connections)
        if "inputs" in new_task and isinstance(new_task["inputs"], list):
            new_inputs = []
            for item in new_task["inputs"]:
                if isinstance(item, dict) and "data" in item:
                    new_item = item.copy()
                    v = new_item["data"]

                    # Helper function to process a single "$ID.Output" string
                    def process_connection(conn_str):
                        if isinstance(conn_str, str) and conn_str.startswith("$"):
                            # Split $ID.Output -> ID
                            parts = conn_str.lstrip("$").split(".")
                            source_task_id = parts[0]
                            if source_task_id in id_map:
                                mapped_id, mapped_output = id_map[source_task_id]
                                return f"${mapped_id}.{mapped_output}"
                        return conn_str

                    # Case 1: data is a list [ $ID.Out, $ID.Out ]
                    if isinstance(v, list):
                        new_item["data"] = [process_connection(s) for s in v]
                    
                    # Case 2: data is a single string "$ID.Out"
                    else:
                        new_item["data"] = process_connection(v)
                    
                    new_inputs.append(new_item)
                else:
                    # Keep other parameters (output_dir, etc.) as they are
                    new_inputs.append(item)
            
            new_task["inputs"] = new_inputs
        # Store in the ordered dictionary
        normalized_tasks[new_id] = new_task

    return {"tasks": normalized_tasks}
def compare_workflow_files(file_path_orig, file_path_ground_truth):
    """
    Compares two workflow YAML templates, listing modified IDs and counting total parameter line changes.
    """
    if not os.path.exists(file_path_orig):
        print(f"error in path: {file_path_orig}")
        print(f"Error: File not found.")
        return
    
    if not os.path.exists(file_path_ground_truth):
        print(f"error in path: {file_path_ground_truth}")
        print(f"Error: Files not found.")
        return
    

    try:
        with open(file_path_orig, 'r', encoding='utf-8') as f:
            orig_data = yaml.safe_load(f)
        with open(file_path_ground_truth, 'r', encoding='utf-8') as f:
            gt_data = yaml.safe_load(f)
    except Exception as e:
        print(f"Error parsing YAML: {e}")
        return
    
    print("--- Normalized Workflow Output gt---")
    normalized_gt_tasks = normalize_workflow(gt_data)
    print("--- Normalized Workflow Output task---")
    normalized_orig_tasks = normalize_workflow(orig_data)



    # 2. When dumping, use sort_keys=False to keep your original order
    #print(yaml.dump(normalized_gt_tasks, sort_keys=False, allow_unicode=True))

    orig_tasks = normalized_orig_tasks.get("tasks", {}) if normalized_orig_tasks else {}
    gt_tasks = normalized_gt_tasks.get("tasks", {}) if normalized_gt_tasks else {}




    # 1. Structural differences
    orig_keys = set(orig_tasks.keys())
    gt_keys = set(gt_tasks.keys())
    
    added_tasks = sorted(list(gt_keys - orig_keys))
    removed_tasks = sorted(list(orig_keys - gt_keys))
    common_tasks = orig_keys & gt_keys

    # 2. Detail tracking
    tasks_with_corrected_from = []
    tasks_with_fixed_params = []
    tasks_with_conn_changes = []
    total_param_line_diffs = 0

    def flatten_inputs(input_list):
        flat = {}
        for item in (input_list or []):
            if isinstance(item, dict):
                flat.update(item)
        return flat

    update_paras = OrderedDict()
    # 3. Deep Analysis
    for task_id in sorted(list(common_tasks)):
        t_orig = orig_tasks[task_id]
        t_fix = gt_tasks[task_id]

        # Check 'from'
        if t_orig.get("from") != t_fix.get("from"):
            tasks_with_corrected_from.append(task_id)

        # Check 'inputs' and count line-by-line differences
        orig_inputs = flatten_inputs(t_orig.get("inputs"))
        fix_inputs = flatten_inputs(t_fix.get("inputs"))

        # Check 'output'
        if orig_inputs.get("data") != fix_inputs.get("data"):
            tasks_with_conn_changes.append(task_id)


        # do not count data here
        orig_inputs.pop("data", None)
        fix_inputs.pop("data", None)

        all_param_keys = set(orig_inputs.keys()) | set(fix_inputs.keys())
        task_param_diff_count = 0
        
        current_task_diffs = {}
        for p_key in all_param_keys:
            v_orig = orig_inputs.get(p_key)
            v_fix = fix_inputs.get(p_key)
            if v_orig != v_fix:
                task_param_diff_count += 1
                current_task_diffs[p_key] = (v_orig, v_fix)

        if task_param_diff_count > 0:
            tasks_with_fixed_params.append(task_id)
            total_param_line_diffs += task_param_diff_count
            update_paras[task_id] = current_task_diffs



    # --- Print Detailed Summary Report ---
    print(f"{'='*65}")
    print(f"WORKFLOW COMPARISON: {os.path.basename(file_path_orig)}")
    print(f"{'='*65}")
    print(f"Total Tasks: Original ({len(orig_keys)}) | Fixed ({len(gt_keys)})")
    print(f"-"*65)
    
    # Structure Changes
    if added_tasks:
        print(f"[+] Added Tasks ({len(added_tasks)}):")
        print(f"    {', '.join(added_tasks)}")
    
    if removed_tasks:
        print(f"[-] Removed Tasks ({len(removed_tasks)}):")
        print(f"    {', '.join(removed_tasks)}")

    # Modification Details
    if tasks_with_corrected_from:
        print(f"[*] Corrected 'from' Name ({len(tasks_with_corrected_from)}):")
        print(f"    {', '.join(tasks_with_corrected_from)}")

    if tasks_with_fixed_params:
        print(f"[*] Parameters Modified ({len(tasks_with_fixed_params)} tasks, {total_param_line_diffs} total lines):")
        print(f"    {', '.join(tasks_with_fixed_params)}")

    if tasks_with_conn_changes:
        print(f"[*] Connections Changed ({len(tasks_with_conn_changes)}):")
        print(f"    {', '.join(tasks_with_conn_changes)}")

    if not any([added_tasks, removed_tasks, tasks_with_corrected_from, tasks_with_fixed_params, tasks_with_conn_changes]):
        print("No differences found.")
        
    print(f"{'='*65}\n")

    # --- Logging Logic ---
    banner = "="*65
    log_file = "para_diff_log.txt"
    with open(log_file, 'a', encoding='utf-8') as log:
        log.write(f"\n{banner}\n")
        log.write(f"SOURCE: {file_path_orig}\n")
        log.write(f"GROUND TRUTH: {file_path_ground_truth}\n")
        log.write(f"{banner}\n")
        
        if not update_paras:
            log.write("No parameter differences found.\n")
        else:
            for tid, diffs in update_paras.items():
                log.write(f"Task: {tid}\n")
                for p_key, (old_v, new_v) in diffs.items():
                    log.write(f"  - {p_key}:\n")
                    log.write(f"      [Original]: {old_v}\n")
                    log.write(f"      [GroundTr]: {new_v}\n")
        log.write("\n")
    print(f"Done. Detailed log appended to {log_file}")


# --- Execution ---
# Use the relative path you showed in your terminal
# dir_path_list = r"."
# cases_list = ["."]
# ground_truth_files = ["gwlalg-vis-workflow-1-2.yaml", "gwlalg-vis-workflow-2-2.yaml","workflow_config.yaml","gwlalg-vis-workflow-4-2.yaml","gwlalg-vis-workflow-6-2.yaml"]

# file_names = [
#     ("EX_workflow.yaml", "EX_workflow_fix.yaml"),
#     ("EX-R_workflow.yaml", "EX-R_workflow_fix.yaml"),
#     ("EX-R-OD_workflow.yaml", "EX-R-OD_workflow_fix.yaml"),
#     ("EX-R-OD-PD_workflow.yaml", "EX-R-OD-PD_workflow_fix.yaml"),
#     ("EX-R-OD-PD-DATA_workflow.yaml", "EX-R-OD-PD-DATA_workflow_fix.yaml")
# ]


baseline_gt= "stage0_result.yaml"
baseline_human_fix = os.path.join("stage2_workflow_results","stage0_result_ground_truth_with_humantune.yaml")

compare_workflow_files(baseline_gt, baseline_human_fix)


stage2_results_lists=[
"260408_deepseekv3\\test0\\stage2_result.yaml",
"260423_deepseekv3\\test3\\stage2_result.yaml",
"260408_deepseekv3\\test2\\stage2_result.yaml",
]


stage3_results_lists=[
"260408_deepseekv3\\test0\\stage3_result.yaml",
"260423_deepseekv3\\test3\\stage3_result.yaml",
"260408_deepseekv3\\test2\\stage3_result.yaml",
]

gt_file_lists = [
    "test0_stage3_result_humanfix.yaml",
    #"test1_stage3_result_humanfix.yaml", # we replace the original test1 with test3, since there is missing data in original test1
    "test3_stage3_result_humanfix.yaml",
    "test2_stage3_result_humanfix.yaml",
    
]


for index, file_name in enumerate(gt_file_lists):
    print("--------------------")
    # stage2
    print("check gt name:", file_name)
    gt_path = os.path.join("stage2_workflow_results", gt_file_lists[index])

    stage2_path = os.path.join("stage2_workflow_results",stage2_results_lists[index])
    print("stage2_path:",stage2_path)
    compare_workflow_files(gt_path, stage2_path)

    # stage3
    stage3_path = os.path.join("stage2_workflow_results",stage3_results_lists[index])
    print("stage3_path:",stage3_path)
    compare_workflow_files(gt_path, stage3_path)


