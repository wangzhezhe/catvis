import matplotlib.pyplot as plt
import numpy as np

# 数据准备
cases = ["test1_stage2", "test1_stage3", "test2_stage2", "test2_stage3", "tets3_stage2", "test3_stage3"]
added_tasks = [1, 0, 2, 1, 1, 0]
removed_tasks = [ 2, 0, 2, 3, 3, 2]
modified_tasks = [ 2, 1, 1, 1, 1, 1]
modified_lines = [ 3, 2, 1, 1, 1, 1]
connection_changed = [ 3, 0, 5, 4, 4, 1]

# 计算平均每项任务修改的行数 (Avg lines / Modified task)
avg_lines = [(ml / mt) if mt > 0 else 0 for ml, mt in zip(modified_lines, modified_tasks)]

# 颜色和标签定义（参考原脚本）
COLORS = {
    "added":   "#547dbd",
    "removed": "#82d8db",
    "avg":     "#82aadb",
    "conn":    "#c3e3d5",
}
LABELS = {
    "added":   "Added tasks",
    "removed": "Removed tasks",
    "avg":     "Avg lines / Modified task",
    "conn":    "Connection changed",
}

# 绘图设置
n_groups = 4
bar_width = 0.18
x = np.arange(len(cases))
offsets = np.array([-1.5, -0.5, 0.5, 1.5]) * bar_width

plt.figure(figsize=(10, 6))

# 绘制柱状图
plt.bar(x + offsets[0], added_tasks,        bar_width, label=LABELS["added"],   color=COLORS["added"],   zorder=2)
plt.bar(x + offsets[1], removed_tasks,      bar_width, label=LABELS["removed"], color=COLORS["removed"], zorder=2)
plt.bar(x + offsets[2], avg_lines,          bar_width, label=LABELS["avg"],     color=COLORS["avg"],     zorder=2)
plt.bar(x + offsets[3], connection_changed, bar_width, label=LABELS["conn"],    color=COLORS["conn"],    zorder=2)

# 图表装饰
plt.xticks(x, cases, rotation=15, fontsize=14)
plt.ylabel("Difference", fontsize=12, color="dimgray")
plt.tick_params(axis="y", labelcolor="dimgray", labelsize=10)
plt.grid(axis="y", linestyle="--", alpha=0.4, zorder=0)
#plt.title("Comparison of Experimental Results", fontsize=14, fontweight="bold")
plt.legend(loc="upper right", fontsize=12, framealpha=0.8)

plt.tight_layout()
plt.savefig("exp2_results_no_std_baseline.png", dpi=150, bbox_inches="tight")


# show avg of the dataset

